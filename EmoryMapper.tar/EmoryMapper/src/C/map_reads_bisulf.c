#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <float.h> 
#include <ctype.h>

#define TRUE 1
#define FALSE 0
#define stdprn  ((FILE *)NULL)
#include <time.h>
 
#define minim(a,b) ((a<b)?a:b)
#define maxim(a,b) ((a>b)?a:b)

void read_var(char *line,char *result);
int *ivector(int nl,int nh);
char *cvector(int nl,int nh);
unsigned char *ucvector(int nl,int nh);
unsigned long *ulvector(int nl,int nh);
unsigned int *uvector(int nl,int nh);
unsigned long long *ullvector(int nl,int nh);
double *dvector(int nl, int nh);
double **dmatrix(int nrl,int nrh,int ncl,int nch);
char **cmatrix(int nrl,int nrh,int ncl,int nch);
unsigned char **ucmatrix(int nrl,int nrh,int ncl,int nch);
unsigned long **ulmatrix(int nrl,int nrh,int ncl,int nch);
unsigned int **umatrix(int nrl,int nrh,int ncl,int nch);
void free_cvector(char *v, int nl, int nh);
void free_ivector(int *v, int nl, int nh);
void free_ucvector(unsigned char *v, int nl, int nh);
void free_ulvector(unsigned long *v, int nl, int nh);
void free_uvector(unsigned int *v, int nl, int nh);
void free_dvector(double *v, int nl,int nh);
void free_dmatrix(double **m,int nrl,int nrh,int ncl,int nch);
void free_cmatrix(char **m,int nrl,int nrh,int ncl,int nch);
void free_ucmatrix(unsigned char **m,int nrl,int nrh,int ncl,int nch);
void free_ulmatrix(unsigned long **m,int nrl,int nrh,int ncl,int nch);
void free_umatrix(unsigned int **m,int nrl,int nrh,int ncl,int nch);
void nrerror(char *error_text);
int **imatrix(int nrl,int nrh,int ncl,int nch);
void free_imatrix(int **m,int nrl,int nrh,int ncl,int nch);
void set_next(char *sss,int *i, int *j);
void count_copys(int *flat, char *s, int n,int *reps);
void reverse_transcribe(char *contig, char *s, int n);
void transcribe(char *contig, char *s, int n);
void reverse_string(char *contig, char *s, int n);
int snp_sort(const void *a,const void *b);
int mystrcmp(const void *a,const void *b);
int sort_unsigned_long(const void *a,const void *b);
int sort_unsigned_int(const void *a,const void *b);
int check_watson_crick(char a, char b);
unsigned int encode_basepairs(char *ss,int n);
void decode_basepairs(unsigned char *s,char *dest,int n);
void convert_int_basepairs(int i,char *s,int k);
int ishetero(char a);
int convert_seq_int(char *seq,int n);
int compare_base(char a, char b);
int compare_sequence(char *s1,char *s1a,char *s2);
int find_chrom(int *pos,int *ends,int n,int this);
void find_matches(unsigned int **mers,int max_depth,int *offsets, int idepth,
		  int *min_match,unsigned int *hits,int *hits_off,int *seg_matches,
		  int *tot_hits,char *orient,char or);
void convert_ct(char *s,int n);

static FILE *outfile;
static int PRINT_ME;
static 	int max_hits = 2000;
 
int main()
{
	char *token;
	char **filename,ss[256],sss[4196],forward_seq[1024],reverse_seq[1024],f1[1024],basename[1024];
	int i,j,N,max_decon;
	int idepth,total_index,decode,decode_length,not_done;
	double max_rportion;
	int *offsets,total_cuts,*frag_pos;
	char *orient;
	unsigned int *hits;
	int *segs_matched,*hits_off,is_bisulf;
	int *frag_map;
	unsigned int **all_mers;
	unsigned int **forward_mers;
	unsigned int **reverse_mers;
	unsigned int *temp_mers;
	int temp_off;

  	FILE *mfile,*sfile,*innfile1;

	max_decon = 81920;
	max_rportion = 0.9;
	PRINT_ME = FALSE;
	
	outfile = stdout;
	read_var("\nSend Output to Screen or Disk? [S,D]\n",ss);
 
	if( (strchr(ss,'D')) || (strchr(ss,'d')) )
	{
		read_var("Please Enter File Name for Output\n",ss);
		if((outfile=fopen(ss,"w"))==(FILE *)NULL)
		{
			printf("\n Can not open file %s\n",ss);
			exit(1);
		}

	}

	read_var("Name of sdx file\n",basename);
	if((sfile=fopen(basename,"r"))==(FILE *)NULL)
	{
	    printf("\n Can not open file %s\n",basename);
	    exit(1);
	}
	for(i=0;i<strlen(basename);i++)
	  if(basename[i] == '.')
	    basename[i] = '\0';

	fgets(sss,256,sfile);
	N = atoi(sss);
	frag_pos = ivector(-1,N);
	filename = cmatrix(0,N,0,256);
	frag_pos[-1] = 0;
	for(i=0;i<N;i++)
	{
	    fgets(sss,1024,sfile);
	    token = strtok(sss,"\t \n");
	    frag_pos[i] = atoi(token);
	    /* sprintf(sss,"%u\t>%s",&offsets[i],s2); */
	    frag_pos[i] += frag_pos[i-1];
	    token = strtok(NULL,"\t \n");
	    strcpy(filename[i],token);
	    // printf("\nFor contig %d we have offset %u",i,frag_pos[i]); 
	}

	int N1 = N-1;
	int last = 1+frag_pos[N1]/100;
	frag_map = ivector(0,last);
	int this_pos = 0;
	j = 0;
	for(i=1;i<=last;i++)
	  frag_map[i] = N1;
	for(i=0;(i <= frag_pos[N1]) && (this_pos < N); i+=100,j++)
	{
	    while(frag_pos[this_pos] < i)
	      this_pos++;
	    frag_map[j] = this_pos;
	    // printf("\n frag_map[%d] = %d",i,frag_map[i]);
	}

	fgets(sss,1024,sfile);
	idepth = atoi(sss);
	fclose(sfile);
	// for(i=0;i<N;i++)
	// frag_pos[i] -= idepth;

	hits = uvector(0,max_hits);
	segs_matched = ivector(0,max_hits);
	hits_off = ivector(0,max_hits);
	orient = cvector(0,max_hits);
	printf("\n Found %d contigs and a depth of %d\n",N,idepth);
	printf("\n About to Read Indices \n\n");
	total_index = (int)pow(4,idepth);

	sprintf(sss,"%s.mdx",basename);

	if((mfile=fopen(sss,"r"))==(FILE *)NULL)
	{
	    printf("\nCould Not Open file %s\n",sss);
	    exit(1);
	}

	all_mers=(unsigned int **) malloc((unsigned) (total_index+1)*sizeof(unsigned int *));
	if(!all_mers) nrerror("\n Error Allocating all mers\n");
	for(i=0;i<total_index;i++)
	{
	    fread(&decode_length,sizeof(int),1,mfile);
	    if(decode_length > 0)
	    {
		all_mers[i] = uvector(0,decode_length); 
	    	fread(&all_mers[i][1],sizeof(unsigned int),decode_length,mfile);
		/* if(decode_length > 10)
		{
	    		printf("\n i = %d len = %d",i,decode_length);
			for(j=1;j<=decode_length;j++)
				printf("\t %d",all_mers[i][j]);	
		} */
	    }
	    else
	    {
		all_mers[i] = uvector(0,1); 
            }
	    all_mers[i][0] = decode_length;
	}
	fclose(mfile);
	// printf("\n Made it here \n\n");

	read_var("Name of file containing read\n",ss);
	if((innfile1=fopen(ss,"r"))==(FILE *)NULL)
	{
	    printf("\n Can not open file %s for reading which should contain first reads\n",ss);
	    exit(1);
	}

	read_var("Has the target DNA been bisulfite converted?\n",ss);
	if( (strchr(ss,'Y')) || (strchr(ss,'y')) )
	  is_bisulf = TRUE;
	else
	  is_bisulf = FALSE;
	
	not_done = TRUE;
	fgets(forward_seq,1023,innfile1);
	fgets(forward_seq,1023,innfile1);

	fprintf(outfile,"\nSequence\tFragment\tPosition in Fragment");
	while(not_done && !feof(innfile1) && strlen(forward_seq) > idepth)
	{
	    int seq_len = strlen(forward_seq);
	    // printf("\n Back at top \n\n");
	    for(i=0;i<=seq_len;i++)
	      if(isalpha(forward_seq[i]))
		forward_seq[i] = toupper(forward_seq[i]);
	      else
	      {
		  forward_seq[i] = '\0';
		  seq_len = i;
	      }
	    reverse_transcribe(forward_seq,reverse_seq,seq_len);
	    if(is_bisulf)
	    {
		strcpy(f1,forward_seq);
		convert_ct(forward_seq,seq_len);
		convert_ct(reverse_seq,seq_len);
	    }

	    total_cuts = seq_len / idepth;
	    if(seq_len % idepth == 0)
	      total_cuts--;

	    offsets = ivector(0,total_cuts);
	    // printf("\n Looking for sequence %s which has length %d and total cuts = %d\n\n",forward_seq,seq_len,total_cuts);
	    offsets[0] = 0;
	    i = 1;
	    while(i < total_cuts)
	      {
		offsets[i] = offsets[i-1]+idepth;
		i++;
	      }
	    if(i == total_cuts)
	      offsets[i] = seq_len - idepth;
	    
	    forward_mers=(unsigned int **) malloc((unsigned) (total_cuts+1)*sizeof(unsigned int *));
	    if(!forward_mers) nrerror("\n Error Allocating forward mers\n");
	    
	    reverse_mers=(unsigned int **) malloc((unsigned) (total_cuts+1)*sizeof(unsigned int *));
	    if(!reverse_mers) nrerror("\n Error Allocating forward mers\n");
	    
	    // printf("\n About to Assemble matches \n\n");

	    for(i=0;i<=total_cuts;i++)
	    {
		// printf("\nWorking on Forward subsequence %s which begins at %d",&forward_seq[offsets[i]],offsets[i]); 
		decode = convert_seq_int(&forward_seq[offsets[i]],idepth);
		// printf("\n\tjust decoded number %d to %d which has %d occurrences\n",i,decode,all_mers[decode][0]);  
		forward_mers[i] = all_mers[decode];
		decode = convert_seq_int(&reverse_seq[offsets[i]],idepth);
		// printf("\nWorking on Reverse subsequence %s which begins at %d",&reverse_seq[offsets[i]],offsets[i]); 
		reverse_mers[i] = all_mers[decode];
	        // printf("\n\tjust decoded number %d to %d which has %d occurrences\n",i,decode,all_mers[decode][0]);  
	    }

	    int min_match = minim(4,maxim(1,total_cuts));
	    if(total_cuts > 4)
	    	min_match = (4*(total_cuts))/5;

 	   //  min_match = 1;
	    
	    // printf("\n total_cuts = %d \n",total_cuts);
	    if(is_bisulf)
	      fprintf(outfile,"\n%s",f1);
	    else
	      fprintf(outfile,"\n%s",forward_seq);
	    int tot1 = 0;
	    for(i=0;i<total_cuts;i++)
		for(j=i+1;j<=total_cuts;j++)
			if(forward_mers[i][0] > forward_mers[j][0])
			{
				temp_mers = forward_mers[i];   		temp_off = offsets[i];
				forward_mers[i] = forward_mers[j];	offsets[i] = offsets[j];
				forward_mers[j] = temp_mers;		offsets[j] = temp_off;
			}

	    find_matches(forward_mers,total_cuts,offsets,idepth,&min_match,hits,hits_off,segs_matched,&tot1,orient,0);
	    offsets[0] = 0;
	    i = 1;
	    while(i < total_cuts)
	      {
		offsets[i] = offsets[i-1]+idepth;
		i++;
	      }
	    if(i == total_cuts)
	      offsets[i] = seq_len - idepth;
	    for(i=0;i<total_cuts;i++)
		for(j=i+1;j<=total_cuts;j++)
			if(reverse_mers[i][0] > reverse_mers[j][0])
			{
				temp_mers = reverse_mers[i];   		temp_off = offsets[i];
				reverse_mers[i] = reverse_mers[j];	offsets[i] = offsets[j];
				reverse_mers[j] = temp_mers;		offsets[j] = temp_off;
			}
	    

	    // printf("\n got here with tot1 = %d  and min_match = %d\n\n",tot1,min_match);
	    
	    // printf("\n%s\t",reverse_seq);
	    int tot2 = tot1;
	    find_matches(reverse_mers,total_cuts,offsets,idepth,&min_match,hits,hits_off,segs_matched,&tot2,orient,1);
	    
	    // printf("\n got here with tot2 = %d and min_match = %d\n\n",tot2,min_match);

	    for(i=0;i<tot2;i++)
	      {
		  int which;
		  which = find_chrom(frag_map,frag_pos,last,hits[i]);
		  //fprintf(outfile,"\t%s\t%d",filename[which],hits[i]-(frag_pos[which-1]+hits_off[i]));
		  fprintf(outfile,"\t%d\t%d\t%d",which,hits[i]-(frag_pos[which-1]+hits_off[i]),(int)orient[i]);
	      }
	    

	    free_ivector(offsets,0,total_cuts);
	    free(forward_mers);
	    free(reverse_mers);
	    // printf("\n Made it here \n\n");
	    if(feof(innfile1))
	      not_done = FALSE;
	    else
	    {
		int not_there = TRUE;
		fgets(forward_seq,1023,innfile1);
		fgets(forward_seq,1023,innfile1);
		while(!feof(innfile1) && not_there)
		{
		    fgets(forward_seq,1023,innfile1);
		    if(forward_seq[0] == '@')
		    {
			not_there = FALSE;
			fgets(forward_seq,1023,innfile1);
		    }

		}
		if(not_there)
		  not_done = FALSE;
		  
	    }
	}

	exit(0);
	    
} 

/*---------------------------------------------------------------------*/
void find_matches(unsigned int **mers,int max_depth,int *offsets, int idepth,
		  int *min_match,unsigned int *hits,int *hits_off,int *seg_matches,
		  int *tot_hits,char *orient,char or)
{

	int tot_found;
	int mer_pos[10000];
	int i,j,k,start,end,loop,max_off=maxim(2,idepth-4);

	/* for(i=0;i<=max_depth;i++)
	{
	    printf("\n Piece %d has %d options",i,mers[i][0]);
	    for(j=1;j<=mers[i][0];j++)
	      printf(" %d",mers[i][j]);
	      } */

	for(loop=0;loop <= 1 + max_depth-(*min_match);loop++)
	{
		start = -(offsets[loop] + max_off);
		end = max_off;
		for(j=loop+1;j<=max_depth;j++)
			end = maxim(end,max_off+offsets[j]-offsets[loop]);
		
		for(i=loop;i<=max_depth;i++)
		  mer_pos[i] = 1;

		// printf("\n loop =%d offset = %d Start = %d   end = %d max_depth = %d",loop,offsets[loop],start,end,max_depth);

		for(i=1;i<=mers[loop][0];i++)
		{
		    int this_start = mers[loop][i] + start;
		    int this_end = mers[loop][i] + end;
		    this_start = maxim(this_start,0);
		    this_end = maxim(this_end,0);
		    for(j=loop+1;j<=max_depth;j++)
			while( (mer_pos[j] < mers[j][0]) && (mers[j][mer_pos[j]] < this_start))
			  mer_pos[j]++;

		    //for(j=loop+1;j<=max_depth;j++)
		    // printf("\n Starting element for list %d is %d out of %d",j,mer_pos[j],mers[j][0]);

		    tot_found = 1;
		    for(j=loop+1;j<=max_depth;j++)
		      for(k=mer_pos[j];(k<=mers[j][0] && mers[j][k]<= this_end) ; k++)
			if( abs( (mers[loop][i]-mers[j][k]) - (offsets[loop]-offsets[j])) < max_off)
			{
			    tot_found++;
			    // printf("\n Found a part at j = %d k = %d",j,k);
			    k = mers[j][0]+1;
			}

		    if(tot_found > *min_match)
		    {
			*min_match = tot_found;
			*tot_hits = 0;
			seg_matches[*tot_hits] = tot_found;
			hits[*tot_hits] = mers[loop][i];
			hits_off[*tot_hits] = offsets[loop];
			orient[*tot_hits] = or;
			(*tot_hits)++;
			// printf("\n Nailed it tot_found = %d loop = %d i = %d pos = %d offset = %d total_hits = %d",tot_found,loop,i,mers[loop][i],offsets[loop],*tot_hits);
		    }
		    else
		      if( (tot_found == *min_match) )
			if(*tot_hits < max_hits)
			{
			    int new = 1;
			    for(k=0;k<*tot_hits;k++)
			      if(hits[k] - hits_off[k] == mers[loop][i] - offsets[loop])
			      {
				  k = *tot_hits;
				  new = 0;
			      }
			    if(new)
			    {
				seg_matches[*tot_hits] = tot_found;
				hits[*tot_hits] = mers[loop][i];
				hits_off[*tot_hits] = offsets[loop];
				orient[*tot_hits] = or;
				(*tot_hits)++;
				// printf("\n Nailed it tot_found = %d loop = %d i = %d pos = %d offset = %d total_hits = %d",tot_found,loop,i,mers[loop][i],offsets[loop],*tot_hits);
			    }
			}
		}
	}

}
/*---------------------------------------------------------------------*/
int find_chrom(int *pos,int *ends,int n,int this)
{
  int try = pos[this / 100];
  while( (ends[try] <= this) && try < n)
    try++;
  return try;

}
/*---------------------------------------------------------------------*/

int compare_base(char a, char b)
{
  a = toupper(a);
  b = toupper(b);

  if(a==b)
    return TRUE;

  if( (a == 'N')  || (b == 'N') )
    return TRUE;

  if( (a == 'Y') && ( (b == 'C') || (b == 'T') ) )
    return TRUE;

  if( (a == 'R') && ( (b == 'A') || (b == 'G') ) )
    return TRUE;

  if( (a == 'K') && ( (b == 'G') || (b == 'T') ) )
    return TRUE;

  if( (a == 'S') && ( (b == 'C') || (b == 'G') ) )
    return TRUE;

  if( (a == 'W') && ( (b == 'A') || (b == 'T') ) )
    return TRUE;

  if( (a == 'M') && ( (b == 'A') || (b == 'C') ) )
    return TRUE;

  if( (b == 'Y') && ( (a == 'C') || (a == 'T') ) )
    return TRUE;

  if( (b == 'R') && ( (a == 'A') || (a == 'G') ) )
    return TRUE;

  if( (b == 'K') && ( (a == 'G') || (a == 'T') ) )
    return TRUE;

  if( (b == 'S') && ( (a == 'C') || (a == 'G') ) )
    return TRUE;

  if( (b == 'W') && ( (a == 'A') || (a == 'T') ) )
    return TRUE;

  if( (b == 'M') && ( (a == 'A') || (a == 'C') ) )
    return TRUE;

  return FALSE;
}
/*---------------------------------------------------------------------*/
int compare_sequence(char *s1,char *s1a,char *s2)
{
  int n,i;
  char flip[4196];

  /* printf("\nComparing %s and %s to %s\n",s1,s1a,s2);  */
  n = strlen(s1);
  if((int)strlen(s2) != n)
    return 0;

  for(i=0;i<n;i++)
    if(compare_base(s1[i],s2[i]) == FALSE)
    {
	reverse_transcribe(s1a,flip,n);
	for(i=0;i<n;i++)
	  if(compare_base(flip[i],s2[i]) == FALSE)
	    return 0;

	return -1;
    }

  return 1;
}

/*---------------------------------------------------------------------*/


int convert_seq_int(char *seq,int n)
{
  int i, this_mer;

  this_mer = 0;
  for(i=0;i<n;i++)
  {
      this_mer = this_mer << 2;
      
      if(seq[i] == 'C')
	this_mer += 1;
      else
	if(seq[i] == 'G')
	  this_mer += 2;
	else
	  if(seq[i] == 'T')
	    this_mer += 3;
  }

  return this_mer;

}

/*---------------------------------------------------------------------*/

void convert_int_basepairs(int i,char *s,int k)
{
  int j,l;
  char ss[256];

  l = k-1;
  for(j=0;j<256;j++)
    ss[j] = 'A';

  while(l >= 0)
  {
      j = i % 4;
      if(j == 0)
	ss[l] = 'A';
      else
	if(j == 1)
	  ss[l] = 'C';
	else
	  if(j == 2)
	    ss[l] = 'G';
	  else
	    ss[l] = 'T';
      i -= j;
      i /= 4;
      l--;
  }

  ss[k] = '\0';
  strcpy(s,ss);
  
}
/*---------------------------------------------------------------------*/
void decode_basepairs(unsigned char *s,char *dest,int n)
{
  int i,m,l;
  unsigned char j;
  char a,ss[5];

  ss[5] = '\0';
  for(i=0;i<n;i++)
  {
      j = s[i];

      /* printf("\n Decoding %d ",j); */
      for(l=3;l>=0;l--)
      {
	  m = j % 4;
	  if(m == 0)
	    a = 'A';
	  else
	    if(m==1)
	      a = 'C';
	    else
	      if(m==2)
		a = 'G';
	      else
		a = 'T';
	  
	  ss[l] = a;
	  j = j >> 2;;

      }

      for(m=0;m<4;m++)
	*dest++ = ss[m];

      /* printf("as %s",ss); */
  }
}
/*---------------------------------------------------------------------*/
unsigned int encode_basepairs(char *ss,int n)
{
  unsigned int k;
  int i;

  k = 0;
  for(i=0;i<n;i++)
  {
      k = k << 2;
      if(ss[i] == 'A') ;
      else
	if(ss[i] == 'C')
	  k++;
	else
	  if(ss[i] == 'G')
	    k+=2;
	  else
	    k+=3;
  }

  /* printf("\nn = %d Encoding %c%c%c%c as %d ",n,ss[0],ss[1],ss[2],ss[3],k);  */


  return k;
}
/*---------------------------------------------------------------------*/
int check_watson_crick(char a, char b)
{
  if(a=='A') 
  {	 
    if(b=='T')
      return TRUE;
    else
      return FALSE;
  }
  if(a=='T')
  { 
    if(b=='A')
      return TRUE;
    else
      return FALSE;
  }

  if(a=='G') 
  {	  
    if(b=='C')
      return TRUE;
    else
      return FALSE;
  }
  if(a=='C') 
  {	  
    if(b=='G')
      return TRUE;
    else
      return FALSE;
  }
  return FALSE;
}
/*---------------------------------------------------------------------*/
void reverse_string(char *contig, char *s, int n)
{
  int i;
  
  for(i=n-1;i>-1;i--)
  {
      *s++ = *(contig+i);
  }

}
/*---------------------------------------------------------------------*/
void convert_ct(char *s,int n)
{
  int i;
  for(i=0;i<n;i++)
    if(s[i] == 'C')
      s[i] = 'T';
  
}
/*---------------------------------------------------------------------*/
void reverse_transcribe(char *contig, char *s, int n)
{
  int i;
  char c;
  
  for(i=n-1;i>-1;i--)
  {
      if(*(contig+i) == 'A')
	c = 'T';
      else
      if(*(contig+i) == 'C')
	c = 'G';
      else
      if(*(contig+i) == 'G')
	c = 'C';
      else
      if(*(contig+i) == 'T')
	c = 'A';
      else
      if(*(contig+i) == 'W')
	c = 'W';
      else
      if(*(contig+i) == 'S')
	c = 'S';
      else
      if(*(contig+i) == 'K')
	c = 'M';
      else
      if(*(contig+i) == 'M')
	c = 'K';
      else
      if(*(contig+i) == 'Y')
	c = 'R';
      else
      if(*(contig+i) == 'R')
	c = 'Y';
      else
	c = 'N';
      *s++ = c;
  }
  *s = '\0';

}
/*---------------------------------------------------------------------*/
void transcribe(char *contig, char *s, int n)
{
  int i;
  char c;
  
  for(i=0;i<n;i++)
  {
      if(*(contig+i) == 'A')
	c = 'T';
      else
      if(*(contig+i) == 'C')
	c = 'G';
      else
      if(*(contig+i) == 'G')
	c = 'C';
      else
      if(*(contig+i) == 'T')
	c = 'A';
      else
      if(*(contig+i) == 'W')
	c = 'W';
      else
      if(*(contig+i) == 'S')
	c = 'S';
      else
      if(*(contig+i) == 'K')
	c = 'M';
      else
      if(*(contig+i) == 'M')
	c = 'K';
      else
      if(*(contig+i) == 'Y')
	c = 'R';
      else
      if(*(contig+i) == 'R')
	c = 'Y';
      else
	c = 'N';
      *s++ = c;
  }
  *s = '\0';

}
/*---------------------------------------------------------------------*/

int ishetero(char a)
{
  char A;

  A = toupper(a);

  if( (A == 'R') || (A == 'Y') || (A == 'K') || (A == 'M') || (A == 'S') || (A == 'W') )
    return TRUE;

  return FALSE;
}
/*---------------------------------------------------------------------*/
int mystrcmp(const void *a,const void *b)
{
  return strcmp(*((char **)a),*((char **)b));
}
/*---------------------------------------------------------------------*/

int sort_unsigned_int(const void *a,const void *b)
{
        if(*((unsigned int *)a)<*((unsigned int *)b))
                return -1;
        else
        if(*((unsigned int *)a)>*((unsigned int *)b))
                return 1;
        else
                return 0;
}

/*---------------------------------------------------------------------*/
int sort_unsigned_long(const void *a,const void *b)
{
        if(*((unsigned long *)a)<*((unsigned long *)b))
                return -1;
        else
        if(*((unsigned long *)a)>*((unsigned long *)b))
                return 1;
        else
                return 0;
}
/*---------------------------------------------------------------------*/
int sort_compare(const void *a,const void *b)
{
        if(*((double *)a)<*((double *)b))
                return -1;
        else
        if(*((double *)a)>*((double *)b))
                return 1;
        else
                return 0;
}
/*---------------------------------------------------------------------*/

void set_next(char *sss,int *i, int *j)
{
	
	while(!(isalnum(sss[*i]) || (sss[*i] == '(') || (sss[*i] == '*') || (sss[*i] == '-')) )
		(*i)++;
	*j = *i;
 	while( (sss[*j] != '\t') && (sss[*j] != '\n') && (sss[*j] != '\0'))
		(*j)++;
	sss[*j] = '\0';
	/* printf("\n %s",&sss[*i]); */
}
/*---------------------------------------------------------------------*/

/*---------------------------------------------------------------------*/

void read_var(char *line,char *result)
{
 
	char line1[256];  
	int i;

	sprintf(line1,"%s",line);
	printf("%s",line1);
	fgets(result,250,stdin);
	result[strlen(result)-1] = '\0';
	/* printf("\n You entered %s which is %d characters int\n",result,strlen(result)); */
	if(outfile != stdout)
	{
		for(i=0;i<(int)minim(strlen(line1),255);i++)
			if(line1[i] == '\n')
				line1[i] = '\0';
		fprintf(outfile,"\"%s\",%s\n",line1,result);
	} 
}
 
/*---------------------------------------------------------------------*/

char *cvector(int nl,int nh)
{
	char *v;
 
	v=(char *)malloc((unsigned) (nh-nl+1)*sizeof(char));
	if (!v) nrerror("allocation failure in cvector()");
	return v-nl;
}

unsigned char *ucvector(int nl,int nh)
{
	unsigned char *v;
 
	v=(unsigned char *)malloc((unsigned) (nh-nl+1)*sizeof(unsigned char));
	if (!v) nrerror("allocation failure in ucvector()");
	return v-nl;
}

unsigned long long *ullvector(int nl,int nh)
{
	unsigned long long *v;
 
	v=(unsigned long long *)malloc((unsigned) (nh-nl+1)*sizeof(unsigned long long));
	if (!v) nrerror("allocation failure in ullvector()");
	return v-nl;
}

int *ivector(int nl,int nh)
{
	int *v;
 
	v=(int *)malloc((unsigned) (nh-nl+1)*sizeof(int));
	if (!v) nrerror("allocation failure in ivector()");
	return v-nl;
}

unsigned int *uvector(int nl,int nh)
{
	unsigned int *v;
 
	v=(unsigned int *)malloc((unsigned) (nh-nl+1)*sizeof(int));
	if (!v) nrerror("allocation failure in ulvector()");
	return v-nl;
}

unsigned long *ulvector(int nl,int nh)
{
	unsigned long *v;
 
	v=(unsigned long *)malloc((unsigned) (nh-nl+1)*sizeof(long));
	if (!v) nrerror("allocation failure in ulvector()");
	return v-nl;
}

double *dvector(int nl, int nh)
{
	double *v;
 
	v=(double *)malloc((unsigned) (nh-nl+1)*sizeof(double));
	if (!v) nrerror("allocation failure in dvector()");
	return v-nl;
}
 
 
int **imatrix(int nrl,int nrh,int ncl,int nch)
{
	int i,**m;

	m=(int **)malloc((unsigned) (nrh-nrl+1)*sizeof(int*));
	if (!m) nrerror("allocation failure 1 in imatrix()");
	m -= nrl;

	for(i=nrl;i<=nrh;i++) {
		m[i]=(int *)malloc((unsigned) (nch-ncl+1)*sizeof(int));
		if (!m[i]) nrerror("allocation failure 2 in imatrix()");
		m[i] -= ncl;
	}
	return m;
}

unsigned int **umatrix(int nrl,int nrh,int ncl,int nch)
{
        int i;
	unsigned int **m;

	m=(unsigned int **)malloc((unsigned) (nrh-nrl+1)*sizeof(unsigned int*));
	if (!m) nrerror("allocation failure 1 in ulmatrix()");
	m -= nrl;

	for(i=nrl;i<=nrh;i++) {
		m[i]=(unsigned int *)malloc((unsigned) (nch-ncl+1)*sizeof(unsigned int));
		if (!m[i]) nrerror("allocation failure 2 in ulmatrix()");
		m[i] -= ncl;
	}
	return m;
}

unsigned long **ulmatrix(int nrl,int nrh,int ncl,int nch)
{
        int i;
	unsigned long **m;

	m=(unsigned long **)malloc((unsigned) (nrh-nrl+1)*sizeof(unsigned long*));
	if (!m) nrerror("allocation failure 1 in ulmatrix()");
	m -= nrl;

	for(i=nrl;i<=nrh;i++) {
		m[i]=(unsigned long *)malloc((unsigned) (nch-ncl+1)*sizeof(unsigned long));
		if (!m[i]) nrerror("allocation failure 2 in ulmatrix()");
		m[i] -= ncl;
	}
	return m;
}

void free_umatrix(unsigned int **m,int nrl,int nrh,int ncl,int nch)
{
	int i;

	for(i=nrh;i>=nrl;i--) free((void *) (m[i]+ncl));
	free((void *) (m+nrl));
}


void free_ulmatrix(unsigned long **m,int nrl,int nrh,int ncl,int nch)
{
	int i;

	for(i=nrh;i>=nrl;i--) free((void *) (m[i]+ncl));
	free((void *) (m+nrl));
}


void free_imatrix(int **m,int nrl,int nrh,int ncl,int nch)
{
	int i;

	for(i=nrh;i>=nrl;i--) free((void *) (m[i]+ncl));
	free((void *) (m+nrl));
}

 
double **dmatrix(int nrl,int nrh,int ncl,int nch)
{
	int i;
	double **m;
 
	m=(double **) malloc((unsigned) (nrh-nrl+1)*sizeof(double*));
	if (!m) nrerror("allocation failure 1 in dmatrix()");
	m -= nrl;
 
	for(i=nrl;i<=nrh;i++) {
		m[i]=(double *) malloc((unsigned) (nch-ncl+1)*sizeof(double));
		if (!m[i]) nrerror("allocation failure 2 in dmatrix()");
		m[i] -= ncl;
	}
	return m;
}
 
void free_dmatrix(double **m,int nrl,int nrh,int ncl,int nch)
{
	int i;
 
	for(i=nrh;i>=nrl;i--) free((void *) (m[i]+ncl));
	free((void *) (m+nrl));
}

char **cmatrix(int nrl,int nrh,int ncl,int nch)
{
	int i;
	char **m;
 
	m=(char **) malloc((unsigned) (nrh-nrl+1)*sizeof(char*));
	if (!m) nrerror("allocation failure 1 in cmatrix()");
	m -= nrl;
 
	for(i=nrl;i<=nrh;i++) {
		m[i]=(char *) malloc((unsigned) (nch-ncl+1)*sizeof(char));
		if (!m[i]) nrerror("allocation failure 2 in cmatrix()");
		m[i] -= ncl;
	}
	return m;
}


unsigned char **ucmatrix(int nrl,int nrh,int ncl,int nch)
{
	int i;
	unsigned char **m;
 
	m=(unsigned char **) malloc((unsigned) (nrh-nrl+1)*sizeof(unsigned char*));
	if (!m) nrerror("allocation failure 1 in cmatrix()");
	m -= nrl;
 
	for(i=nrl;i<=nrh;i++) {
		m[i]=(unsigned char *) malloc((unsigned) (nch-ncl+1)*sizeof(unsigned char));
		if (!m[i]) nrerror("allocation failure 2 in cmatrix()");
		m[i] -= ncl;
	}
	return m;
}


 
void free_cmatrix(char **m,int nrl,int nrh,int ncl,int nch)
{
	int i;
 
	for(i=nrh;i>=nrl;i--) free((void *) (m[i]+ncl));
	free((void *) (m+nrl));
}

 
void free_ucmatrix(unsigned char **m,int nrl,int nrh,int ncl,int nch)
{
	int i;
 
	for(i=nrh;i>=nrl;i--) free((void *) (m[i]+ncl));
	free((void *) (m+nrl));
}
 
void free_cvector(char *v, int nl, int nh)
{
	free((void *) (v+nl));
}

void free_ucvector(unsigned char *v, int nl, int nh)
{
	free((void *) (v+nl));
}

 
void free_ivector(int *v, int nl, int nh)
{
	free((void *) (v+nl));
}

void free_ulvector(unsigned long *v, int nl, int nh)
{
	free((void *) (v+nl));
}

void free_uvector(unsigned int *v, int nl, int nh)
{
	free((void *) (v+nl));
}
 
void free_dvector(double *v, int nl,int nh)
{
	free((void *) (v+nl));
}
 
/*---------------------------------------------------------------------*/
/*---------------------------------------------------------------------*/

void nrerror(char *error_text)
{
 
	fprintf(outfile,"Numerical Recipes run-time error...\n");
	fprintf(outfile,"%s\n",error_text);
	fprintf(outfile,"...now exiting to system...\n");
	exit(1);
}

/*---------------------------------------------------------------------*/


