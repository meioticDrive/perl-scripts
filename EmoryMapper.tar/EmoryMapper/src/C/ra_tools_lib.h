double **dmatrix(int nrl,int nrh,int ncl,int nch);
void free_dmatrix(double **m,int nrl,int nrh,int ncl,int nch);

double *dvector(int nl, int nh);
void free_dvector(double *v, int nl,int nh);

int **imatrix(int nrl,int nrh,int ncl,int nch);
void free_imatrix(int **m,int nrl,int nrh,int ncl,int nch);

int *ivector(int nl,int nh);
void free_ivector(int *v, int nl, int nh);

unsigned short *usvector(int nl,int nh);
void free_usvector(unsigned short *v, int nl, int nh);

char **cmatrix(int nrl,int nrh,int ncl,int nch);
void free_cmatrix(char **m,int nrl,int nrh,int ncl,int nch);

char *cvector(int nl,int nh);
void free_cvector(char *v, int nl,int nh);

unsigned char **ucmatrix(int nrl,int nrh,int ncl,int nch);
void free_ucmatrix(unsigned char **m,int nrl,int nrh,int ncl,int nch);

unsigned short **usmatrix(int nrl,int nrh,int ncl,int nch);
void free_usmatrix(unsigned short **m,int nrl,int nrh,int ncl,int nch);

void dump_error(char *error_text);

void read_var(char *line,char *result);

void set_next(char *sss,int *i, int *j);

int round_dave(double x);

int sort_compare(const void *a,const void *b);

char watson_crick_compliment(int a);

inline unsigned short endian( unsigned short s);

#define TRUE 1
#define FALSE 0
#define SQR(a) ((a)*(a))
#define minim(a,b) ((a<b)?a:b)
#define maxim(a,b) ((a>b)?a:b)
