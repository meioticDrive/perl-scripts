/* 
ra_popgen_caller is software developed for the Drosophila Population
Genomics Project.  This assumes that ra_basecaller has already
been run.  It attempts to improve call rates by using population
genetics information in a bayesian framework.

The code itself is Copyright (C) 2009, by David J. Cutler.  The 
basic design and approach is due to Kristian Stevens, Chuck Langley, 
and Dave Cutler.  The current code developers and maintainers is 
Dave Cutler 

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.
This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.
You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "basecaller_from_pileup_bbd.h"

FILE *innfile,*outfile,**fastafile;
FILE *snpfile;
int HAPLOID,max_configs,max_gen,min_depth_needed;
char fragment[1024];
int expos;
double Wc;
int gen_to_int(char c);
char int_to_gen(int c);
void count_alleles(CNODE *cn,int *alleles,int *hets,int ref);
void fill_prior(CNODE *cn,double theta,double **HW,int asize, double Wc,int ref);
int clean_config_probs(CNODE **cn, SAMNODE **sn, int n, int max,int max_gen,int **alpha,double *coef,int indiv,int depth,int ref);
int sort_configs(const void *a,const void *b);
int fill_config_probs(CNODE **cn, int n, SAMNODE *sn, int max,int **alpha,double *coef,int indiv,int this_depth);
void make_initial_call(SAMNODE *sm, int haploid,int min_needed);
SAMNODE *sample_alloc();
CNODE *config_alloc(int N);
void config_free(CNODE *tn,int N);
void fill_hardy_weinberg(double **exact_HW,int asize,int n);
void fill_alpha_prior(int **alpha,int max_gen,int hom,int het,int ref);
void fill_alpha_coef(int **alpha,double *coef,int max_gen);
void fill_hom_like(CNODE *cn, SAMNODE **sn, int n,int **alpha,double *coef);
double gammln(double xx);
double exactfactln(int n);
double factln(int n);
void check_alpha_sanity(int **alpha_prior,int max,int **first_alpha_prior,int ref,double **weight);
void get_het_alleles(int i, int *a, int *b,int ref);
int get_snp_type(SAMNODE *sm,double cover,int ref,char *minor);

#define REF_ALLELE 0
#define SNP 1
#define DELETION 2
#define INSERTION 3
#define LOW 4
#define HIGH 5
#define MESS 6

int main()
{
        char ss[512],ss2[512],inname[512];
	char sss[81920],**filename,lastfrag[1024];
	char snp_type[MESS+1][80];
	// char *ref_seq,sdxname[1024];
	// int ref_size;
	double THRESHOLD,theta;
	int asize,ind,INDIV;
	int maxfiles = 5000;
	int i,j,total_configs,fragpos,issnp;
	int dom_int,ii,jj;
	double **HW_exact,*errors,*errors_save;
	double *mean_coverage;
	int **alpha_prior,**first_alpha_prior,**new_alpha;
	int normal_factor;
	int last_pass = 5;
	char dom,minor[80],this_minor[80];
	double **d_alpha_mean,**d_alpha_var,**d_alpha_weight;
	double coef_prior[MAX_GENOTYPES];
	SAMNODE **samples;
	CNODE **configs;
	// FILE *reffile;
	
	outfile = stdout;
	read_var("\nSend Output to Screen, or Disk? [S,D]\n",ss);
 
	if( (strchr(ss,'D')) || (strchr(ss,'d')) )
	{
		read_var("Please Enter File Name for Output\n",ss);
		if((outfile=fopen(ss,"w"))==(FILE *)NULL)
		{
			printf("\n Can not open file %s\n",ss);
			exit(1);
		}
	}
	else
		outfile = stdout;

	read_var("Input File Name\n",inname);
	
	if( (innfile = fopen(inname,"r")) == NULL)
	{
		printf("\n Could Not open %s",inname);
		exit(1);
	}

	sprintf(ss,"%s.snp",inname);
	if((snpfile=fopen(ss,"w"))==(FILE *)NULL)
	{
		printf("\n Can not open file %s for writing\n",ss);
		exit(1);
	}


	/* read_var("Number of individuals \n",ss);
	INDIV = atoi(ss); */
	INDIV = maxfiles;

	filename = cmatrix(0,INDIV,0,1024);

	read_var("Posterior Probability to Make Call\n",ss);
	THRESHOLD = (double)atof(ss);

	read_var("Theta per site\n",ss);	
	theta = (double)atof(ss);
	
	HAPLOID = FALSE;

	read_var("Is this haploid Data [y,n]\n",ss);
	if( (strchr(ss,'Y')) || (strchr(ss,'y')) )
        {
	    HAPLOID = TRUE;
	    max_gen = 6;
	    min_depth_needed = 1;
	}
	else
	{
	    max_gen = MAX_GENOTYPES;
	    min_depth_needed = 8;
	}
	/* read_var("Name of sdx file\n",sdxname);
	if((sfile=fopen(sdxname,"r"))==(FILE *)NULL)
	{
	    printf("\n Can not open file %s\n",sdxname);
	    exit(1);
	}
	if(strstr(sdxname,".sdx") != NULL)
	{
	    for(i=strlen(sdxname)-1;i>0;i--)
	      if(sdxname[i] == '.')
	      {
		  sdxname[i] = '\0';
		  i = 0;
	      }
	}

	sprintf(sss,"%s.seq",sdxname);
	struct stat st;
	stat(sdxname, &st);
	ref_size = st.st_size;
	ref_seq = cvector(0,ref_size);
	
	if((reffile=fopen(sss,"r"))==(FILE *)NULL)
	{
	    printf("\n Can not open file %s for reading\n",sss);
	    exit(1);
	}
	fread(ref_seq,sizeof(char),ref_size,reffile);
	fclose(reffile); */

	/* row 0   =  A
	       1   =  C
	       2   =  G
	       3   =  T
	       4   =  Del
	       5   =  Ins
	       6   =  M  AC
	       7   =  R  AG
 	       8   =  W  AT
	       9   =  S  CG
	       10  =  Y  CT
	       11  =  K  GT
	       12  = Del Het
	       13  = Ins Rre
	*/

	sprintf(snp_type[SNP],"SNP");
	sprintf(snp_type[DELETION],"DEL");
	sprintf(snp_type[INSERTION],"INS");
	sprintf(snp_type[LOW],"LOW_COVER");
	sprintf(snp_type[HIGH],"HIGH_COVER");
	sprintf(snp_type[MESS],"MESS");

	fastafile=(FILE **) malloc((unsigned) (INDIV+1)*sizeof(FILE *));
	if (!fastafile) dump_error("allocation failure 1 in fastafile");

	mean_coverage = dvector(0,INDIV);
	char *token;
	fgets(sss,81919,innfile);
		
	fprintf(snpfile,"Fragment\tPosition\tReference\tMinor_allele\tType");
	token = strtok(sss,"\n\t ");
	// printf("\n token 1 = %s\n\n",token);
	token = strtok(NULL,"\n\t ");
	// printf("\n token 2 = %s\n\n",token);
	token = strtok(NULL,"\n\t ");
	// printf("\n token 3 = %s\n\n",token);
	i = 0;
	while(i < INDIV)
	{
	    token = strtok(NULL,"\n\t ");
	    // printf("\n token i=%d  = %s\n\n",i,token);
	    if(token)
	    {
		strcpy(filename[i],token);
		sprintf(ss2,"%s.fasta",filename[i]);
		if( (fastafile[i] = fopen(ss2,"w")) == NULL)
		{
		    printf("\n Could Not open %s\n\n",ss2);
		    exit(1);
		}
		token = strtok(NULL,"\n\t ");
		mean_coverage[i] = (double)atof(token);
		// printf("\n Found %s for file %d\n\n",filename[i],i);
	    }
	    else
	      INDIV = i;
	    i++;
	}
	for(i=0;i<INDIV;i++)
	  fprintf(snpfile,"\t%s\t",filename[i]);
	printf("\n Found a total of %d individuals\n\n",INDIV);
  	
	if(HAPLOID)
		asize = INDIV+1;
	else
		asize = 2*(INDIV+1);

	Wc = 1.0;	  
	for(i=2;i<asize;i++)
	  Wc += 1.0 / (double) i;	

	HW_exact = dmatrix(0,asize,0,INDIV+1);
	errors = dvector(0,INDIV);
	errors_save = dvector(0,INDIV);
	alpha_prior = imatrix(0,MAX_GENOTYPES-1,0,NO_ALLELES-1);
	first_alpha_prior = imatrix(0,MAX_GENOTYPES-1,0,NO_ALLELES-1);
	new_alpha = imatrix(0,MAX_GENOTYPES-1,0,NO_ALLELES-1);
	d_alpha_mean = dmatrix(0,MAX_GENOTYPES-1,0,NO_ALLELES-1);
	d_alpha_var = dmatrix(0,MAX_GENOTYPES-1,0,NO_ALLELES-1);
	d_alpha_weight = dmatrix(0,MAX_GENOTYPES-1,0,NO_ALLELES-1);

	sprintf(lastfrag,"!!!!!!!");
	fragpos = 0;
	
  	samples = (SAMNODE **)malloc((unsigned)((INDIV+1)*sizeof(SAMNODE *)));
	if(!samples) dump_error("Allocation failure in samples\n");
	for(i=0;i<INDIV;i++)
	  samples[i] = sample_alloc();

	max_configs = 500;

	configs = (CNODE **)malloc((unsigned) (max_gen*(max_configs+1)+1)*sizeof(CNODE *));
	if(!configs) dump_error("Allocation failure in configs\n");
    	
	// printf("\n About to fill HW matrix \n\n");
	if(!HAPLOID)
	  fill_hardy_weinberg(HW_exact,asize,INDIV+1);

	while(feof(innfile) == 0) 
	{
	    /*  Read all the calls and likelihoods */
	    fscanf(innfile,"%s\t%d\t%c",fragment,&expos,&dom);
	    //  printf("\n for fragment = %s  pos = %d Dom = %c\n\n",fragment,expos,dom);
	    // printf("\n Finished filling reference configs \n\n");
	    dom_int = gen_to_int(dom);
	    if(dom_int == 14)
	      dom_int = 0;
	    if(strcmp(lastfrag,fragment) != 0)
	    {
		if( (fragpos % 50 != 0) && (lastfrag[0] != '!' || lastfrag[1] != '!' || lastfrag[2] != '!'))
		  for(ind=0;ind<INDIV;ind++)
		    fprintf(fastafile[ind],"\n");
		strcpy(lastfrag,fragment);
		for(ind=0;ind<INDIV;ind++)
		  fprintf(fastafile[ind],">%s\n",fragment);
		fragpos = 0;
	    }
	    int tot_depth = 0;

	    // printf("\n about to start looping \n\n");

	    for(ind=0;ind<INDIV;ind++)
	    {		
		for(i=0;i<NO_ALLELES;i++)
		  fscanf(innfile,"\t%d",&(samples[ind]->reads[i]));

		samples[ind]->tot = samples[ind]->reads[0];
		for(i=1;i<NO_ALLELES;i++)
		  samples[ind]->tot += samples[ind]->reads[i];
		tot_depth += samples[ind]->tot;
		if(samples[ind]->tot > 0)
		  for(i=0;i<NO_ALLELES;i++)
		    samples[ind]->frac[i] = (double)samples[ind]->reads[i] / (double)samples[ind]->tot;

		// printf("\n Just sucked in data for individual %d  tot = %d %d %d\n\n",ind,samples[ind]->tot,samples[ind]->reads[0],samples[ind]->reads[1]);
		for(i=0;i<max_gen;i++)
		  samples[ind]->post_prob[i] = 0.0;
		samples[ind]->coef = factln(samples[ind]->tot);
		for(i=0;i<NO_ALLELES;i++)
		  samples[ind]->coef -= factln(samples[ind]->reads[i]);
		// printf("\n About to make call \n\n");
		// make_initial_call(samples[ind],HAPLOID,min_depth_needed);
		samples[ind]->initial_call = dom_int;
		// printf("\n Called %c \n\n",int_to_gen(samples[ind]->initial_call));
	    }
	    // printf("\n About to fill prior \n\n");
	    // normal_factor = 20;
	    // normal_factor = 5000;
	    normal_factor = maxim(100,tot_depth / INDIV);
	    fill_alpha_prior(alpha_prior,max_gen,normal_factor,normal_factor/2,dom_int);
	    for(ii=0;ii<max_gen;ii++)
	      for(jj=0;jj<NO_ALLELES;jj++)
		first_alpha_prior[ii][jj] = alpha_prior[ii][jj];
					
	    // printf("\n About to fill coef matrix \n\n");
	    fill_alpha_coef(alpha_prior,coef_prior,max_gen);
	    // printf("\n Back from coef fill \n\n");
	    int calls_changed = TRUE;
	    int pass = 0;
	    while(calls_changed && pass < last_pass)
	    {
		pass++;
		configs[0] = config_alloc(INDIV);
		total_configs = 1;

		/* printf("\n Alpha Matrix\n");
		for(ii=0;ii<max_gen;ii++)
		{
		    for(jj=0;jj<NO_ALLELES;jj++)
		      printf("\t%d",alpha_prior[ii][jj]);
		    printf("\t\t%g\n",coef_prior[ii]);
		} */

		for(ind=0;ind<INDIV;ind++)
		  if(samples[ind]->tot > min_depth_needed)
		  {
		      // printf("\n About to fill config probs \n\n");
		      total_configs = fill_config_probs(configs,total_configs,samples[ind],max_gen,alpha_prior,coef_prior,INDIV,ind);
		      // printf("\n About to clean config probs with total configs = %d\n\n",total_configs);
		      total_configs = clean_config_probs(configs,samples,total_configs,max_configs,max_gen,alpha_prior,coef_prior,INDIV,ind,dom_int);
		      // printf("\n Out of clean config probs with total configs = %d\n\n",total_configs);
		  }
		  else
		  {
		      samples[ind]->final_call = MAX_GENOTYPES;
		      for(i=0;i<max_gen;i++)
			samples[ind]->post_prob[i] = 1.0 / (double)max_gen;
		  }
		// printf("\n About to fill prior with total configs = %d\n\n",total_configs);
		
	 
		double savel = configs[0]->like;
		double tot_prior = 0.0;
		double max_prior = 0.0;
		for(i=0;i<total_configs;i++)
		{
		    fill_prior(configs[i],theta,HW_exact,asize,Wc,dom_int);
		    if(configs[i]->prior > max_prior)
		    {
			tot_prior += max_prior;
			max_prior = configs[i]->prior;
		    }
		    else
		      tot_prior += configs[i]->prior;
		}

		// printf("\n About to do the config probs \n\n");
		double tot_post = 0.0;
		for(i=0;i<total_configs;i++)
		{
		    if(configs[i]->prior < max_prior)
		      configs[i]->prior = (1.0 - max_prior) * configs[i]->prior / tot_prior;
		    configs[i]->like -= savel;
		    configs[i]->post = configs[i]->prior*exp(configs[i]->like);
		    tot_post += configs[i]->post;
		}
		for(ind=0;ind<INDIV;ind++)
		  for(i=0;i<max_gen;i++)
		    samples[ind]->post_prob[i] = 0;

		// printf("\n About to do the sample probs \n\n");
		for(i=0;i<total_configs;i++)
		{
		    configs[i]->post /= tot_post;
		    // printf("\nConfig %d has post %g with prior %g\t",i,configs[i]->post,configs[i]->prior);
		    // int j;
		    // for(j=0;j<max_gen;j++)
		    //  printf(" %d",configs[i]->genotype_count[j]);
		    // for(j=0;j<INDIV;j++)
		    //  printf(" %c",int_to_gen(configs[i]->sample_calls[j])); 

		    for(ind=0;ind<INDIV;ind++)
		      if(samples[ind]->tot > min_depth_needed)
			samples[ind]->post_prob[(int)configs[i]->sample_calls[ind]] += configs[i]->post;
		}

		// printf("\n About to check if the calls changed \n\n");
		calls_changed = FALSE;
		for(ind=0;ind<INDIV;ind++)
		  if(samples[ind]->tot > min_depth_needed)
		  {
		      int besti = 0;
		      for(i=1;i<max_gen;i++)
			if(samples[ind]->post_prob[i] > samples[ind]->post_prob[besti])
			  besti = i;
		      samples[ind]->final_p = samples[ind]->post_prob[besti];
		      samples[ind]->final_call = besti;
		      if(samples[ind]->final_call != samples[ind]->initial_call)
			calls_changed = TRUE;
		  }

		if(INDIV < 4 || pass == last_pass)
		  calls_changed = FALSE;

		if(calls_changed)
		{
		    for(ii=0;ii<max_gen;ii++)
		      for(jj=0;jj<NO_ALLELES;jj++)
			d_alpha_weight[ii][jj] = d_alpha_mean[ii][jj] = d_alpha_var[ii][jj] = (double)0.0;
		    
		    // printf("\n Calls have changed.  Recalculating alpha matrix  with total_configs = %d\n\n",total_configs);
		    for(i=0;i<total_configs;i++)
			for(ind=0;ind<INDIV;ind++)
			  if(samples[ind]->tot > min_depth_needed)
			    for(j=0;j<NO_ALLELES;j++)
			    {
				// printf("\n Working on individual %d of %d and allele %d of %d which is called %d\n\n",ind,INDIV,j,NO_ALLELES,configs[i]->sample_calls[ind]);
				d_alpha_mean[(int)configs[i]->sample_calls[ind]][j] += samples[ind]->frac[j]*configs[i]->post;
				d_alpha_var[(int)configs[i]->sample_calls[ind]][j] += (samples[ind]->frac[j]*samples[ind]->frac[j])*configs[i]->post;
				d_alpha_weight[(int)configs[i]->sample_calls[ind]][j] += configs[i]->post;
				// d_alpha_mean[(int)configs[i]->sample_calls[ind]][j] += samples[ind]->frac[j];
				// d_alpha_var[(int)configs[i]->sample_calls[ind]][j] += (samples[ind]->frac[j]*samples[ind]->frac[j]);
				// d_alpha_weight[(int)configs[i]->sample_calls[ind]][j] += 1.0;
			    }	      
		    // printf("\n About to finish average calcs \n\n");
		    for(ii=0;ii<max_gen;ii++)
		      for(jj=0;jj<NO_ALLELES;jj++)
			if(d_alpha_weight[ii][jj] > 1e-9)
			{
			    d_alpha_mean[ii][jj] /= d_alpha_weight[ii][jj];
			    d_alpha_var[ii][jj] /= d_alpha_weight[ii][jj];
			    d_alpha_var[ii][jj] -= d_alpha_mean[ii][jj]*d_alpha_mean[ii][jj];
			}

		    double var_eps = 1e-6;	
		    for(ii=0;ii<max_gen;ii++)
		    {
			int non_zero_var = 0;
			int this_min = 0;

			for(jj=0;jj<NO_ALLELES;jj++)
			{
			    if(d_alpha_weight[ii][jj] >= 1.5 && d_alpha_var[ii][jj] > var_eps*d_alpha_mean[ii][jj])
			      non_zero_var++;
			    if(d_alpha_mean[ii][jj] < d_alpha_mean[ii][this_min])
			      this_min = jj;
			    // printf("\n For ii = %d jj = %d  mean = %g  var = %g  weight = %g",ii,jj,d_alpha_mean[ii][jj],d_alpha_var[ii][jj],d_alpha_weight[ii][jj]);
			}
			if(non_zero_var > 1)
			{
			    double s0 = 1.0;
			    for(jj=0;jj<NO_ALLELES;jj++)
			      if(jj != this_min && d_alpha_var[ii][jj] > var_eps*d_alpha_mean[ii][jj])
				s0 *= d_alpha_mean[ii][jj]*(1.0 - d_alpha_mean[ii][jj]) / d_alpha_var[ii][jj];
			    s0 = pow(s0-1.0,(double)1.0/(double)(non_zero_var-1.0));
			    if(s0>3.0)
			      for(jj=0;jj<NO_ALLELES;jj++)
				alpha_prior[ii][jj] = maxim(1,(int)ceil(d_alpha_mean[ii][jj]*s0));
			    else
			      for(jj=0;jj<NO_ALLELES;jj++)
				alpha_prior[ii][jj] = first_alpha_prior[ii][jj];
			}
			else
			  for(jj=0;jj<NO_ALLELES;jj++)
			    alpha_prior[ii][jj] = first_alpha_prior[ii][jj];
		    }
		    check_alpha_sanity(alpha_prior,max_gen,first_alpha_prior,dom_int,d_alpha_weight);
		    // printf("\n Alpha Matrix\n");
		    // for(ii=0;ii<max_gen;ii++)
		    // {
		    // for(jj=0;jj<NO_ALLELES;jj++)
		    //	  printf("\t%d",alpha_prior[ii][jj]);
		    //	printf("\t\t\n");
		    //}
		    // printf("\n About to calculate coefficients \n\n");
		    fill_alpha_coef(alpha_prior,coef_prior,max_gen);
		    
		    for(ind=0;ind<INDIV;ind++)
		      samples[ind]->initial_call = samples[ind]->final_call;
		}
		
		// printf("\n About to free stuff\n\n");
		for(i=0;i<total_configs;i++)
		  config_free(configs[i],INDIV);
	    }

	    fprintf(outfile,"%s\t%d\t%c",fragment,expos,dom);
	    issnp = REF_ALLELE;
	    sprintf(minor,"N");
	    for(ind=0;ind<INDIV;ind++)
	      if(samples[ind]->tot > min_depth_needed)
	      {
		  
		  fprintf(outfile,"\t%c\t%g",int_to_gen(samples[ind]->final_call),samples[ind]->final_p);

		  /* if(expos == 9911)
		     printf("\nFragment = %s Pos=%d Ind = %d call=%c score = %g threshold = %g issnp = %d",
		     fragment,expos,ind,model_call[ind],model_score[ind],THRESHOLD,issnp); */
		  
		  if(samples[ind]->final_p >= THRESHOLD)
		  {
		      fprintf(fastafile[ind],"%c",int_to_gen(samples[ind]->final_call));
		      if(samples[ind]->final_call != dom_int && issnp != MESS)
		      {
			  
			  int this_site = get_snp_type(samples[ind],mean_coverage[ind],dom_int,this_minor);
			  if(issnp == REF_ALLELE)
			    issnp = this_site;
			  else
			    if(issnp != this_site)
			    {
				if(this_site <= INSERTION && issnp <= INSERTION)
				  issnp = MESS;
				else
				  if(issnp > INSERTION && this_site <= INSERTION)
				    issnp = this_site;
				else
				  if(issnp > INSERTION && this_site > INSERTION)
				    issnp = MESS;
			    }
			  if(issnp < LOW && issnp == this_site)
			    strcpy(minor,this_minor);
		      }
		  }
		  else
		    fprintf(fastafile[ind],"N");

		  if(fragpos%50 == 49)
		    fprintf(fastafile[ind],"\n");
		  // printf("\tNew %c with prob %g  forward = %g  reverse = %g\n",model_call[ind],model_score[ind],total_forward[ind],total_reverse[ind]);
		  //printf("\tNew %c with prob %g\n",model_call[ind],model_score[ind]);
	      }
	      else
	      {
		  fprintf(outfile,"\tN\t0");
		  samples[ind]->final_call = MAX_GENOTYPES;
		  fprintf(fastafile[ind],"N");
		  if(fragpos%50 == 49)
		    fprintf(fastafile[ind],"\n");
	      }
	    if(issnp)
	    {
		fprintf(snpfile,"\n%s\t%d\t%c\t%s\t%s",fragment,expos,dom,minor,snp_type[issnp]);
		for(ind=0;ind<INDIV;ind++)
		  fprintf(snpfile,"\t%c\t%g",int_to_gen(samples[ind]->final_call),samples[ind]->final_p);
	    }
	    
	    // fprintf(outfile,"\n fragpos = %d",fragpos);
	    fprintf(outfile,"\n");
	    fragpos++;
	    // printf("\n About to free configs with total_configs = %d \n\n",total_configs);
	    fscanf(innfile,"\n");
	    // printf("\n Done Freeing \n\n");
	}

	for(i=0;i<INDIV;i++)
	{
		fclose(fastafile[i]);
	}

	return 0;
}


/*---------------------------------------------------------------------*/
int get_snp_type(SAMNODE *sm,double cover,int ref,char *minor)
{
  int a,b;

  get_het_alleles(sm->final_call,&a,&b,ref);
  if(a < 4 && b < 4)
  {
      if(a != ref)
	sprintf(minor,"%c",int_to_gen(a));
      else
	sprintf(minor,"%c",int_to_gen(b));
      if((double)sm->tot*4.0 < cover)
	return LOW;
      else
      if((double)sm->tot > cover * 4.0)
	  return HIGH;
      else
	return SNP; 
  }

  sprintf(minor,"-");
  if((double)sm->tot*4.0 < cover)
      return LOW;

  if((double)sm->tot > cover * 4.0)
      return HIGH;

  if(b == 4)
      return DELETION;

  if(b == 5)
      return INSERTION;

  sprintf(minor,"-");
  return MESS;
  
}
/*---------------------------------------------------------------------*/
void check_alpha_sanity(int **alpha_prior,int max_gen,int **first_alpha_prior,int ref,double **weight)
{
  int i,j;
  int max;
  double scale_factor[MAX_GENOTYPES];



  for(i=0;i<4;i++)
  {
      max = 0;
      for(j=1;j<NO_ALLELES;j++)
	if(alpha_prior[i][j] > alpha_prior[i][max])
	  max = j;
      if(max != i)
	for(j=0;j<NO_ALLELES;j++)
	  alpha_prior[i][j] = first_alpha_prior[i][j];
  }

  double frac[MAX_GENOTYPES][NO_ALLELES];
  double temp;
  for(i=0;i<max_gen;i++)
  {
      int tot = alpha_prior[i][0];
      for(j=1;j<NO_ALLELES;j++)
	tot += alpha_prior[i][j];
      for(j=0;j<NO_ALLELES;j++)
	frac[i][j] = (double)alpha_prior[i][j] / (double)tot;
  }

  // Del Homozygote
  i = 4;
  temp = frac[i][i] - frac[ref][i];

  if(temp < 0.5)
    for(j=0;j<NO_ALLELES;j++)
      alpha_prior[i][j] = first_alpha_prior[i][j];
  
  // Ins Homozygote
  i = 5;
  temp = frac[i][i] - frac[ref][i];

  if(temp < 0.7)
    for(j=0;j<NO_ALLELES;j++)
      alpha_prior[i][j] = first_alpha_prior[i][j];

  // printf("\n In check sanity with max = %d \n",max_gen);
  for(i = NO_ALLELES;i<max_gen;i++)
  {
      // HET
      int a,b;
      get_het_alleles(i,&a,&b,ref);
      if(b == ref)
      {
	  int ti;
	  ti = a;	  a = b;	  b = ti;
      }
      if(frac[i][b] - frac[ref][b] < 0.15)
	for(j=0;j<NO_ALLELES;j++)
	  alpha_prior[i][j] = first_alpha_prior[i][j];
      else
      {
	  if(ref == a)
	    frac[i][a] -= 0.05;
	  else
	    frac[i][a] -= maxim(frac[ref][a],0.05);

	  frac[i][b] -= maxim(0.05,frac[ref][b]);


	  int bad = FALSE;
	  
	  for(j=0;j<NO_ALLELES;j++)
	    if(j != a && j != b)
	      if(frac[i][j] > frac[i][a] || frac[i][j] > frac[i][b])
	      {
		  bad = TRUE;
		  j = NO_ALLELES;
	      }
	  
	  if(bad)
	    for(j=0;j<NO_ALLELES;j++)
	      alpha_prior[i][j] = first_alpha_prior[i][j];
      }
  }

  int max_weight = 0;
  for(i=0;i<max_gen;i++)
  {  
      scale_factor[i] = alpha_prior[i][0];
      for(j=1;j<NO_ALLELES;j++)
	scale_factor[i] += alpha_prior[i][j];
      if(weight[i][0] > weight[max_weight][0])
	max_weight = i;
  }

  for(i=0;i<max_gen;i++)
    if(i != max_weight)
      scale_factor[i] = scale_factor[max_weight] / scale_factor[i];

  for(i=0;i<max_gen;i++)
    if(i != max_weight && weight[i][0] < 4.0)
      for(j=0;j<NO_ALLELES;j++)
	alpha_prior[i][j] = maxim(1,(int)ceil(scale_factor[i]*(double)alpha_prior[i][j]));

}
/*---------------------------------------------------------------------*/
void get_het_alleles(int i, int *a, int *b,int ref)
{
  if(i < NO_ALLELES)
  {
      *a = *b = i;
  }
  else
  if(i == 6)
  {
      *a = 0;
      *b = 1;
  }
  else
  if(i == 7)
  {
      *a = 0;
      *b = 2;
  }
  else
  if(i == 8)
  {
      *a = 0;
      *b = 3;
  }
  else
  if(i == 9)
  {
      *a = 1;
      *b = 2;
  }
  else
  if(i == 10)
  {
      *a = 1;
      *b = 3;
  }
  else
  if(i == 11)
  {
      *a = 2;
      *b = 3;
  }
  else
  if(i == 12)
  {
      *a = ref;
      *b = 4;
  }
  else
  if(i == 13)
  {
      *a = ref;
      *b = 5;
  }
  else
  {
      printf("\n This is impossible in get_het_alleles.  i = %d\n\n",i);
      exit(1);
  }

  return;
}
/*---------------------------------------------------------------------*/
void make_initial_call(SAMNODE *sm, int haploid,int min_needed)
{
  int i,max;

  if(sm->tot < min_needed)
  {
      sm->initial_call = MAX_GENOTYPES;
      return;
  }

  if(haploid)
  {
      max = 0;
      for(i=1;i<NO_ALLELES;i++)
	if(sm->reads[i] > sm->reads[max])
	  max = i;
      
      sm->initial_call = max;
      return;
  }

  int second;

  if(sm->reads[0] >= sm->reads[1])
  {
      max = 0; second = 1;
  }
  else
  {
      max = 1; second = 0;
  }

  for(i=2;i<NO_ALLELES;i++)
    if(sm->reads[i] > sm->reads[max])
    {
	second = max;
	max = i;
    }
    else
      if(sm->reads[i] > sm->reads[second])
	second = i;

  // printf("\n Made it here \n\n");
  int tot = sm->reads[max] + sm->reads[second];
  if((double)sm->reads[max] / (double) tot > 0.65)
  {
      sm->initial_call = max;
      return;
  }

  int del, ins;
  ins = NO_ALLELES - 1;
  del = ins-1;

  if( (max == del && second == ins) || (max == del  && second == ins) ) 
    sm->initial_call = max;
  else
    if( ((max < del) && (second == del))  || ((max == del) && (second < del) ) )
      sm->initial_call = 12;
    else
      if( ((max < del) && (second == ins))  || ((max == ins) && (second < del) ) )
	sm->initial_call = 13;
      else
      {
	  int j;
	  if(max > second)
	  {
	      j = second;
	      second = max;
	      max = j;
	  }
	  sm->initial_call = NO_ALLELES-1;
	  for(i=0;i<max;i++)
	    for(j=i+1;j<4;j++)
	      sm->initial_call++;
	  
	  for(j=max+1;j<=second;j++)
	    sm->initial_call++;
	  // printf("\n With max = %d  second = %d and reads %d %d we call %d",max,second,sm->reads[max],sm->reads[second],sm->initial_call);
      }

  return;
}
/*---------------------------------------------------------------------*/
void count_alleles(CNODE *cn,int *alleles,int *hets,int ref)
{
  int i,j;

  for(i=0;i<NO_ALLELES;i++)
    alleles[i] = 0;

  for(i=0;i<NO_ALLELES;i++)
  {
      hets[i] = 0;
      if(HAPLOID)
	alleles[i] = cn->genotype_count[i];
      else
	alleles[i] = 2*cn->genotype_count[i];
  }


  if(!HAPLOID)
  {
      int a,b;
      for(j=NO_ALLELES;j<MAX_GENOTYPES;j++)
      {
	  get_het_alleles(j,&a,&b,ref);
	  hets[a] += cn->genotype_count[j];
	  hets[b] += cn->genotype_count[j];
	  alleles[a] += cn->genotype_count[j];
	  alleles[b] += cn->genotype_count[j];
      }
  }

}
/*---------------------------------------------------------------------*/
void fill_prior(CNODE *cn,double theta,double **HW,int asize, double Wc,int ref)
{

  int alleles[NO_ALLELES],i,major,lm,minor,acount,hh,hets[NO_ALLELES];

  count_alleles(cn,alleles,hets,ref);

  lm = major = minor = acount = 0;
  hh = hets[lm];
  for(i=0;i<NO_ALLELES;i++)
  {
      if(alleles[i] > 0)
	acount++;
      if(alleles[i] >= major)
      {
	  minor = major;
	  major = alleles[i];
	  hh = hets[lm];
	  lm = i;
      }
      else
	if(alleles[i] > minor)
	{
	    minor = alleles[i];
	    hh = hets[i];
	}
  }

  if(acount > 2)
	cn->prior = theta*theta;
  else
    if(acount == 2)
      cn->prior = theta*(1.0/(double)minor + 1.0/((double)(asize-minor)));
    else
      cn->prior = 1.0 - (theta*Wc + theta*theta);

  // printf("\n minor = %d  hets = %d  HW = %g",minor,hh,HW[minor][hh]);
  if( (!HAPLOID) && (acount == 2) )
    cn->prior *= HW[minor][hh];

  return;
}
/*---------------------------------------------------------------------*/
int clean_config_probs(CNODE **cn, SAMNODE **sn, int n, int max,int max_gen,int **alpha,double *coef,int indiv,int depth,int ref)
{
  int i,j;
  qsort(cn,n,sizeof(CNODE *),sort_configs);
  /* for(i=0;i<n;i++)
  {
	printf("\n For configuration %d like = %g",i,cn[i]->like);
	int j;
	for(j=0;j<max_gen;j++)
		printf(" %d",cn[i]->genotype_count[j]); 
	printf("\n\n");
	} */
  max = minim(max,n);
  for(i=1;i<max;i++)
    if(cn[0]->like > cn[i]->like + 10)
      max = i;

  for(i=max;i<n;i++)
    config_free(cn[i],indiv);

  int found_hom = FALSE;
  int tot,max_hom;
  for(i=0;i<max;i++)
  {
      max_hom = tot = 0;
      for(j=0;j<NO_ALLELES;j++)
      {
	  tot += cn[i]->genotype_count[j];
	  max_hom = maxim(max_hom,cn[i]->genotype_count[j]);
      }
      for(j=NO_ALLELES;j<max_gen;j++)
	tot += cn[i]->genotype_count[j];
      if(max_hom == tot)
      {
	  found_hom = TRUE;
	  i = max;
      }
  }

  // fprintf(outfile,"\n Finished first round of cleaning, with max = %d and found_hom = %d \n",max,found_hom);
  if(!found_hom)
  {
      int best_hom = 0;
      for(i=1;i<NO_ALLELES;i++)
	if(cn[0]->genotype_count[i] > cn[0]->genotype_count[best_hom])
	  best_hom = i;
      if(best_hom > 3)
	best_hom = ref;
      cn[max] = config_alloc(indiv);
      cn[max]->genotype_count[best_hom] = depth+1;
      for(i=0;i<=depth;i++)
	cn[max]->sample_calls[i] = best_hom;
      fill_hom_like(cn[max],sn,depth,alpha,coef);
      max++;
  }
  return max;
}
/*---------------------------------------------------------------------*/
void fill_hom_like(CNODE *cn, SAMNODE **sn, int n,int **alpha,double *coef)
{
  int i, j, ii;
  double prob;

  cn->like = 0;
  for(i=0;i<=n;i++)
    if(sn[i]->tot >= min_depth_needed)
    {
	j = cn->sample_calls[i];
	prob = sn[i]->coef + coef[j];
	int tot = 0;
	for(ii=0;ii<NO_ALLELES;ii++)
	  {
	    prob += factln(alpha[j][ii]+sn[i]->reads[ii]-1);
	    tot += alpha[j][ii] + sn[i]->reads[ii];
	  }
	prob -= factln(tot-1);
	cn->like += prob;
    } 
}
/*---------------------------------------------------------------------*/
int sort_configs(const void *a,const void *b)
{
  CNODE *fa, *fb;
  
  fa = *((CNODE **)a);
  fb = *((CNODE **)b);

  if(fa->like > fb->like)
    return -1;
  else
    if(fa->like < fb->like)
      return 1;
    else
      return 0;
}
/*---------------------------------------------------------------------*/
int fill_config_probs(CNODE **cn, int n, SAMNODE *sn, int max,int **alpha,double *coef,int indiv,int this_depth)
{
  int i,j,k,newcount,ii;
  CNODE *temp,*old,**new;
  double prob;
  
  newcount = 0;
  new = (CNODE **)malloc((unsigned) ((max+1)*(n+1)*sizeof(CNODE *)));
  if(!new) dump_error("Allocation failure in fill_config_probs\n");
  // printf("\n Entering fill_config_probs with n = %d \n\n",n);
  for(i=0;i<n;i++)
  {
      // printf("\n At top of the loop with i=%d and cn[i] = %d\n\n",i,cn[i]);
      old = cn[i];
      for(j=0;j<max;j++)
      {
	  // printf("\n ABout to allocate temp with j = %d \n\n",j);
	  temp = config_alloc(indiv);

	  // printf("\n Copying over \n\n");
	  for(k=0;k<max;k++)
	      temp->genotype_count[k] = old->genotype_count[k];

	  for(k=0;k<this_depth;k++)
	    temp->sample_calls[k] = old->sample_calls[k];

	  temp->genotype_count[j]++;
	  temp->sample_calls[this_depth] = j;
	  prob = sn->coef + coef[j];
	  // printf("\n Calcing Prob \n\n");
	  int tot = 0;
	  for(ii=0;ii<NO_ALLELES;ii++)
	  {
	      prob += factln(alpha[j][ii]+sn->reads[ii]-1);
	      tot += alpha[j][ii] + sn->reads[ii];
	  }
	  prob -= factln(tot-1);
	  temp->like = old->like + prob;
	  // printf("\n j = %d with n = %d newcount = %d Configuration:",j,n,newcount);
	  // for(ii=0;ii<max;ii++)
	  //  printf(" %d",temp->genotype_count[ii]);
	  // printf("\n\tTotal Like = %g  This Prob = %g",temp->like,exp(prob));
	  // for(ii=0;ii<NO_ALLELES;ii++)
	  // printf(" %d",sn->reads[ii]);  
	  // printf("\n About to store \n\n");
	  new[newcount] = temp;
	  newcount++;
      }
      // printf("\n i = %d  about to free old = %d\n\n",i,old);
      config_free(old,indiv);
  }
  for(i=0;i<newcount;i++)
	cn[i] = new[i];
  free(new);

  // printf("\n About to leave with newcount = %d\n\n",newcount);

  return newcount;
    
}
/*---------------------------------------------------------------------*/
void fill_hardy_weinberg(double **exact_HW,int asize,int n)
{
  double **marg,sum,p;
  int i,j,naa,nab,nbb,Na,Nb,start,expect;
  
  // printf("\n Entering fill_hardy_weinberg with asize = %d\n\n",asize);
  marg = dmatrix(0,asize,0,n);
  for(i=0;i<=asize;i++)
    for(j=0;j<=n;j++)
      exact_HW[i][j] = marg[i][j] = 0.0;


  for(i=1;i<=asize;i++)
  {
      Na = 2*n - i;
      Nb = i;
      p = (double)i/(double)(Na+Nb);
      expect = ceil(i*(1.0-p));
      
      if(i%2 == 0)
      {
	  if(expect%2 == 1)
	    start = expect -1;
	  else
	    start = expect;
      }
      else
      {
	  if(expect%2 == 1)
	    start = expect;
	  else
	    start = expect-1;
      }
      // printf("\ni=%d expect = %d  start = %d p = %g ",i,expect,start,p);
      sum = marg[i][start] = 1.0;

      nbb = ((Nb-start)/2);
      naa = ((Na-start)/2);

      // printf("\n naa = %d nbb = %d nab = %d  Nb = %d  Na = %d",naa,nbb,start+2,Nb,Na);
      for(nab=start+2;naa > 0 && nbb > 0;nab+=2,naa--,nbb--)
      {
	  marg[i][nab] = marg[i][nab-2] * 4.0 * ((double)naa*(double)nbb) / ((double)(nab) * (double)(nab-1.0) );
	  // printf("\n nab = %d last = %g  current = %g",nab,marg[i][nab-2],marg[i][nab]);
	  sum += marg[i][nab];
      }

      nbb = ((Nb-start)/2);
      naa = ((Na-start)/2);

      for(nab=start-2;nab>=0;nab-=2,naa++,nbb++)
      {
	  marg[i][nab] = marg[i][nab+2] * ((double)(nab+2.0) * (double)(nab+1.0) ) / ( (double)4.0*((double)(naa+1.0)*(nbb+1.0)));
	  sum += marg[i][nab];
      }
      
      for(j=0;j<=n;j++)
	marg[i][j] /= sum;
  }
  for(i=0;i<=asize;i++)
      for(j=0;j<=n;j++)
	{
	  exact_HW[i][j] = marg[i][j];
	  // printf("\n i = %d  j = %d  p = %g",i,j,exact_HW[i][j]);
	}
  // exit(1);   
  free_dmatrix(marg,0,asize,0,n);
}

/*---------------------------------------------------------------------*/
int gen_to_int(char c)
{
  if(c == 'A') return 0;
  if(c == 'C') return 1;
  if(c == 'G') return 2;
  if(c == 'T') return 3;
  if(c == 'D') return 4;
  if(c == 'I') return 5;
  if(c == 'M') return 6;
  if(c == 'R') return 7;
  if(c == 'W') return 8;
  if(c == 'S') return 9;
  if(c == 'Y') return 10;
  if(c == 'K') return 11;
  if(c == 'E') return 12;
  if(c == 'H') return 13;
  if(c == 'N') return 14;

  printf("\n This is impossible\n Illegal character in gen_to_int %c\n\n",c);
  exit(1);
  return -1;

}
/*---------------------------------------------------------------------*/
char int_to_gen(int c)
{
  if(c == 0) return 'A';
  if(c == 1) return 'C';
  if(c == 2) return 'G';
  if(c == 3) return 'T';
  if(c == 4) return 'D';
  if(c == 5) return 'I';
  if(c == 6) return 'M';
  if(c == 7) return 'R';
  if(c == 8) return 'W';
  if(c == 9) return 'S';
  if(c == 10) return 'Y';
  if(c == 11) return 'K';
  if(c == 12) return 'E';
  if(c == 13) return 'H';

  return 'N';
}

/*---------------------------------------------------------------------*/

SAMNODE *sample_alloc()
{
	SAMNODE *tn;
	int i;

	tn = (SAMNODE *)malloc((unsigned) sizeof(struct sample_node));
	if (!tn) dump_error("allocation failure in sample_alloc()");

	for(i=0;i<=MAX_GENOTYPES;i++)
	  tn->post_prob[i] = 0.0;

	for(i=0;i<NO_ALLELES;i++)
	  tn->reads[i] = 0;
	tn->final_call = MAX_GENOTYPES;
	tn->initial_call = MAX_GENOTYPES;
	tn->final_p = 0.0;
	tn->coef = 0.0;

	return tn;
}

/*---------------------------------------------------------------------*/

CNODE *config_alloc(int N)
{
	CNODE *tn;
	int i;

	tn = (CNODE *)malloc((unsigned) sizeof(struct config_node));
	if (!tn) dump_error("allocation failure in config_alloc()");

	for(i=0;i<MAX_GENOTYPES;i++)
	    tn->genotype_count[i] = 0;

	tn->sample_calls = cvector(0,N-1);
	for(i=0;i<N;i++)
	    tn->sample_calls[i] = (char)MAX_GENOTYPES;

	tn->like = 0;
	tn->prior = 0;
	tn->post = 0;

	return tn;
}
/*---------------------------------------------------------------------*/
void config_free(CNODE *tn,int N)
{
  // printf("\n In free with tn = %d\n\n",tn);
  // printf("\n\t tn->sample_calls =  %d  tn->alpha = %d\n\n",tn->sample_calls,tn->alpha);
  if(!tn)
    return;

  free_cvector(tn->sample_calls,0,N);
  free(tn);
}
/*---------------------------------------------------------------------*/
void fill_alpha_prior(int **alpha,int max_gen,int hom,int het,int ref)
{
  int i,j,k,hom_err,err;


  hom_err = maxim(1,hom/300);
  err = maxim(1,(2*het)/300);

  for(i=0;i<max_gen;i++)
  {
        if(i<NO_ALLELES-2)
	  for(j=0;j<NO_ALLELES;j++)
	    if(i == j)
	      alpha[i][j] = hom;
	    else
	      alpha[i][j] = hom_err;
	else
	{
	    j = i;
	    if(j == NO_ALLELES - 2)
	    {
		// Del homozygote
		for(k=0;k<4;k++)
		  if(k == ref)
		    alpha[j][k] = hom/5;
		  else
		    alpha[j][k] = err;
		alpha[j][4] = (4*hom)/5;
		alpha[j][5] = err;
	    }
	    else
	    if(j == NO_ALLELES - 1)
	    {
		// Ins homozygote
		for(k=0;k<4;k++)
		  if(k == ref)
		    alpha[j][k] = hom;
		  else
		    alpha[j][k] = err;
		alpha[j][4] = err;
		alpha[j][5] = (4*hom)/5;
	    } 
	    else
	      if(j < NO_ALLELES+6)
	      {
		  int a,b;
		  get_het_alleles(j,&a,&b,ref);
		  if(a == ref)
		  {
		      alpha[j][a] = (51*het) / 50;
		      alpha[j][b] = (49*het) / 50;
		      alpha[j][4] = maxim(1,het/20);
		      alpha[j][5] = err;
		      for(k=0;k<4;k++)
			if(k != a && k != b)
			  alpha[j][k] = err;
		  }
		  else
		    if(b == ref)
		    {
			alpha[j][b] = (51*het) / 50;
			alpha[j][a] = (49*het) / 50;
			alpha[j][4] = maxim(1,het/20);
			alpha[j][5] = err;
			for(k=0;k<4;k++)
			  if(k != a && k != b)
			    alpha[j][k] = err;
		    }
		    else
		    {
			alpha[j][a] = het;
			alpha[j][b] = het;
			for(k=0;k<NO_ALLELES;k++)
			  if(k != a && k != b)
			    alpha[j][k] = err;
		    }
	      }
	      else
		if(j == NO_ALLELES + 6)
		  {
		    // Del - ref
		    alpha[j][4] = (4*het)/5;
		    alpha[j][ref] = (6*het)/5;
		    for(k=0;k<4;k++)
		      if(k != ref)
			alpha[j][k] = err;
		    alpha[j++][5] = err;
		  }
		else
		  {
		    // Ins - ref
		    alpha[j][5] = (2*het)/5;
		    alpha[j][ref] = (8*het)/5;
		    for(k=0;k<5;k++)
		      if(k != ref)
			alpha[j][k] = err;
		  }
	}
  }
}

/*---------------------------------------------------------------------*/
void fill_alpha_coef(int **alpha,double *coef,int max_gen)
{
  int i,j,tot;

  for(j=0;j<max_gen;j++)
  {
      coef[j] = 0;
      tot  = 0;
      for(i=0;i<NO_ALLELES;i++)
      {
	  tot += alpha[j][i];
	  coef[j] -= factln(alpha[j][i]-1);
      }
      coef[j] += factln(tot-1);
  }

}

/*---------------------------------------------------------------------*/

double gammln(double xx)
{
	double x,tmp,ser;
	static double cof[6]={76.18009173,-86.50532033,24.01409822,
		-1.231739516,0.120858003e-2,-0.536382e-5};
	int j;

	x=xx-1.0;
	tmp=x+5.5;
	tmp -= (x+0.5)*log(tmp);
	ser=1.0;
	for (j=0;j<=5;j++) {
		x += 1.0;
		ser += cof[j]/x;
	}
	return -tmp+log(2.50662827465*ser);
}

/*---------------------------------------------------------------------*/
double exactfactln(int n)
{
  int i;
  double x=1.0;

  for(i=2;i<=n;i++)
    x*=(double)i;

  return log(x);
}
/*---------------------------------------------------------------------*/

double factln(int n)
{
	static double a[10001];

	if (n < 0) dump_error("Negative factorial in routine FACTLN");
	if (n <= 1) return 0.0;
	if (n <= 40) return a[n] ? a[n] : (a[n]=exactfactln(n));
	if (n <= 10000) return a[n] ? a[n] : (a[n]=gammln(n+1.0));
	else return gammln(n+1.0);
}

/* -------------------------------------------------------------- */
