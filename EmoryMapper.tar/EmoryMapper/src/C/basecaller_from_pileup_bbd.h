#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
#include <string.h>

#define TRUE 1
#define FALSE 0
#define SQR(a) ((a)*(a))
#define minim(a,b) ((a<b)?a:b)
#define maxim(a,b) ((a>b)?a:b)
#define NO_ALLELES 6
#define MAX_GENOTYPES 14

/* row 0   =  A
   1   =  C
   2   =  G
   3   =  T
   4   =  Del
   5   =  Ins
   6   =  M  AC
   7   =  R  AG
   8   =  W  AT
   9   =  S  CG
   10  =  Y  CT
   11  =  K  GT
   12  = Del Het
   13  = Ins Het
*/

typedef struct sample_node
{
  double post_prob[MAX_GENOTYPES+1];
  double final_p;
  double coef;
  int reads[NO_ALLELES];
  double frac[NO_ALLELES];
  int tot;
  char final_call;
  char initial_call;
} SAMNODE;

typedef struct config_node
{
  int genotype_count[MAX_GENOTYPES];
  double prior;
  double like;
  double post;
  char *sample_calls;
  float avg_depth;
} CNODE;

#define LOG10 (double)2.302585

#include "ra_tools_lib.h"


