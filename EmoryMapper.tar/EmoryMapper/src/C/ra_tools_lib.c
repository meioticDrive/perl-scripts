/*
 
RATools is software developed for the Drosophila Population
Genomics Project.  This code aligns a "locally perfect" grid onto an 
Affy or Nimblegen resequencing array.

The design of the algorithm is due to Dave Cutler and Mike Zwick.
The code itself is Copyright (C) 2004, David J. Cutler.
The current code developers and maintainers are Dave Cutler and
Kristian Stevens.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.
This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.
You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

This file contains general io / memory allocation routines used
by numerous functions.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include "ra_tools_lib.h"

extern FILE *outfile;

/*---------------------------------------------------------------------*/
void set_next(char *sss,int *i, int *j)
{
	
	while(!isalnum(sss[*i]))
		(*i)++;
	*j = *i;
 	while(!isspace(sss[*j]) && (sss[*j] != '"'))
		(*j)++;
	sss[*j] = '\0';
	/* printf("\n %s",&sss[*i]); */
}
/*---------------------------------------------------------------------*/
 
char *cvector(int nl,int nh)
{
	char *v;
 
	v=(char *)malloc((unsigned) (nh-nl+1)*sizeof(char));
	if (!v) dump_error("allocation failure in cvector()");
	return v-nl;
}
/*---------------------------------------------------------------------*/
void free_cvector(char *v, int nl,int nh)
{
	free((char*) (v+nl));
}
 
/*---------------------------------------------------------------------*/
int *ivector(int nl,int nh)
{
	int *v;
 
	v=(int *)malloc((unsigned) (nh-nl+1)*sizeof(int));
	if (!v) dump_error("allocation failure in ivector()");
	return v-nl;
}
/*---------------------------------------------------------------------*/
void free_ivector(int *v, int nl, int nh)
{
	free((char*) (v+nl));
}
/*---------------------------------------------------------------------*/
unsigned short *usvector(int nl,int nh)
{
	unsigned short *v;
 
	v=(unsigned short *)malloc((unsigned) (nh-nl+1)*sizeof(short));
	if (!v) dump_error("allocation failure in usvector()");
	return v-nl;
}
/*---------------------------------------------------------------------*/
void free_usvector(unsigned short *v, int nl, int nh)
{
	free((char*) (v+nl));
}
/*---------------------------------------------------------------------*/
double *dvector(int nl, int nh)
{
	double *v;
 
	v=(double *)malloc((unsigned) (nh-nl+1)*sizeof(double));
	if (!v) dump_error("allocation failure in dvector()");
	return v-nl;
}
/*---------------------------------------------------------------------*/
void free_dvector(double *v, int nl,int nh)
{
	free((char*) (v+nl));
}
/*---------------------------------------------------------------------*/
int **imatrix(int nrl,int nrh,int ncl,int nch)
{
	int i,**m;

	m=(int **)malloc((unsigned) (nrh-nrl+1)*sizeof(int*));
	if (!m) dump_error("allocation failure 1 in imatrix()");
	m -= nrl;

	for(i=nrl;i<=nrh;i++) {
		m[i]=(int *)malloc((unsigned) (nch-ncl+1)*sizeof(int));
		if (!m[i]) dump_error("allocation failure 2 in imatrix()");
		m[i] -= ncl;
	}
	return m;
}
/*---------------------------------------------------------------------*/
void free_imatrix(int **m,int nrl,int nrh,int ncl,int nch)
{
	int i;

	for(i=nrh;i>=nrl;i--) free((char*) (m[i]+ncl));
	free((char*) (m+nrl));
}
/*---------------------------------------------------------------------*/
unsigned short **usmatrix(int nrl,int nrh,int ncl,int nch)
{
	int i;
	unsigned short **m;

	m=(unsigned short **)malloc((unsigned) (nrh-nrl+1)*sizeof(short*));
	if (!m) dump_error("allocation failure 1 in usmatrix()");
	m -= nrl;

	for(i=nrl;i<=nrh;i++) {
		m[i]=(unsigned short *)malloc((unsigned) (nch-ncl+1)*sizeof(short));
		if (!m[i]) dump_error("allocation failure 2 in usmatrix()");
		m[i] -= ncl;
	}
	return m;
}
/*---------------------------------------------------------------------*/
void free_usmatrix(unsigned short **m,int nrl,int nrh,int ncl,int nch)
{
	int i;

	for(i=nrh;i>=nrl;i--) free((char*) (m[i]+ncl));
	free((char*) (m+nrl));
}

/*---------------------------------------------------------------------*/
char **cmatrix(int nrl,int nrh,int ncl,int nch)
{
	int i;
	char **m;

	m=(char **)malloc((unsigned) (nrh-nrl+1)*sizeof(char*));
	if (!m) dump_error("allocation failure 1 in cmatrix()");
	m -= nrl;

	for(i=nrl;i<=nrh;i++) {
		m[i]=(char *)malloc((unsigned) (nch-ncl+1)*sizeof(char));
		if (!m[i]) dump_error("allocation failure 2 in cmatrix()");
		m[i] -= ncl;
	}
	return m;
}
 /*---------------------------------------------------------------------*/
void free_cmatrix(char **m,int nrl,int nrh,int ncl,int nch)
{
	int i;

	for(i=nrh;i>=nrl;i--) free((char*) (m[i]+ncl));
	free((char*) (m+nrl));
}
/*---------------------------------------------------------------------*/
unsigned char **ucmatrix(int nrl,int nrh,int ncl,int nch)
{
	int i;
	unsigned char **m;

	m=(unsigned char **)malloc((unsigned) (nrh-nrl+1)*sizeof(unsigned char*));
	if (!m) dump_error("allocation failure 1 in ucmatrix()");
	m -= nrl;

	for(i=nrl;i<=nrh;i++) {
		m[i]=(unsigned char *)malloc((unsigned) (nch-ncl+1)*sizeof(unsigned char));
		if (!m[i]) dump_error("allocation failure 2 in ucmatrix()");
		m[i] -= ncl;
	}
	return m;
}
/*---------------------------------------------------------------------*/
void free_ucmatrix(unsigned char **m,int nrl,int nrh,int ncl,int nch)
{
	int i;

	for(i=nrh;i>=nrl;i--) free((unsigned char*) (m[i]+ncl));
	free((unsigned char**) (m+nrl));
}
/*---------------------------------------------------------------------*/
double **dmatrix(int nrl,int nrh,int ncl,int nch)
{
	int i;
	double **m;
 
	m=(double **) malloc((unsigned) (nrh-nrl+1)*sizeof(double*));
	if (!m) dump_error("allocation failure 1 in dmatrix()");
	m -= nrl;
 
	for(i=nrl;i<=nrh;i++) {
		m[i]=(double *) malloc((unsigned) (nch-ncl+1)*sizeof(double));
		if (!m[i]) dump_error("allocation failure 2 in dmatrix()");
		m[i] -= ncl;
	}
	return m;
}
/*---------------------------------------------------------------------*/
void free_dmatrix(double **m,int nrl,int nrh,int ncl,int nch)
{
	int i;
 
	for(i=nrh;i>=nrl;i--) free((char*) (m[i]+ncl));
	free((char*) (m+nrl));
}
/*---------------------------------------------------------------------*/

void dump_error(char *error_text)
{
 
	fprintf(outfile,"An Unrecoverable Error Has Occurred...\n");
	fprintf(outfile,"%s\n",error_text);
	fprintf(outfile,"...now exiting to system...\n");
	exit(1);
}
 
/*---------------------------------------------------------------------*/
int sort_compare(const void *a,const void *b)
{
	if(*((double *)a)<*((double *)b))
		return -1;
	else
	if(*((double *)a)>*((double *)b))
		return 1;
	else
		return 0;
}

/*---------------------------------------------------------------------*/
 
void read_var(char *line,char *result)
{
 
	char line1[4196];  
	int i;

	sprintf(line1,"%s",line);
	printf(line1);
	fgets(result,4190,stdin);
	result[strlen(result)-1] = '\0';
	/* printf("\n You entered %s which is %d characters long\n",result,strlen(result)); */
	if(outfile != stdout)
	{
		for(i=0;i<minim(strlen(line1),4190);i++)
			if(line1[i] == '\n')
				line1[i] = '\0';
		fprintf(outfile,"\"%s\",%s\n",line1,result);
	}  
}
 
/*---------------------------------------------------------------------*/
int round_dave(double x)
{
	int i;
	i = (int)floor(x);
	if((double)(x - (double)i) > 0.5)
		return i + 1;
	else
		return i;
}
/*---------------------------------------------------------------------*/
char watson_crick_compliment(int a)
{
  a = toupper(a);

  if(a == 'A')
    return 'T';

  if(a == 'C')
    return 'G';

  if(a == 'G')
    return 'C';

  if(a == 'T')
    return 'A';

  return 'N';
}
/*---------------------------------------------------------------------*/
inline unsigned short short_swap( unsigned short s ) 
{
  unsigned char b1, b2;
  
  b1 = s & 255;
  b2 = (s >> 8) & 255;
  
  return (b1 << 8) + b2;
}
/*---------------------------------------------------------------------*/
inline unsigned short short_no_swap( unsigned short s ) 
{
 return s;
}
/*---------------------------------------------------------------------*/
inline int little_endian_test(void) 
{
  unsigned char  etest[2] = { 1, 0 };
  
  return ( *(short *) etest == 1 );
}
/*---------------------------------------------------------------------*/
inline unsigned short endian( unsigned short s) 
{
	if( little_endian_test() ) {
 		return( short_no_swap(s) );
 	}
 	else {
 		return( short_swap(s) );
 	}
}
/*---------------------------------------------------------------------*/
