#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
#define TRUE 1
#define FALSE 0
 
#define minim(a,b) ((a<b)?a:b)
#define maxim(a,b) ((a>b)?a:b)


typedef struct base_node 
{
  char ref;
  int frag_no;
  int frag_pos;
  int tot_coverage;
  int no_left;
  int no_right;
  float avg_left;
  float avg_right;
  float *scores;
  char score_count;
  int As;
  int Cs;
  int Gs;
  int Ts;
  int Dels;
  int no_ins;
  char **ins;
} BASE_NODE;

double smith_waterman_align(BASE_NODE **base,int nn,char *seq,int mm, double ***S, double **match, double **gap_open, double **gap_extend,int *start);
int smith_waterman_backtrack(BASE_NODE **base,int nn,char *seq,int mm, double ***S, double **gap_open, double **gap_extend,int is_left, int dist,int *start,int orient);
void set_gaps(BASE_NODE **base,int nn, double **gap_open,double **gap_extend,double **go_new,double **ge_new);
int find_mate_pairs(char **list1,int n1,char **list2,int n2,BASE_NODE **base,int *contig_starts,int no_contigs,
		    int max_dist,int min_dist,char **read1,char **read2,int *len,int *is_left,double *dist,int *start_match1,int *start_match2,
		    int *start1,int *start2,double ***p1,double ***p2,double ***p_temp1,double ***p_temp2,double match_bonus,
		    double **forwar_mat,double **reverse_mat,double **gap_open,double **gap_extend,double **go_t1,double **ge_t1,
		    double **go_t2,double **ge_t2,int *orient1,int *orient2);
int check_for_duplicates(BASE_NODE *bn,double score);
int find_base(int i,int this,int *starts,int n);
int find_length_left(BASE_NODE **base,int which, int max);
int find_length_right(BASE_NODE **base,int which,int final, int max);
BASE_NODE *base_node_alloc(void);
void read_var(char *line,char *result);
void reverse_compliment(char *contig, int n);
char *cvector(int nl,int nh);
unsigned char *ucvector(int nl,int nh);
unsigned long long *ullvector(int nl,int nh);
int *ivector(int nl,int nh);
unsigned int *uvector(int nl,int nh);
unsigned long *ulvector(int nl,int nh);
double *dvector(int nl, int nh);
float *vector(int nl, int nh);
int **imatrix(int nrl,int nrh,int ncl,int nch);
unsigned int **umatrix(int nrl,int nrh,int ncl,int nch);
unsigned long **ulmatrix(int nrl,int nrh,int ncl,int nch);
void free_umatrix(unsigned int **m,int nrl,int nrh,int ncl,int nch);
void free_ulmatrix(unsigned long **m,int nrl,int nrh,int ncl,int nch);
void free_imatrix(int **m,int nrl,int nrh,int ncl,int nch);
double **dmatrix(int nrl,int nrh,int ncl,int nch);
void free_dmatrix(double **m,int nrl,int nrh,int ncl,int nch);
char **cmatrix(int nrl,int nrh,int ncl,int nch);
unsigned char **ucmatrix(int nrl,int nrh,int ncl,int nch);
void free_cmatrix(char **m,int nrl,int nrh,int ncl,int nch);
void free_ucmatrix(unsigned char **m,int nrl,int nrh,int ncl,int nch);
void free_cvector(char *v, int nl, int nh);
void free_ucvector(unsigned char *v, int nl, int nh);
void free_ivector(int *v, int nl, int nh);
void free_ulvector(unsigned long *v, int nl, int nh);
void free_uvector(unsigned int *v, int nl, int nh);
void free_dvector(double *v, int nl,int nh);
void free_vector(float *v, int nl,int nh);
void nrerror(char *error_text);
double bicoln(int n,int k);
double gammln(double xx); 
double exactfactln(int n);
double factln(int n);


static FILE *outfile;
static FILE *matchfile;
static FILE *pileupfile;
static FILE *indelfile;

#define UNIQUE_MATE 0
#define UNIQUE_SLIP 1
#define UNIQUE_SINGLE 2 
#define UNIQUE_MIS 3
#define NON_MATE 4
#define NON_MIS 5
#define FRAG_MIS 6
#define NON_NO 7
#define DUPLICATE_READ 8
#define NEITHER_MAP 9


#define MISALIGN_SLOP 10

#define NO_INDEL_PRIOR 0.9998

double MIN_ALIGN = 0.9;
int max_hits = 10000;
int IS_BISULFITE = 0;
int DUPLICATE_CHECKING = 0;
int ADAPTIVE_GAPS = FALSE;
 
int main()
{
        char basename[1024];
	char sdxname[1024];
	char sss[4128],temp_read[1024];
	char best_read1[1024],best_read2[1024];
	char **list1,**list2,*token;
	int i,j,k,m;
	int bl1,bl2;
	int start1[3],start2[3],start_temp[3];
	int mate_counts[NEITHER_MAP+1];
	char mate_names[NEITHER_MAP+1][80];
	char **contig_names;
	int *contig_starts;
	int frag_pos,no_tokens1,no_tokens2;
	int max_contigs,no_contigs,not_done;
	int max_bases,no_bases,pair_flag;
	int max_dist, min_dist;
	double ***penalty_matrix1,***penalty_matrix2,***penalty_matrix_temp,***penalty_matrix_temp2;
	double match_bonus = 1.0;
	double **forward_bonus_matrix;
	double **reverse_bonus_matrix;
	double **gap_open,**gap_open_temp1,**gap_open_temp2;
	double **gap_extend,**gap_extend_temp1,**gap_extend_temp2;
	double avg_readlen = 0.0;
	int no_mapping_reads = 0;
	int big_line = 64000;
	char *line1,*line2,*tempseq;
       
	BASE_NODE **ref_seq;
	FILE *innfile1, *innfile2,*reffile,*largeindelfile,*sfile;
	FILE *summaryfile,*notfile1,*notfile2;
	notfile2 = stdout;

	line1 = cvector(0,big_line+1);
	line2 = cvector(0,big_line+1);
	outfile = stdout;
	read_var("Please Enter File Name for Output\n",basename);


	sprintf(sss,"%s.pileup.txt",basename);
	if((pileupfile=fopen(sss,"w"))==(FILE *)NULL)
	{
	    printf("\n Can not open file %s for writing\n",sss);
	    exit(1);
	}
	sprintf(sss,"%s.indel.txt",basename);
	if((indelfile=fopen(sss,"w"))==(FILE *)NULL)
	{
	    printf("\n Can not open file %s for writing\n",sss);
	    exit(1);
	}
	sprintf(sss,"%s.large_indel.txt",basename);
	if((largeindelfile=fopen(sss,"w"))==(FILE *)NULL)
	{
	    printf("\n Can not open file %s for writing\n",sss);
	    exit(1);
	}
	sprintf(sss,"%s.summary.txt",basename);
	if((summaryfile=fopen(sss,"w"))==(FILE *)NULL)
	{
	    printf("\n Can not open file %s for writing\n",sss);
	    exit(1);
	}
	sprintf(sss,"%s.not_mapping1.txt",basename);
	if((notfile1=fopen(sss,"w"))==(FILE *)NULL)
	{
	    printf("\n Can not open file %s for writing\n",sss);
	    exit(1);
	}
	fprintf(notfile1,"Read Number\tSequence\n");


	read_var("Name of sdx file\n",sdxname);
	if((sfile=fopen(sdxname,"r"))==(FILE *)NULL)
	{
	    printf("\n Can not open file %s\n",sdxname);
	    exit(1);
	}
	if(strstr(sdxname,".sdx") != NULL)
	{
	    for(i=strlen(sdxname)-1;i>0;i--)
	      if(sdxname[i] == '.')
	      {
		  sdxname[i] = '\0';
		  i = 0;
	      }
	}

	fgets(sss,256,sfile);
	max_contigs = atoi(sss);
	contig_starts = ivector(0,max_contigs);
	contig_names = cmatrix(0,max_contigs,0,256);

	contig_starts[0] = 0;
	for(i=0;i<max_contigs;i++)
	{
	    fgets(sss,1024,sfile);
	    token = strtok(sss,"\t \n");
	    contig_starts[i+1] = atoi(token);
	    token = strtok(NULL,"\t \n");
	    strcpy(contig_names[i],token);
	    // printf("\nFor contig %d we have offset %d",i,contig_starts[i]); 
	}
	fgets(sss,1024,sfile);
	int idepth = atoi(sss);
	fclose(sfile);
	idepth--;
	for(i=1;i<=max_contigs;i++)
	  contig_starts[i] += contig_starts[i-1] + idepth;

	max_bases = contig_starts[max_contigs];

	// for(i=0;i<=max_contigs;i++)
	// printf("\n Contig %d starts at position %d \n",i,contig_starts[i]);

	if( (ref_seq = (BASE_NODE **) malloc(sizeof(BASE_NODE *) * (max_bases+1))) == NULL)
	  nrerror("\n Error allocating space for the reference sequence \n");

	read_var("Is this pair-ended data or single end [P,p for pairend end]?\n",sss);
	pair_flag = FALSE;
	
	if( (strchr(sss,'P')) || (strchr(sss,'p')) )
	  pair_flag = TRUE;

	sprintf(sss,"%s.seq",sdxname);

	if((reffile=fopen(sss,"r"))==(FILE *)NULL)
	{
	    printf("\n Can not open file %s for reading\n",sss);
	    exit(1);
	}

	if(pair_flag)
	  read_var("Name of file containing first reads\n",sss);
	else
	  read_var("Name of file containing reads\n",sss);
	if((innfile1=fopen(sss,"r"))==(FILE *)NULL)
	{
	    printf("\n Can not open file %s for reading\n",sss);
	    exit(1);
	}
	if(pair_flag)
	{
	    sprintf(mate_names[UNIQUE_MATE],"Unique Mate-Paired");
	    sprintf(mate_names[UNIQUE_SLIP],"Unique Mate-Paired with slip");
	    sprintf(mate_names[UNIQUE_SINGLE],"Unique Single End");
	    sprintf(mate_names[UNIQUE_MIS],"Unique Mis-size");
	    sprintf(mate_names[NON_MATE],"Non-Unique Mate-Paired");
	    sprintf(mate_names[NON_MIS],"Non-Unique Mis-size");
	    sprintf(mate_names[FRAG_MIS],"Fragment Mismatch");
	    sprintf(mate_names[NON_NO],"Non-unique with no map");
	    sprintf(mate_names[DUPLICATE_READ],"Duplicate Reads Removed After Mapping");
	    sprintf(mate_names[NEITHER_MAP],"Neither Map");
	}
	else
	{
	    sprintf(mate_names[UNIQUE_MATE],"Not Used");
	    sprintf(mate_names[UNIQUE_SLIP],"Not Used");
	    sprintf(mate_names[UNIQUE_SINGLE],"Unique Mapping");
	    sprintf(mate_names[UNIQUE_MIS],"Not Used");
	    sprintf(mate_names[NON_MATE],"Not Used");
	    sprintf(mate_names[NON_MIS],"Not Used");
	    sprintf(mate_names[FRAG_MIS],"Not Used");
	    sprintf(mate_names[NON_NO],"Non-Unique Mapping, discarded");
	    sprintf(mate_names[DUPLICATE_READ],"Duplicate Reads Removed After Mapping");
	    sprintf(mate_names[NEITHER_MAP],"No mapping reaches threshold");
	}
	for(i=0;i<=NEITHER_MAP;i++)
		mate_counts[i] = 0;
	
	max_dist = min_dist = 0;

	if( (list1 = (char **) malloc(sizeof(char *) * (max_hits))) == NULL)
	  nrerror("\n Error allocating space for list1 \n");
	
	list1[0] = cvector(0,4124);
	for(i=1;i<max_hits;i++)
	  list1[i] = cvector(0,12);
	
	list2 = NULL;
	innfile2 = NULL;
	bl1 = bl2 = 0;

	if(pair_flag)
	{
	    read_var("Name of file containing second (paired-end) reads\n",sss);
	    if((innfile2=fopen(sss,"r"))==(FILE *)NULL)
	    {
		printf("\n Can not open file %s for reading\n",sss);
		exit(1);
	    }

	    if( (list2 = (char **) malloc(sizeof(char *) * (max_hits))) == NULL)
	      nrerror("\n Error allocating space for list2 \n");
	
	    list2[0] = cvector(0,4124);
	    for(i=1;i<max_hits;i++)
	      list2[i] = cvector(0,12);
	
	    read_var("Maximum distance between pairs to be considered proper mate\n",sss);
	    max_dist = atoi(sss);
	    read_var("Minimum distance between pairs to be considered proper mate\n",sss);
	    min_dist = atoi(sss);
	    sprintf(sss,"%s.pair_match.txt",basename);
	    if((matchfile=fopen(sss,"w"))==(FILE *)NULL)
	    {
	   	printf("\n Can not open file %s for writing\n",sss);
	      	exit(1);
	    }
	    sprintf(sss,"%s.not_mapping2.txt",basename);
	    if((notfile2=fopen(sss,"w"))==(FILE *)NULL)
	    {
		printf("\n Can not open file %s for writing\n",sss);
		exit(1);
	    }
	    fprintf(notfile2,"Read Number\tSequence\n");
	}

	read_var("Is this bisulfite converted DNA?\n",sss);
	if( (strchr(sss,'Y')) || (strchr(sss,'y')) )
	  IS_BISULFITE = TRUE;

	read_var("Minimum fraction of aligned bases to declare a match acceptable\n",sss);
	double temp = (double) atof(sss);
	if(temp >= 0.1 && temp <= 1.0)
	  MIN_ALIGN = temp;

	read_var("Should duplicates be removed?\n",sss);
	if( (strchr(sss,'Y')) || (strchr(sss,'y')) )
	  DUPLICATE_CHECKING = TRUE;

	if(!DUPLICATE_CHECKING)
	  sprintf(mate_names[DUPLICATE_READ],"Not Used");
	  
	printf("\n Using %g as the minimum alignment percentage \n",MIN_ALIGN);

	forward_bonus_matrix = dmatrix(0,256,0,256);
	reverse_bonus_matrix = dmatrix(0,256,0,256);

	double mtemp = -1.0 / ((double)3.0 * match_bonus);

	for(i=0;i<=256;i++)
	{
	    for(j=0;j<=256;j++)
	      if(i==j)
		forward_bonus_matrix[i][j] = reverse_bonus_matrix[i][j] = match_bonus;
	      else
		forward_bonus_matrix[i][j] = reverse_bonus_matrix[i][j] = mtemp;
	    forward_bonus_matrix[i][(int)'N'] = forward_bonus_matrix[(int)'N'][i] = forward_bonus_matrix[i][(int)'n'] = forward_bonus_matrix[(int)'n'][i] = match_bonus;
	    reverse_bonus_matrix[i][(int)'N'] = reverse_bonus_matrix[(int)'N'][i] = reverse_bonus_matrix[i][(int)'n'] = reverse_bonus_matrix[(int)'n'][i] = match_bonus;
	    if(IS_BISULFITE)
	    {
		forward_bonus_matrix[(int)'C'][(int)'T'] = match_bonus;
		forward_bonus_matrix[(int)'C'][(int)'t'] = match_bonus;
		forward_bonus_matrix[(int)'c'][(int)'T'] = match_bonus;
		forward_bonus_matrix[(int)'c'][(int)'t'] = match_bonus;
		reverse_bonus_matrix[(int)'C'][(int)'T'] = match_bonus;
		reverse_bonus_matrix[(int)'C'][(int)'t'] = match_bonus;
		reverse_bonus_matrix[(int)'c'][(int)'T'] = match_bonus;
		reverse_bonus_matrix[(int)'c'][(int)'t'] = match_bonus;
	    }
	}
	// printf("\n About to read the sequence \n\n");
	not_done = TRUE;
	frag_pos = 0;
	
	int this_contig = 1;
	tempseq = cvector(0,max_bases);
	fread(tempseq,sizeof(char),max_bases,reffile);
	fclose(reffile);
	no_bases = max_bases;
	no_contigs = max_contigs;
	for(i=0;i<max_bases;i++)
	{
	    if(i >= contig_starts[this_contig])
	    {
		this_contig++;
		frag_pos = 0;
	    }
	    char c = tempseq[i];
	    if(c == 'A' || c == 'C' || c == 'G' || c == 'T' || c == 'N')
	    {
		ref_seq[i] = base_node_alloc();
		ref_seq[i]->ref = c;
		ref_seq[i]->frag_pos = frag_pos;
		ref_seq[i]->frag_no = this_contig-1;
	    }
	    else
	    {
		printf("\n Illegal character found at position %d with is .%c. \n\n",i,c);
		exit(1);
	    }
	    frag_pos++;
	}

	free_cvector(tempseq,0,max_bases);

	fprintf(outfile,"\n Finished reading the reference file and the number of contigs = %d\n The number bases is %d\n",
		no_contigs,no_bases);

	not_done = TRUE;
	fgets(sss,4147,innfile1);
	while((sss[0] != 'S' || sss[1] != 'e' || sss[2] != 'q') && not_done)
	{
	    if(!feof(innfile1))
	      fgets(sss,4147,innfile1);
	    else
	      not_done = FALSE;
	}
	if(not_done)
	  fgets(line1,big_line,innfile1);

	if(not_done && pair_flag)
        {
	    fgets(sss,4147,innfile2);
	    while((sss[0] != 'S' || sss[1] != 'e' || sss[2] != 'q') && not_done)
	    {
		if(!feof(innfile2))
		  fgets(sss,4147,innfile2);
		else
		  not_done = FALSE;
	    }
	    if(not_done)
	      fgets(line2,big_line,innfile2);
	}
	
	if( (penalty_matrix1 = (double ***) malloc(sizeof(double **) * 3)) == NULL)
	  nrerror("\n Error allocating space for the penalty matrix 1\n");

	if( (penalty_matrix2 = (double ***) malloc(sizeof(double **) * 3)) == NULL)
	  nrerror("\n Error allocating space for the penalty matrix 2\n");

	if( (penalty_matrix_temp = (double ***) malloc(sizeof(double **) * 3)) == NULL)
	  nrerror("\n Error allocating space for the penalty matrix_temp\n");

	if( (penalty_matrix_temp2 = (double ***) malloc(sizeof(double **) * 3)) == NULL)
	  nrerror("\n Error allocating space for the penalty matrix_temp2\n");
	
	for(i=0;i<3;i++)
	{
	    penalty_matrix1[i] = dmatrix(0,1024,0,1024);
	    penalty_matrix2[i] = dmatrix(0,1024,0,1024);
	    penalty_matrix_temp[i] = dmatrix(0,1024,0,1024);
	    penalty_matrix_temp2[i] = dmatrix(0,1024,0,1024);
	}
	gap_open = dmatrix(0,1024,0,1024);
	gap_open_temp1 = dmatrix(0,1024,0,1024);
	gap_open_temp2 = dmatrix(0,1024,0,1024);

	gap_extend = dmatrix(0,1024,0,1024);
	gap_extend_temp1 = dmatrix(0,1024,0,1024);
	gap_extend_temp2 = dmatrix(0,1024,0,1024);

	double gopen_penalty = 2.0*match_bonus;

	double ge = match_bonus / 36.0;
	for(i=0;i<=1024;i++)
	  for(j=0;j<=1024;j++)
	  {
	      gap_open_temp1[i][j] = gap_open_temp2[i][j] = gap_open[i][j] = gopen_penalty;
	      gap_extend[i][j] = gap_extend_temp1[i][j] = gap_extend_temp2[i][j]= ge;
	  }

	penalty_matrix1[0][0][0] = 0.0;
	penalty_matrix1[1][0][0] = 0.0; 
	penalty_matrix1[2][0][0] = -1.0*gopen_penalty;

	for(i=1;i<1024;i++)
	{
	    /* penalty_matrix[0][0][i] = penalty_matrix[1][0][i] = penalty_matrix[0][i][0] = penalty_matrix[2][i][0] 
	       = -(gap_open + (double)(i-1)*gap_extend);  */	
	    penalty_matrix1[0][0][i] = penalty_matrix1[1][0][i] = penalty_matrix1[2][0][i] = -(gopen_penalty + (double)(i-1)*ge);
	    penalty_matrix1[0][i][0] = penalty_matrix1[0][0][0];
	    penalty_matrix1[1][i][0] = penalty_matrix1[1][0][0];
	    penalty_matrix1[2][i][0] = penalty_matrix1[2][0][0]; 
        }
	for(i=0;i<1024;i++)
		for(j=0;j<1024;j++)
			for(k=0;k<3;k++)
				penalty_matrix2[k][i][j] = penalty_matrix_temp[k][i][j] = penalty_matrix_temp2[k][i][j] = penalty_matrix1[k][i][j];

	double avg_dist = 0.0;
	int tot_pairs = 0;

	
	// printf("\n Made it here \n\n");
	while(not_done)
	{	    
	    no_tokens1 = no_tokens2 = 0;
	    char *token;
	    int first_call = 0;
	    // printf("\n Working on line=%s\n\n",line1);
	    token = strtok(line1,"\t");
	    strcpy(list1[no_tokens1],token);
	    no_tokens1++;
	    while( (token = strtok(NULL,"\t")) )
	    {
		strcpy(list1[no_tokens1],token);
		no_tokens1++;
	    }
	    if(pair_flag)
	    {
		token = strtok(line2,"\t");
		strcpy(list2[no_tokens2],token);
		no_tokens2++;
		while( (token = strtok(NULL,"\t")) )
		{
		    strcpy(list2[no_tokens2],token);
		    no_tokens2++;
		}
	    }

	    int start_match1,len[5],start_match2;
	    int end_match,this_base;
	    int dup_counts = 0;
	    int is_left = 0;

	    tot_pairs++;
	     
	    char *read1,*read2;
	    read1 = read2 = NULL;
	    double dist = 0.0;
	    int bsm = 0;
	    int orient1 = 0;
	    int orient2 = 0;
	    if(no_tokens1 >= 4 && no_tokens2 < 3)    // First is present; second doesn't map
	    {
		len[1] = strlen(list1[0]);
		double good_score = len[1] * MIN_ALIGN * match_bonus;
		double top_score = -gap_open[0][0]*len[1];
		int top_score_count = 0;
		double this_score = 0;
	
		for(i=1;i<no_tokens1;i+=3)
		{
		  // printf("\n In the loop with i = %d  frag = %s  base = %d \n\n",i,list1[i],atoi(list1[i+1]));
		    this_base = find_base(atoi(list1[i]),maxim((int)atoi(list1[i+1]),0),contig_starts,no_contigs);
		    start_match1 = maxim(contig_starts[ref_seq[this_base]->frag_no],this_base-MISALIGN_SLOP);
		    end_match = minim(contig_starts[ref_seq[this_base]->frag_no+1]-1,this_base + len[1]+MISALIGN_SLOP);
		    len[2] = 1 + end_match - start_match1;
		    strcpy(temp_read,list1[0]);
		    double **this_bonus = forward_bonus_matrix;
		    int this_orient1 = atoi(list1[i+2]);
		    if(this_orient1 == 1)
		    {
			reverse_compliment(temp_read,len[1]);
			this_bonus = reverse_bonus_matrix;
		    }

		    set_gaps(&ref_seq[start_match1],len[2],gap_open,gap_extend,gap_open_temp1,gap_extend_temp1);
		    this_score = smith_waterman_align(&ref_seq[start_match1],len[2],temp_read,len[1],penalty_matrix_temp,this_bonus,gap_open_temp1,gap_extend_temp1,start_temp);
		    if(this_score > top_score && this_score > good_score)
		    {
			top_score = this_score;
			top_score_count = 1;
			orient1 = this_orient1;
			strcpy(best_read1,temp_read);
			bsm = start_match1;
			bl1 = len[1];
			for(m=0;m<3;m++)
			{
			    start1[m] = start_temp[m];

			    for(j=0;j<=len[2];j++)
			      for(k=0;k<=len[1];k++)
				penalty_matrix1[m][j][k] = penalty_matrix_temp[m][j][k];
			}
		    }
		    else
		      if(fabs(this_score - top_score) < 0.0001)
			top_score_count++;
		}
		if(top_score_count == 0)
		{
			read2 = NULL;
			first_call = NEITHER_MAP;
		}
		else
		if(top_score_count == 1)
		{
		    first_call = UNIQUE_SINGLE;
		    read1 = best_read1;
		    len[1] = bl1;
		    start_match1 = bsm;
		}
		else
		{
		    read1 = NULL;
		    first_call = NON_NO;
		}
		    
	    }
	    else
	    if(no_tokens2 >= 4 && no_tokens1 < 3)    // Second is persent; first doesn't map
	    {
		len[3] = strlen(list2[0]);
		double good_score = len[3] * MIN_ALIGN * match_bonus;
		double top_score = -gap_open[0][0]*len[3];
		int top_score_count = 0;
		double this_score = 0;
		for(i=1;i<no_tokens1;i+=3)
		{
		    this_base = find_base(atoi(list2[i]),maxim((int)atoi(list2[i+1]),0),contig_starts,no_contigs);
		    start_match2 = maxim(contig_starts[ref_seq[this_base]->frag_no],this_base-MISALIGN_SLOP);
		    end_match = minim(contig_starts[ref_seq[this_base]->frag_no+1]-1,this_base + len[3]+MISALIGN_SLOP);
		    len[4] = 1 + end_match - start_match2;
		    strcpy(temp_read,list2[0]);
		    double **this_bonus = forward_bonus_matrix;
		    int this_orient2 = atoi(list2[i+2]);
		    if(this_orient2 == 1)
		    {
			reverse_compliment(temp_read,len[3]);
			this_bonus = reverse_bonus_matrix;
		    }

		    set_gaps(&ref_seq[start_match2],len[4],gap_open,gap_extend,gap_open_temp2,gap_extend_temp2);
		    this_score = smith_waterman_align(&ref_seq[start_match2],len[4],temp_read,len[3],penalty_matrix_temp,this_bonus,gap_open_temp2,gap_extend_temp2,start_temp);
		    if(this_score > top_score && this_score > good_score)
		    {
			top_score = this_score;
			read2 = temp_read;
			top_score_count = 1;
			bsm = start_match2;
			orient2 = this_orient2;
			bl2 = len[4];
			strcpy(best_read2,temp_read);

			for(m=0;m<3;m++)
			{
			    start2[m] = start_temp[m];
			    for(j=0;j<=len[4];j++)
			      for(k=0;k<=len[3];k++)
				penalty_matrix2[m][j][k] = penalty_matrix_temp[m][j][k];
			}
		    }
		    else
		      if(fabs(this_score - top_score) < 0.0001)
			top_score_count++;
		}
		if(top_score_count == 0)
		{
			read2 = NULL;
			first_call = NEITHER_MAP;
		}
		else
		if(top_score_count == 1)
		{
		    first_call = UNIQUE_SINGLE;
		    read2 = best_read2;
		    len[3] = bl2;
		    start_match2 = bsm;
		}
		else
		{
		    read2 = NULL;
		    first_call = NON_NO;
		}
	    }
	    else
	    if(no_tokens2 >= 4 && no_tokens1 >= 4)    // Both Present
	    {	
		int this_match = find_mate_pairs(list1,no_tokens1,list2,no_tokens2,ref_seq,contig_starts,no_contigs,
						 max_dist,min_dist,&read1,&read2,len,&is_left,&dist,&start_match1,&start_match2,
						 start1,start2,penalty_matrix1,penalty_matrix2,penalty_matrix_temp,penalty_matrix_temp2,
						 match_bonus,forward_bonus_matrix,reverse_bonus_matrix,gap_open,gap_extend,gap_open_temp1,
						 gap_extend_temp1,gap_open_temp2,gap_extend_temp2,&orient1,&orient2);

		// printf("\n Got back from find_mate_pairs with this_match = %d read1 = %s  read2 = %s l2 = %d l4 = %d\n\n",
		// this_match,read1,read2,len[2],len[4]);
		first_call = this_match;
		if(this_match == UNIQUE_MATE)
		    avg_dist += (float) dist;
	    }
	    else
	    {
		if(no_tokens1 < 4 && no_tokens2 < 4)
		    first_call = NEITHER_MAP;
		else
		    first_call = NON_NO;
	    }

	    if(read1)
	    {
	      // printf("\n About to backtrack with start = %d\n\n",start_match1);
		if(smith_waterman_backtrack(&ref_seq[start_match1],len[2],read1,len[1],penalty_matrix1,gap_open_temp1,gap_extend_temp1,is_left,dist,start1,orient1))
		{
		    // printf("\n Finished first backtrack \n\n");
		    avg_readlen += len[1];
		    no_mapping_reads++;
		}
		else
		    dup_counts++;
	    }
	    else
	      if(no_tokens1 >= 2)
		fprintf(notfile1,"%d\t%s\n",tot_pairs+1,list1[0]);
	      else
		fprintf(notfile1,"%d\t%s",tot_pairs+1,list1[0]);

	    if(read2)
	    {
		is_left = (is_left%2) + 1;
		// printf("\n About to backtrack with start = %d\n\n",start_match2);
		if(smith_waterman_backtrack(&ref_seq[start_match2],len[4],read2,len[3],penalty_matrix2,gap_open_temp2,gap_extend_temp2,is_left,dist,start2,orient2))
		{
		    // printf("\n Finished second backtrack \n\n");
		    avg_readlen += len[3];
		    no_mapping_reads++;
		}
		else
		  dup_counts++;
	    }
	    else
	      if(pair_flag)
	      {
		  if(no_tokens2 >= 2)
		    fprintf(notfile2,"%d\t%s\n",tot_pairs+1,list2[0]);
		  else
		    fprintf(notfile2,"%d\t%s",tot_pairs+1,list2[0]);
	      }

	    mate_counts[first_call]++;
	    mate_counts[DUPLICATE_READ] += dup_counts;

	    line1[0] = '\0';
	    if(!feof(innfile1))
	    {
		fgets(line1,big_line,innfile1);
		int cl;
		while( (cl=strlen(line1)) < 10 && !feof(innfile1) )
			fgets(line1,big_line,innfile1);
		if(cl < 10)
			not_done = FALSE;
	    }
	    else
	      not_done = FALSE;
	    
	    if(not_done && pair_flag)
	    {
		line2[0] = '\0';
		if(!feof(innfile2))
		{
		    int cl;
		    fgets(line2,big_line,innfile2);
		    while( (cl = strlen(line2)) < 10 && !feof(innfile2) )
		    	fgets(line2,big_line,innfile2);
		    if(cl < 10)
		      not_done = FALSE;
		}
		else
		  not_done = FALSE;
	    }
	}

	if(no_mapping_reads > 0)
	  avg_readlen /= (double) no_mapping_reads;
	
	if(mate_counts[UNIQUE_MATE] > 0)
	  avg_dist /= (float) mate_counts[UNIQUE_MATE];

	double avg_reads = (double)avg_readlen*(double)no_mapping_reads / (double) no_bases;
	fprintf(pileupfile,"Fragment\tPositions\tReference Base\tAs\tCs\tGs\tTs\tDels\tIns\t%g",avg_reads);
	fprintf(indelfile,"Fragment\tPositions\tReference Base\tTotal Coverage\tReference Reads\tNo Deletions\tNo Insertions\tInsertion Sequence");
	fprintf(largeindelfile,"Start Fragment\tPosition\tEnd Fragment\tPosition");
	if(pair_flag)
		fprintf(matchfile,"Fragment\tPositions\tReference Base\tTotal Coverage\t%%Not Paired\t%%Left\t%%Right\tAvg Left\tAvg Right");
	


	int in_bigindel = FALSE;
	int big_start = -1;
	int big_end = -1;
	int mid_point = -1;
	int ref_reads = 0;
	double max_bad = 0;
	double max_left = 0;
	double max_right = 0;

	for(i=0;i<no_bases;i++)
	{
	    fprintf(pileupfile,"\n%s\t%d\t%c\t%d\t%d\t%d\t%d\t%d\t%d",contig_names[ref_seq[i]->frag_no],
		    ref_seq[i]->frag_pos+1,ref_seq[i]->ref,ref_seq[i]->As,ref_seq[i]->Cs,ref_seq[i]->Gs,
		    ref_seq[i]->Ts,ref_seq[i]->Dels,ref_seq[i]->no_ins);
	    if(ref_seq[i]->ref == 'A')
		ref_reads = ref_seq[i]->As;
	    else
	    if(ref_seq[i]->ref == 'C')
		ref_reads = ref_seq[i]->Cs;
	    else
	    if(ref_seq[i]->ref == 'G')
		ref_reads = ref_seq[i]->Gs;
	    else
		ref_reads = ref_seq[i]->Ts;
	    fprintf(indelfile,"\n%s\t%d\t%c\t%d\t%d\t%d\t%d",contig_names[ref_seq[i]->frag_no],
		    ref_seq[i]->frag_pos+1,ref_seq[i]->ref,ref_seq[i]->tot_coverage,ref_reads,ref_seq[i]->Dels,ref_seq[i]->no_ins);
	    for(j=0;j<ref_seq[i]->no_ins;j++)
	      fprintf(indelfile,"\t%s",ref_seq[i]->ins[j]);
	    
	    if(pair_flag)
	    {
		if(ref_seq[i]->no_left > 0)
			ref_seq[i]->avg_left /= (float)ref_seq[i]->no_left;
		if(ref_seq[i]->no_right > 0)
			ref_seq[i]->avg_right /= (float)ref_seq[i]->no_right;

		if(ref_seq[i]->tot_coverage > 0.5)
		{
		        double frac_single = 1.0 - (double)(ref_seq[i]->no_left + ref_seq[i]->no_right)/(double)ref_seq[i]->tot_coverage; 
		    	double per_left = (double)ref_seq[i]->no_left / (double) ref_seq[i]->tot_coverage;
			double per_right = (double)ref_seq[i]->no_right / (double) ref_seq[i]->tot_coverage;
			double read_ratio = (double)ref_seq[i]->tot_coverage / avg_reads;
	    		fprintf(matchfile,"\n%s\t%d\t%c\t%d\t%g\t%g\t%g\t%g\t%g",contig_names[ref_seq[i]->frag_no],
		    		ref_seq[i]->frag_pos+1,ref_seq[i]->ref,ref_seq[i]->tot_coverage,frac_single,per_left,per_right,
		    		ref_seq[i]->avg_left,ref_seq[i]->avg_right);
			int print_bigdel = FALSE;
			if(ref_seq[i]->frag_pos > 2*avg_readlen  && i+ 2*avg_readlen < contig_starts[ref_seq[i]->frag_no+1] && (frac_single > 0.02 || read_ratio < 0.5) )
			{
			    if(in_bigindel)
			    {
				if(mid_point < 0)
				  if(per_right > 0.5)
				    mid_point = i;
				max_bad = maxim(max_bad,frac_single);
				max_left = maxim(max_left,per_left);
				max_right = maxim(max_right,per_right);
			    }
			    else
			    {
				if(per_left > 0.66)
				{
				    big_start = i;
				    in_bigindel = TRUE;
				    max_bad = frac_single;
				    max_left = per_left;
				    max_right = per_right;
				}
			    }

			}
			else
			{
			    if(in_bigindel)
			    {
				print_bigdel = TRUE;
				big_end = i;
				if( (max_bad > 0.1) && (max_left > 0.7) && (max_right > 0.7) && ((big_end - big_start < 30*avg_readlen) && (big_end - mid_point)  > avg_readlen) && ((mid_point - big_start) > avg_readlen) )
				  fprintf(largeindelfile,"\n%s\t%d\t%s\t%d",
					  contig_names[ref_seq[big_start]->frag_no],ref_seq[big_start]->frag_pos+1,
					  contig_names[ref_seq[big_end]->frag_no],ref_seq[big_end]->frag_pos+1);
			    }
			    in_bigindel = FALSE;
			    big_start = mid_point = big_end = -1;
			    max_bad = max_left = max_right = 0;
			    
			}
		}
		else
	    		fprintf(matchfile,"\n%s\t%d\t%c\t%d\t%g\t%g\t%g\t%g\t%g",contig_names[ref_seq[i]->frag_no],
		    		ref_seq[i]->frag_pos+1,ref_seq[i]->ref,ref_seq[i]->tot_coverage, 0.0,0.0,0.0, 
		    		ref_seq[i]->avg_left,ref_seq[i]->avg_right);
	    }
	}
	fclose(pileupfile);
	fclose(indelfile);
	fclose(largeindelfile);
	if(pair_flag)
	    fclose(matchfile);

	printf("\n================================================================");
	printf("\n================= Summary ======================================");
	printf("\n================================================================");
	printf("\n================================================================");
	printf("\n\nTotal Number of Mapping reads of Any Kind\t%d\tWith average Length\t%g\tAverage Depth\t%g\tAverage Insert Size\t%g",
	       no_mapping_reads,avg_readlen,avg_reads,avg_dist);
	printf("\n\nMapping Type\tCount\tFraction");
	printf("\nAll\t%d\t1",tot_pairs);
	for(i=0;i<=NEITHER_MAP;i++)
	  if(strstr(mate_names[i],"Not Used") == NULL)
	  {
	      if(i==DUPLICATE_READ)
		printf("\n%s\t%d\t%g",mate_names[i],mate_counts[i],(double)mate_counts[i]/((double)tot_pairs*2.0));
	      else
		printf("\n%s\t%d\t%g",mate_names[i],mate_counts[i],(double)mate_counts[i]/(double)tot_pairs);
	  }
	printf("\n");

	fprintf(summaryfile,"\n================================================================");
	fprintf(summaryfile,"\n================= Summary ======================================");
	fprintf(summaryfile,"\n================================================================");
	fprintf(summaryfile,"\n================================================================");
	fprintf(summaryfile,"\n\nTotal Number of Mapping reads of Any Kind\t%d\tWith average Length\t%g\tAverage Depth\t%g\tAverage Insert Size\t%g",
			no_mapping_reads,avg_readlen,avg_reads,avg_dist);
	fprintf(summaryfile,"\n\nMapping Type\tCount\tFraction");
	fprintf(summaryfile,"\nAll\t%d\t1",tot_pairs);
	for(i=0;i<=NEITHER_MAP;i++)
	  if(strstr(mate_names[i],"Not Used") == NULL)
	  {
	      if(i==DUPLICATE_READ)
		fprintf(summaryfile,"\n%s\t%d\t%g",mate_names[i],mate_counts[i],(double)mate_counts[i]/((double)tot_pairs*2.0));
	      else
		fprintf(summaryfile,"\n%s\t%d\t%g",mate_names[i],mate_counts[i],(double)mate_counts[i]/(double)tot_pairs);
	  }
	fprintf(summaryfile,"\n");
	
	fclose(summaryfile);
	return 0;
}
/*-------------------------------------------------------------------------------------------------------------------------------------- */
/*-------------------------------------------------------------------------------------------------------------------------------------- */
int find_mate_pairs(char **list1,int n1,char **list2,int n2,BASE_NODE **base,int *contig_starts,int no_contigs,
		    int max_dist,int min_dist,char **read1,char **read2,int *len,int *is_left,double *dist,int *start_match1,int *start_match2,
		    int *start1,int *start2,double ***p1_save,double ***p2_save,double ***p_temp1,double ***p_temp2,
		    double match_bonus,double **forward_mat, double **reverse_mat,double **gap_open,double **gap_extend,
		    double **go_temp1,double **ge_temp1, double **go_temp2, double **ge_temp2,int *orient1,int *orient2)
{
	char *seq1;
	char *seq2;
	char frag[1024];
	char seq1_temp[1024];
	char seq2_temp[1024];
	int i,j,k,m,q;
	int start_temp1[3];
	int start_temp2[3];
        int perfect = 0;
        int size_mismatch = 0;
        int broken = 0;
        int frag_count = 0;
	int sm1,em1,sm2,em2;
	int l1,l2,l3,l4;
	int stored1[2],stored2[2];
	double smax1[2],smax2[2];
	double this_1,this_2;
	double **this_mat;
	int best_len[5];
	int temp_dist = 0;
	double tot_best = -1e5;

	if(n1 > 12000 || n2 > 12000)
	  return NON_MIS;

	stored1[0] = stored1[1] = stored2[1] = stored2[0] = -1;
	smax1[0] = smax2[0] = smax1[1] = smax2[1] = -1.0;
	seq1 = list1[0];
	seq2 = list2[0];
	best_len[1] = best_len[2] = best_len[3] = best_len[4] = 0;
	(*orient1) = (*orient2) = 0;
	sm1 = sm2 = l2 = l4 = 0;

	best_len[1] = len[1] = l1 = strlen(list1[0]);
	double good_score1 = l1 * MIN_ALIGN * match_bonus;
	best_len[3] = len[3] = l3 = strlen(list2[0]);
	double good_score2 = l3 * MIN_ALIGN * match_bonus;
	// printf("\n Entered find_mate_pairs with no_contigs = %d and looking for .%s. and .%s. n1 = %d  n2 = %d  l1 = %d  l3 = %d\n\n",no_contigs,list1[0],list2[0],n1,n2,l1,l3);
	for(i=1;i<n1;i+=3)
	{
	    for(j=1;j<n2;j+=3)
	    {
		if(strcmp(list1[i],list2[j]) == 0)
		{
		    int p1 = atof(list1[i+1]);
		    int p2 = atof(list2[j+1]);
		    temp_dist = abs(p1-p2);
		    int or1 = atof(list1[i+2]);
		    int or2 = atof(list2[j+2]);
		    int is_perfect = ( (temp_dist >= min_dist) && (temp_dist <= max_dist) && (or1 != or2));
		    // printf("\n for i = %d   j = %d is_perfect = %d\n\n",i,j,is_perfect);
 		    if(is_perfect || (perfect < 1) )
		    {
			if(stored1[0] != i && stored1[1] != i)
			{
			    int this_base = find_base(atoi(list1[i]),maxim(p1,0),contig_starts,no_contigs);
			    sm1 = maxim(contig_starts[base[this_base]->frag_no],this_base-MISALIGN_SLOP);
			    em1 = minim(contig_starts[base[this_base]->frag_no+1]-1,this_base + l1+MISALIGN_SLOP);
			    strcpy(seq1_temp,list1[0]);
			    if(or1 == 1)
			    {
				this_mat = reverse_mat;
				reverse_compliment(seq1_temp,l1);
			    }
			    else
			      this_mat = forward_mat;
			    l2 = 1 + em1 - sm1;
			    set_gaps(&base[sm1],l2,gap_open,gap_extend,go_temp1,ge_temp1);
			    this_1 = smith_waterman_align(&base[sm1],l2,seq1_temp,l1,p_temp1,this_mat,go_temp1,ge_temp1,start_temp1);
			    stored1[0] = i;
			    smax1[0] = this_1;
			}
			else
			    if(stored1[0] == i)
			      this_1 = smax1[0];
			    else
				this_1 = smax1[1];

			if(stored2[0] != j && stored2[1] != j)
			{
			    int this_base = find_base(atoi(list2[j]),maxim(p2,0),contig_starts,no_contigs);
			    sm2 = maxim(contig_starts[base[this_base]->frag_no],this_base-MISALIGN_SLOP);
			    em2 = minim(contig_starts[base[this_base]->frag_no+1]-1,this_base + l3+MISALIGN_SLOP);
			    l4 = 1 + em2 - sm2;
			    
			    strcpy(seq2_temp,list2[0]);
			    if(or2 == 1)
			    {
				reverse_compliment(seq2_temp,l3);
				this_mat = reverse_mat;
			    }
			    else
			      this_mat = forward_mat;
			    set_gaps(&base[sm2],l4,gap_open,gap_extend,go_temp2,ge_temp2);
			    this_2 = smith_waterman_align(&base[sm2],l4,seq2_temp,l3,p_temp2,this_mat,go_temp2,ge_temp2,start_temp2);
			    stored2[0] = j;
			    smax2[0] = this_2;
			}
			else
			  if(stored2[0] == j)
			    this_2 = smax2[0];
			  else
			    this_2 = smax2[1];

			double inc = this_1 + this_2 - tot_best;
			if(inc > 0.001)
			{
			    // printf("\n About to store everything i=%d j = %d l1 = %d  l2 = %d  l3 = %d  l4 = %d\n\n",i,j,l1,l2,l3,l4);
			    if(is_perfect && this_1 > good_score1 && this_2 > good_score2)
			    {
				perfect = 1;
				size_mismatch = 0;
				*dist = temp_dist;
				if(p2 < p1)
				  *is_left = 1;
				else
				  *is_left = 2;
	
			    }
			    else
			      	size_mismatch=1;
			    frag_count = 0;
			    strcpy(frag,list1[i]);
			    tot_best = this_1 + this_2;
			
			    if(stored1[1] != i && this_1 > good_score1 && (is_perfect || perfect == 0) )
			    {
				for(k=0;k<3;k++)
				{
				    start1[k] = start_temp1[k];
				    for(m=1;m<=l2;m++)
				      for(q=1;q<=l1;q++)
					p1_save[k][m][q] = p_temp1[k][m][q];
				}
				best_len[2] = l2;
				smax1[1] = this_1;
				*start_match1 = sm1;
				stored1[1] = i;
				*orient1 = or1;

			    }
			    if(stored2[1] != j && this_2 > good_score2 && (is_perfect || perfect == 0) )
			    {
				for(k=0;k<3;k++)
				{
				    start2[k] = start_temp2[k];
				    for(m=1;m<=l4;m++)
				      for(q=1;q<=l3;q++)
					p2_save[k][m][q] = p_temp2[k][m][q];
				}
				best_len[4] = l4;
				smax2[1] = this_2;
				*start_match2 = sm2;
				stored2[1] = j;
				*orient2 = or2;
			    }
			}
			else
			  if(inc > -0.001)
			  {
			      if(is_perfect)
				perfect++;
			      else
				size_mismatch++;
			      if(strcmp(list1[i],frag) != 0)
				frag_count++;
			  }

		    }
		}
		else
		  broken++;
	    }
	    
	}

	// printf("\n\tLeaving with smax1 = %g  smax2 = %g  perfect = %d l2=%d l4=%d \n\n",smax1[1],smax2[1],perfect,best_len[2],best_len[4]);

	if(frag_count > 0)
	{
		if(perfect > 0)
			return NON_MATE;
		else
			return NON_MIS;
	}

	if( (perfect > 0) || (size_mismatch > 0) )
	{
	    len[2] = best_len[2];
	    len[4] = best_len[4];
	    if(*orient1 == 1)
	      reverse_compliment(seq1,len[1]);
	    if(*orient2 == 1)
	      reverse_compliment(seq2,len[3]);
	   
	    
	    read1[0] = seq1;
	    read2[0] = seq2;
	    if(smax1[1] < good_score1)
	    {
		read1[0] = NULL;
		if(smax2[1] < good_score2)
		{
		    read2[0] = NULL;
		    return NEITHER_MAP;
		}
		*is_left = 0;
		// printf("\n Read 1 lost with top score %g and good score = %g",smax1[1],good_score1);
		return UNIQUE_SINGLE;
	    }
	    else
	      set_gaps(&base[*start_match1],len[2],gap_open,gap_extend,go_temp1,ge_temp1);

	    if(smax2[1] < good_score2)
	    {
		*is_left = 0;
		read2[0] = NULL;
		// printf("\n Read 2 lost with top score %g and good score = %g",smax2[1],good_score2);
		return UNIQUE_SINGLE;
	    }
	    else
	      set_gaps(&base[*start_match2],len[4],gap_open,gap_extend,go_temp2,ge_temp2);
		
	    if(perfect == 1)
	      return UNIQUE_MATE;
	    else
	      if(perfect > 1)
		return UNIQUE_SLIP;
	      else
		if(size_mismatch == 1)
			return UNIQUE_MIS;
		else
		{
			*is_left = 0;
			read1[0] = NULL;
			read2[0] = NULL;
			return NON_MIS;
		}
	}

	if(broken > 0)
		return FRAG_MIS;

	return NEITHER_MAP;
}
/*-------------------------------------------------------------------------------------------------------------------------------------- */
/*-------------------------------------------------------------------------------------------------------------------------------------- */
void set_gaps(BASE_NODE **base,int nn, double **gap_open,double **gap_extend,double **go_new,double **ge_new)
{
  int i, j, tot;
  double fact,go,ge;
  
  if(ADAPTIVE_GAPS == FALSE)
    return;
  
  go_new[0][0] = gap_open[0][0];
  ge_new[0][0] = gap_extend[0][0];

  for(i=0;i<nn;i++)
  {
      tot = 1 + base[i]->tot_coverage + base[i]->no_ins;
      fact = (double)(tot - (base[i]->Dels + base[i]->no_ins)) / (double)tot;
      go = go_new[0][0] * fact;
      ge = ge_new[0][0] * fact;
      for(j=0;j<=nn;j++)
      {
	  go_new[i][j] = go;
	  ge_new[i][j] = ge;
      }

  }



}
/*-------------------------------------------------------------------------------------------------------------------------------------- */
/*-------------------------------------------------------------------------------------------------------------------------------------- */
double smith_waterman_align(BASE_NODE **base,int nn,char *seq,int mm, double ***S, double **match, double **gap_open, double **gap_extend,int *start)
{
  double bump;
  int maxi,maxj,maxk,i,j,i1,j1;

  maxk = 0;
  maxi = 0;
  maxj = mm;

  for(i=1;i<=nn;i++)
    for(j=1;j<mm;j++)
    {
	i1 = i-1;
	j1 = j-1;
	S[2][i][j] = maxim(S[0][i][j1]-gap_open[i1][j1],S[2][i][j1]-gap_extend[i1][j1]);
	S[1][i][j] = maxim(S[0][i1][j]-gap_open[i1][j],S[1][i1][j]-gap_extend[i1][j]);
	bump = match[(int)base[i1]->ref][(int)seq[j1]];
	S[0][i][j] = maxim(maxim(S[0][i1][j1]+bump,S[1][i1][j1]+bump),S[2][i1][j1]+bump);
    }
  j = mm;
  j1 = j-1;
  for(i=1;i<=nn;i++)
  {
	i1 = i-1;
	S[2][i][j] = maxim(S[0][i][j1]-gap_open[i1][j1],S[2][i][j1]-gap_extend[i1][j1]);
	S[1][i][j] = maxim(S[0][i1][j]-gap_open[i1][j],S[1][i1][j]-gap_extend[i1][j]);
	bump = match[(int)base[i1]->ref][(int)seq[j1]];
	S[0][i][j] = maxim(maxim(S[0][i1][j1]+bump,S[1][i1][j1]+bump),S[2][i1][j1]+bump);
	if(S[0][i][j] > S[maxk][maxi][maxj])
	{
	    maxk = 0; maxi = i; maxj = j; 
	}
	if(S[1][i][j] > S[maxk][maxi][maxj])
	{
	    maxk = 1; maxi = i; maxj = j; 
	}
	if(S[2][i][j] > S[maxk][maxi][maxj])
	{
	    maxk = 2; maxi = i; maxj = j; 
	}
   }
	

  start[0] = maxk;
  start[1] = maxi;
  start[2] = maxj;
  return S[maxk][maxi][maxj];
}

/*-------------------------------------------------------------------------------------------------------------------------------------- */
/*-------------------------------------------------------------------------------------------------------------------------------------- */
int check_for_duplicates(BASE_NODE *bn,double score)
{
  int i;
  double eps = 0.0001;

  for(i=0;i<bn->score_count;i++)
    if(fabs(bn->scores[i] - score) < eps)
      return TRUE;

  if(bn->score_count > 0)
  {
      float *temp;
      temp = vector(0,bn->score_count);
      for(i=0;i<bn->score_count;i++)
	temp[i] = bn->scores[i];
      free_vector(bn->scores,0,bn->score_count);
      bn->scores = temp;
  }
  else
      bn->scores = vector(0,1);

  bn->scores[(int)(bn->score_count)] = (float) score;
  (bn->score_count)++;
  return FALSE;
}
/*-------------------------------------------------------------------------------------------------------------------------------------- */
/*-------------------------------------------------------------------------------------------------------------------------------------- */
int smith_waterman_backtrack(BASE_NODE **base,int nn,char *seq,int mm, double ***S, double **gap_open, double **gap_extend,int is_left, int dist,int *start,int orient)
{  
  double smax = 0.0;
  char ins_string[512],**temp_ins;
  int ins_len;
  int maxi,maxj,maxk,i,j,k,i1,j1,m;

  for(i=0;i<512;i++)
	ins_string[i] = '\0';

  k = start[0];
  i = start[1];
  j = start[2];
  if(DUPLICATE_CHECKING)
  {
    // printf("\n Off we go with i=.%d. j = %d k = %d, and score = %g orient = %d \n\n",i,j,k,S[start[0]][start[1]][start[2]],orient);
      if(check_for_duplicates(base[i-1],-1*orient*S[start[0]][start[1]][start[2]]))
	return FALSE;
  }
  
  i1 = j1 = 0;

  // printf("\n\t In backtrack with k=%d i = %d  j = %d with max = %g\n\n",k,i,j,S[k][i][j]);
  /* int kk,ii,jj;
  for(kk=0;kk<3;kk++)
  {
      printf("k=%d 0",kk);
      for(ii=0;ii<nn;ii++)
	printf(" %c",base[ii]->ref);
      for(jj=0;jj<=mm;jj++)
      {
	  if(jj > 0)
	    printf("\n%c",seq[jj-1]);
	  else
	    printf("\n0");
	  for(ii=0;ii<=nn;ii++)
	    printf(" %g",S[kk][ii][jj]);
      }
      printf("\n");
  } */

  ins_len = 0;
  while(i > 0 && j > 0)
  {
      i1 = i-1;
      j1 = j-1;
      if(k == 0)
      {
	  maxi = i1; maxj = j1; maxk = 0;
	  smax = S[0][i1][j1];
	  if(S[1][maxi][maxj] > smax)
	  {
	      maxk = 1; smax = S[maxk][maxi][maxj];
	  }
	  if(S[2][maxi][maxj] > smax)
	    maxk = 2; 

      }
      else
      if(k == 2)
      {
	  maxk = 0; maxi = i; maxj = j1; smax = S[maxk][maxi][maxj] - gap_open[i1][maxj];
	  if(S[2][maxi][maxj] - gap_extend[i1][maxj] > smax)
	      maxk = 2; 
      }
      else 
      {
	  maxk = 0; maxi = i1; maxj = j; smax = S[maxk][maxi][maxj] - gap_open[maxi][maxj];
	  if(S[1][maxi][maxj] - gap_extend[maxi][maxj] > smax)
	      maxk = 1; 
      }
      if( maxi != i )
      {

	  base[i1]->tot_coverage++;
	  if(is_left == 1)
	  {
	      base[i1]->no_left++;
	      base[i1]->avg_left+=dist;
	  }
	  else
	    if(is_left == 2)
	    {
		base[i1]->no_right++;
		base[i1]->avg_right+=dist;
	    }

	  if(maxj != j) 
	  {
	      if(seq[j1] == 'A')
		base[i1]->As++;
	      else
		if(seq[j1] == 'T')
		  base[i1]->Ts++;
		else
		  if(seq[j1] == 'G')
		    base[i1]->Gs++;
		  else
		    if(seq[j1] == 'C')
		      base[i1]->Cs++;
	  }
	  else
	  {
	    /* int nnn;
            char sss[1024];
            for(nnn=0;nnn<nn;nnn++)
                sss[nnn] = base[nnn]->ref;
            sss[nn] = '\0';
            fprintf(outfile,"\n Deletion at base %d in reference sequence %s comapred to %s  which is a %c Top score = %g\n",
	    i1,sss,seq,base[i1]->ref,S[start[0]][start[1]][start[2]]); */ 
	    base[i1]->Dels++;
	  }

	  if(ins_len > 0)
	  {
	      // printf("\n About to do the deed with an existing number of insertions = %d and an insertion of len = %d \n\n",base[i1]->no_ins,ins_len);
	      if( (temp_ins = (char **) malloc(sizeof(char *) * (base[i1]->no_ins+1))) == NULL)
		nrerror("\n Error allocating space for the insertion list \n");
	      if(base[i1]->no_ins > 0)
	      {
		  for(m=0;m<base[i1]->no_ins;m++)
		    temp_ins[m] = base[i1]->ins[m];
		  
		 free(base[i1]->ins);
	      }
	      base[i1]->ins = temp_ins;
		  
	      base[i1]->ins[base[i1]->no_ins] = cvector(0,ins_len);
	      base[i1]->ins[base[i1]->no_ins][ins_len] = '\0';
	      for(m=0;m<ins_len;m++)
		base[i1]->ins[base[i1]->no_ins][m] = ins_string[ins_len - (m+1)];
	      /* printf("\n The deed is done \n\n");
              int nnn;
              char sss[1024];
              for(nnn=0;nnn<nn;nnn++)
                sss[nnn] = base[nnn]->ref;
              sss[nnn] = '\0';
              fprintf(outfile,"\n Insertion at base %d in reference sequence %s comapred to %s.  The insertion is %s Top score is %g\n\n",
	      i1,sss,seq,base[i1]->ins[base[i1]->no_ins],S[start[0]][start[1]][start[2]]);  */

	      base[i1]->no_ins++;
	  }
	  ins_len = 0; 
      }
      else
      {
	  ins_string[ins_len] = seq[j1];
	  ins_len++;
      }

      i = maxi; j = maxj;  k = maxk;
  }
  if(ins_len > 0 && i >= 1)
  {
	      // printf("\n\n Got Here \n\n");
              if( (temp_ins = (char **) malloc(sizeof(char *) * (base[i1]->no_ins+1))) == NULL)
                nrerror("\n Error allocating space for the insertion list \n");
              if(base[i1]->no_ins > 0)
              {
                  for(m=0;m<base[i1]->no_ins;m++)
                    temp_ins[m] = base[i1]->ins[m];

                 free(base[i1]->ins);
              }
              base[i1]->ins = temp_ins;

              base[i1]->ins[base[i1]->no_ins] = cvector(0,ins_len);
              base[i1]->ins[base[i1]->no_ins][ins_len] = '\0';
              for(m=0;m<ins_len;m++)
                base[i1]->ins[base[i1]->no_ins][m] = ins_string[ins_len - (m+1)];
              /* int nnn;
              char sss[1024];
              for(nnn=0;nnn<nn;nnn++)
                sss[nnn] = base[nnn]->ref;
              sss[nnn] = '\0';
              fprintf(outfile,"\n Insertion at base %d in reference sequence %s comapred to %s.  The insertion is %s \n",
                        i1,sss,seq,base[i1]->ins[base[i1]->no_ins]); */

              base[i1]->no_ins++;

  }

  return TRUE;
  
}


/*-------------------------------------------------------------------------------------------------------------------------------------- */
int find_length_left(BASE_NODE **base,int which, int max)
{
  int i,run1,run2,run3;
  char last[3];
  int stop = maxim(which - max,0);
  
  if(which < 4)
    return which;

  run1 = 1;
  run2 = run3 = 0;
  last[0] = base[which-1]->ref;
  last[1] = base[which-2]->ref;
  last[2] = base[which-3]->ref;
  for(i=which-2;i>stop;i--)
    if(base[i]->ref == last[0])
      run1++;
    else
      i = stop;

  for(i=which-4;i>stop;i-=2)
    if(base[i+1]->ref == last[0] && base[i]->ref == last[1])
      run2+=2;
    else
      i = stop;

  for(i=which-6;i>stop;i-=3)
    if(base[i+2]->ref == last[0] && base[i+1]->ref == last[1]  && base[i]->ref == last[2])
      run3+=3;
    else
      i = stop;


  return maxim(maxim(run1,run2),run3);
    
}
/*-------------------------------------------------------------------------------------------------------------------------------------- */
int find_length_right(BASE_NODE **base,int which,int final, int max)
{
  int i,run1,run2,run3;
  char last[3];
  int stop = minim(which + max,final-1);
  
  if(which+4 > stop)
    return final - which;

  run1 = 1;
  run2 = run3 = 0;
  last[0] = base[which+1]->ref;
  last[1] = base[which+2]->ref;
  last[2] = base[which+3]->ref;
  for(i=which+2;i<stop;i++)
    if(base[i]->ref == last[0])
      run1++;
    else
      i = stop;

  for(i=which+4;i<stop;i+=2)
    if(base[i-1]->ref == last[0] && base[i]->ref == last[1])
      run2+=2;
    else
      i = stop;

  for(i=which+6;i<stop;i+=3)
    if(base[i-2]->ref == last[0] && base[i-1]->ref == last[1]  && base[i]->ref == last[2])
      run3+=3;
    else
      i = stop;


  return maxim(maxim(run1,run2),run3);
    
}

/*-------------------------------------------------------------------------------------------------------------------------------------- */
int find_base(int i,int this,int *starts, int n)
{
  int j;

  j = starts[i] + this;

  if(i >= n || i < 0)
  {
      fprintf(outfile,"\n Could not find %d and base %d anywhere \n",i,this);
      exit(1);
  }

  if(j > starts[i+1])
  {
    fprintf(outfile,"\n Could not find .%d. and base %d anywhere because this length is %d \n",i,this,starts[i+1]-starts[i]);
      exit(1);
  }

  return j;
}
/*-------------------------------------------------------------------------------------------------------------------------------------- */
BASE_NODE *base_node_alloc(void)
{
  BASE_NODE *node;

   node = (BASE_NODE *)malloc(sizeof(struct base_node));
   if(!node)
     nrerror("\nFailure to alloc base node \n");

  node->ref = 'N';
  node->frag_no = -1;
  node->frag_pos = 0;
  node->tot_coverage = 0;

  node->no_left = 0;
  node->no_right = 0;

  node->avg_left = 0.0;
  node->avg_right = 0.0;
 
  node->As = 0;
  node->Cs = 0;
  node->Gs = 0;
  node->Ts = 0;

  node->Dels = 0;

  node->no_ins = 0;
  node->score_count = (char)0;
  
  node->scores = (float *)NULL;
  node->ins = (char **)NULL;
 
  return node;
}
/*---------------------------------------------------------------------*/
/*--------------------------------------------------------------- */
double bicoln(int n,int k)
{
  return (factln(n)-(factln(k)+factln(n-k)));
}
/*---------------------------------------------------------------------*/

double gammln(double xx)
{
        double x,tmp,ser;
        static double cof[6]={76.18009173,-86.50532033,24.01409822,
                -1.231739516,0.120858003e-2,-0.536382e-5};
        int j;

        x=xx-1.0;
        tmp=x+5.5;
        tmp -= (x+0.5)*log(tmp);
        ser=1.0;
        for (j=0;j<=5;j++) {
                x += 1.0;
                ser += cof[j]/x;
        }
        return -tmp+log(2.50662827465*ser);
}

/*---------------------------------------------------------------------*/
double exactfactln(int n)
{
  int i;
  double x=1.0;

  for(i=2;i<=n;i++)
    x*=(double)i;

  return log(x);
}
/*---------------------------------------------------------------------*/

double factln(int n)
{
        static double a[10001];

        // if (n < 0) nrerror("Negative factorial in routine FACTLN");
        if (n <= 1) return 0.0;
        if (n <= 40) return a[n] ? a[n] : (a[n]=exactfactln(n));
        if (n <= 10000) return a[n] ? a[n] : (a[n]=gammln(n+1.0));
        else return gammln(n+1.0);
}


/*---------------------------------------------------------------------*/
/*---------------------------------------------------------------------*/

void read_var(char *line,char *result)
{
 
	char line1[256];  
	int i;

	sprintf(line1,"%s",line);
	printf("%s",line1);
	fgets(result,250,stdin);
	result[strlen(result)-1] = '\0';
	/* printf("\n You entered %s which is %d characters int\n",result,strlen(result)); */
	if(outfile != stdout)
	{
		for(i=0;i<(int)minim(strlen(line1),255);i++)
			if(line1[i] == '\n')
				line1[i] = '\0';
		fprintf(outfile,"\"%s\",%s\n",line1,result);
	} 
}

/*---------------------------------------------------------------------*/
void reverse_compliment(char *contig, int n)
{
  int i,j=0;
  char c,s[4128];

  for(i=n-1;i>=0;i--)
  {
      if(*(contig+i) == 'A')
	c = 'T';
      else
      if(*(contig+i) == 'C')
	c = 'G';
      else
      if(*(contig+i) == 'G')
	c = 'C';
      else
      if(*(contig+i) == 'T')
	c = 'A';
      else
	c = 'N';

      s[j++] = c;
  }
  for(i=0;i<n;i++)
    contig[i] = s[i];
  contig[i] = '\0';

}
/*---------------------------------------------------------------------*/

char *cvector(int nl,int nh)
{
	char *v;
 
	v=(char *)malloc((unsigned) (nh-nl+1)*sizeof(char));
	if (!v) nrerror("allocation failure in cvector()");
	return v-nl;
}

unsigned char *ucvector(int nl,int nh)
{
	unsigned char *v;
 
	v=(unsigned char *)malloc((unsigned) (nh-nl+1)*sizeof(unsigned char));
	if (!v) nrerror("allocation failure in ucvector()");
	return v-nl;
}

unsigned long long *ullvector(int nl,int nh)
{
	unsigned long long *v;
 
	v=(unsigned long long *)malloc((unsigned) (nh-nl+1)*sizeof(unsigned long long));
	if (!v) nrerror("allocation failure in ullvector()");
	return v-nl;
}

int *ivector(int nl,int nh)
{
	int *v;
 
	v=(int *)malloc((unsigned) (nh-nl+1)*sizeof(int));
	if (!v) nrerror("allocation failure in ivector()");
	return v-nl;
}

unsigned int *uvector(int nl,int nh)
{
	unsigned int *v;
 
	v=(unsigned int *)malloc((unsigned) (nh-nl+1)*sizeof(int));
	if (!v) nrerror("allocation failure in ulvector()");
	return v-nl;
}

unsigned long *ulvector(int nl,int nh)
{
	unsigned long *v;
 
	v=(unsigned long *)malloc((unsigned) (nh-nl+1)*sizeof(long));
	if (!v) nrerror("allocation failure in ulvector()");
	return v-nl;
}

double *dvector(int nl, int nh)
{
	double *v;
 
	v=(double *)malloc((unsigned) (nh-nl+1)*sizeof(double));
	if (!v) nrerror("allocation failure in dvector()");
	return v-nl;
}
float *vector(int nl, int nh)
{
	float *v;
 
	v=(float *)malloc((unsigned) (nh-nl+1)*sizeof(float));
	if (!v) nrerror("allocation failure in vector()");
	return v-nl;
}
 
 
int **imatrix(int nrl,int nrh,int ncl,int nch)
{
	int i,**m;

	m=(int **)malloc((unsigned) (nrh-nrl+1)*sizeof(int*));
	if (!m) nrerror("allocation failure 1 in imatrix()");
	m -= nrl;

	for(i=nrl;i<=nrh;i++) {
		m[i]=(int *)malloc((unsigned) (nch-ncl+1)*sizeof(int));
		if (!m[i]) nrerror("allocation failure 2 in imatrix()");
		m[i] -= ncl;
	}
	return m;
}

unsigned int **umatrix(int nrl,int nrh,int ncl,int nch)
{
        int i;
	unsigned int **m;

	m=(unsigned int **)malloc((unsigned) (nrh-nrl+1)*sizeof(unsigned int*));
	if (!m) nrerror("allocation failure 1 in ulmatrix()");
	m -= nrl;

	for(i=nrl;i<=nrh;i++) {
		m[i]=(unsigned int *)malloc((unsigned) (nch-ncl+1)*sizeof(unsigned int));
		if (!m[i]) nrerror("allocation failure 2 in ulmatrix()");
		m[i] -= ncl;
	}
	return m;
}

unsigned long **ulmatrix(int nrl,int nrh,int ncl,int nch)
{
        int i;
	unsigned long **m;

	m=(unsigned long **)malloc((unsigned) (nrh-nrl+1)*sizeof(unsigned long*));
	if (!m) nrerror("allocation failure 1 in ulmatrix()");
	m -= nrl;

	for(i=nrl;i<=nrh;i++) {
		m[i]=(unsigned long *)malloc((unsigned) (nch-ncl+1)*sizeof(unsigned long));
		if (!m[i]) nrerror("allocation failure 2 in ulmatrix()");
		m[i] -= ncl;
	}
	return m;
}

void free_umatrix(unsigned int **m,int nrl,int nrh,int ncl,int nch)
{
	int i;

	for(i=nrh;i>=nrl;i--) free((void *) (m[i]+ncl));
	free((void *) (m+nrl));
}


void free_ulmatrix(unsigned long **m,int nrl,int nrh,int ncl,int nch)
{
	int i;

	for(i=nrh;i>=nrl;i--) free((void *) (m[i]+ncl));
	free((void *) (m+nrl));
}


void free_imatrix(int **m,int nrl,int nrh,int ncl,int nch)
{
	int i;

	for(i=nrh;i>=nrl;i--) free((void *) (m[i]+ncl));
	free((void *) (m+nrl));
}

 
double **dmatrix(int nrl,int nrh,int ncl,int nch)
{
	int i;
	double **m;
 
	m=(double **) malloc((unsigned) (nrh-nrl+1)*sizeof(double*));
	if (!m) nrerror("allocation failure 1 in dmatrix()");
	m -= nrl;
 
	for(i=nrl;i<=nrh;i++) {
		m[i]=(double *) malloc((unsigned) (nch-ncl+1)*sizeof(double));
		if (!m[i]) nrerror("allocation failure 2 in dmatrix()");
		m[i] -= ncl;
	}
	return m;
}
 
void free_dmatrix(double **m,int nrl,int nrh,int ncl,int nch)
{
	int i;
 
	for(i=nrh;i>=nrl;i--) free((void *) (m[i]+ncl));
	free((void *) (m+nrl));
}

char **cmatrix(int nrl,int nrh,int ncl,int nch)
{
	int i;
	char **m;
 
	m=(char **) malloc((unsigned) (nrh-nrl+1)*sizeof(char*));
	if (!m) nrerror("allocation failure 1 in cmatrix()");
	m -= nrl;
 
	for(i=nrl;i<=nrh;i++) {
		m[i]=(char *) malloc((unsigned) (nch-ncl+1)*sizeof(char));
		if (!m[i]) nrerror("allocation failure 2 in cmatrix()");
		m[i] -= ncl;
	}
	return m;
}


unsigned char **ucmatrix(int nrl,int nrh,int ncl,int nch)
{
	int i;
	unsigned char **m;
 
	m=(unsigned char **) malloc((unsigned) (nrh-nrl+1)*sizeof(unsigned char*));
	if (!m) nrerror("allocation failure 1 in cmatrix()");
	m -= nrl;
 
	for(i=nrl;i<=nrh;i++) {
		m[i]=(unsigned char *) malloc((unsigned) (nch-ncl+1)*sizeof(unsigned char));
		if (!m[i]) nrerror("allocation failure 2 in cmatrix()");
		m[i] -= ncl;
	}
	return m;
}


 
void free_cmatrix(char **m,int nrl,int nrh,int ncl,int nch)
{
	int i;
 
	for(i=nrh;i>=nrl;i--) free((void *) (m[i]+ncl));
	free((void *) (m+nrl));
}

 
void free_ucmatrix(unsigned char **m,int nrl,int nrh,int ncl,int nch)
{
	int i;
 
	for(i=nrh;i>=nrl;i--) free((void *) (m[i]+ncl));
	free((void *) (m+nrl));
}
 
void free_cvector(char *v, int nl, int nh)
{
	free((void *) (v+nl));
}

void free_ucvector(unsigned char *v, int nl, int nh)
{
	free((void *) (v+nl));
}

 
void free_ivector(int *v, int nl, int nh)
{
	free((void *) (v+nl));
}

void free_ulvector(unsigned long *v, int nl, int nh)
{
	free((void *) (v+nl));
}

void free_uvector(unsigned int *v, int nl, int nh)
{
	free((void *) (v+nl));
}
 
void free_dvector(double *v, int nl,int nh)
{
	free((void *) (v+nl));
}
void free_vector(float *v, int nl,int nh)
{
	free((void *) (v+nl));
}
 
/*---------------------------------------------------------------------*/

void nrerror(char *error_text)
{
 
	fprintf(outfile,"Numerical Recipes run-time error...\n");
	fprintf(outfile,"%s\n",error_text);
	fprintf(outfile,"...now exiting to system...\n");
	exit(1);
}

/*---------------------------------------------------------------------*/
