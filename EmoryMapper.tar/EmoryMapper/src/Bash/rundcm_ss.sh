#!/bin/bash

DCM_DIR=/opt/DCMapper

# the following are Linux specific
if [ "${OSTYPE}" == "linux-gnu" ]; then
PPLN_DIR=/opt/ZL

CMD_MKDIR=/bin/mkdir
CMD_RM=/bin/rm
CMD_HEAD=/usr/bin/head
CMD_TAIL=/usr/bin/tail
CMD_FIND=/usr/bin/find
CMD_CAT=/bin/cat
CMD_CUT=/bin/cut
CMD_SORT=/bin/sort
CMD_UNIQ=/usr/bin/uniq
CMD_DIRNAME=/usr/bin/dirname
CMD_BASENAME=/bin/basename
CMD_WHOAMI=/usr/bin/whoami
CMD_DATE=/bin/date
CMD_LN=/bin/ln
CMD_GREP=/bin/grep
CMD_SED=/bin/sed
CMD_TR=/usr/bin/tr
CMD_BC=/usr/bin/bc
CMD_AWK=/bin/awk
CMD_WC=/usr/bin/wc

else
PPLN_DIR=/Data/Software/opt/ZL

CMD_MKDIR=/bin/mkdir
CMD_RM=/bin/rm
CMD_HEAD=/usr/bin/head
CMD_TAIL=/usr/bin/tail
CMD_FIND=/usr/bin/find
CMD_CAT=/bin/cat
CMD_CUT=/usr/bin/cut
CMD_SORT=/usr/bin/sort
CMD_UNIQ=/usr/bin/uniq
CMD_DIRNAME=/usr/bin/dirname
CMD_BASENAME=/usr/bin/basename
CMD_WHOAMI=/usr/bin/whoami
CMD_DATE=/bin/date
CMD_LN=/bin/ln
CMD_GREP=/opt/local/bin/grep
CMD_SED=/usr/bin/sed
CMD_TR=/usr/bin/tr
CMD_BC=/usr/bin/bc
CMD_AWK=/usr/bin/awk
CMD_WC=/usr/bin/wc

fi


function Usage {
    echo "Usage: $1 --l <lanedir> --r <ref_fasta> [--s <samplesheet.csv>] "
    echo "       [--x <max_pair_distance] [--n <min_pair_distance] "
    echo "       [--pp <posterior_probability] [--t <theta>] [--haploid] [--p]"
    echo "       [--o <outdir>] [--map <min_align_percent>]"
    echo "       [--bisulfite] [--trim <original.ref.fasta>] [--rmdups]"
}


PE=0
MP=0
D=0
L=0
RFA=0
POSTERIOR_PROB=0.95
THETA=0.001
nMaxContigs=250
nMaxBases=350000
nMaxPairDistance=300
nMinPairDistance=50
nMinAlignPercent=0.90
bHaploid=0
sOutDir=0
bBisulfite=0
bTrim=0
bRmDups=0
ORef=0

LOG=$*

while (( $# > 0 ))
do
    case $1 in
        --l) shift
             D=`${CMD_DIRNAME} ${1}`
             L=`${CMD_BASENAME} ${1}`
             ;;
        --r) shift
             RFA=${1}
             ;;
        --p) PE=1
             ;;
        --x) shift
             nMaxPairDistace=${1}
             ;;
        --n) shift
             nMinPairDistance=${1}
             ;;
        --map) shift
               nMinAlignPercent=${1}
               ;;
        --pp) shift
             POSTERIOR_PROB=${1}
             ;;
        --s) shift
             sSampleSheet=${1}
             MP=1
             ;;
        --t) shift
             THETA=${1}
             ;;
        --p) PE=1
             ;;
        --haploid) bHaploid=1
            ;;
        --bisulfite) bBisulfite=1
            ;;
        --trim) shift
        		bTrim=1
        		ORef=${1}
        		;;
        --rmdups) bRmDups=1
            	  ;;
        --o) shift
             sOutDir=${1}
             ;;
          *) Usage $0
             exit 2
             ;;
    esac
    shift
done

if [ "$D" == "0" -o "$L" == "0" -o "$RFA" == "0" ]; then
    Usage $0
    exit
fi

if [ $bTrim -eq 1 -a "$ORef" == "0" ]; then
	Usage $0
	exit
fi

printf "CMD: ${LOG}\nRUNDIR : ${D}\nLANE : ${L}\nRef_FA : ${RFA}\n\n"

pushd ${D}/${L} >> /dev/null
pwd

if [ $MP -eq 1 ]; then
    if ! [ -d Indexed ]; then
        echo -n "Indexed directory not found. "
        echo "Please execute $PPLN_DIR/IGA_split_mpfq.pl"
        exit 2
    fi
fi

# adjust maxcontigs and maxbases from reference file
nRefContigs=$(${CMD_GREP} '>' ${RFA} | ${CMD_WC} -l)
if [ $nRefContigs -gt $nMaxContigs ]; then
    echo "Adjusting nMaxContigs (${nMaxContigs} --> ${nRefContigs})"
    nMaxContigs=$((nRefContigs + 1))
fi

nRefBases=$(${CMD_GREP} -v '>' ${RFA} | ${CMD_WC} -c)
if [ $nRefBases -gt $nMaxBases ]; then
    echo "Adjusting nMaxBases (${nMaxBases} --> ${nRefBases})"
    nMaxBases=$((nRefBases + 1))
fi

if [ ${bHaploid} -eq 1 ]; then
    M=DCM_`${CMD_WHOAMI}`_`${CMD_DATE} +%Y%m%d_%H%M%S`_Haploid
else
    M=DCM_`${CMD_WHOAMI}`_`${CMD_DATE} +%Y%m%d_%H%M%S`_Diploid
fi

if [ "${sOutDir}" != "0" ]; then
	if ! [ -e $sOutDir ]; then
		${CMD_MKDIR} $sOutDir
	fi
	
    M="${sOutDir}/${M}"
fi

${CMD_MKDIR} ${M}

if ! [ -d ${M} ]; then
    echo "Error. Cannot create directory: ${M}"
    exit 2
fi

pushd ${M} >> /dev/null
pwd

/bin/ln -s $RFA
RFA=$(${CMD_BASENAME} ${RFA})
R=`echo $RFA | ${CMD_SED} -e 's/\(.*\)\..*/\1/'`

# Step 01 - Index the reference

if [ ! -e "${DCM_DIR}/indexes/${R}.sdx" ]; then
	echo "Missing index (${DCM_DIR}/indexes/${R}.sdx) for reference file $RFA"
    echo "Please run: ${DCM_DIR}/bin/index_genome"
    exit
fi

if [ $MP -eq 0 ]; then
    echo "Processing non-multiplexed..."
    if [ $PE -eq 1 ]; then
        echo "paired-end..."
    else
        echo "single-end..."
    fi
    
    if [ $PE -eq 1 ]; then
        for ((P=1;P<=2;P++))
        do
            echo "D" > ${P}.ini
            echo "${L}_${P}.map" >> ${P}.ini
            echo "${DCM_DIR}/indexes/${R}.sdx" >> ${P}.ini
            echo "${D}/${L}/${L}_${P}_sequence.txt" >> ${P}.ini
            if [ ${bBisulfite} -eq 1 ]; then
				echo "Y" >> ${P}.ini
			else
				echo "N" >> ${P}.ini
			fi
			
            ${DCM_DIR}/bin/map_reads < ${P}.ini
        done
    else
        for ((P=1;P<=1;P++))
        do
            echo "D" > ${P}.ini
            echo "${L}.map" >> ${P}.ini
            echo "${DCM_DIR}/indexes/${R}.sdx" >> ${P}.ini
            echo "${D}/${L}/${L}_sequence.txt" >> ${P}.ini
            if [ ${bBisulfite} -eq 1 ]; then
				echo "Y" >> ${P}.ini
			else
				echo "N" >> ${P}.ini
			fi
			
            ${DCM_DIR}/bin/map_reads < ${P}.ini
        done
    fi

        # final_placement replaces Velvet->MUMmer->Clustal... almost

        echo "${L}" >> placement.ini
        echo "${DCM_DIR}/indexes/${R}.sdx" >> placement.ini
        if [ $PE -eq 1 ]; then
            echo "P" >> placement.ini
        else
            echo "S" >> placement.ini
        fi  
        if [ $PE -eq 1 ]; then
            echo "${L}_1.map" >> placement.ini
            echo "${L}_2.map" >> placement.ini
            echo "${nMaxPairDistance}" >> placement.ini
            echo "${nMinPairDistance}" >> placement.ini
        else
            echo "${L}.map" >> placement.ini
        fi
        if [ ${bBisulfite} -eq 1 ]; then
            echo "Y" >> placement.ini
        else
            echo "N" >> placement.ini
        fi
        echo "${nMinAlignPercent}" >> placement.ini
        if [ ${bRmDups} -eq 1 ]; then
            echo "Y" >> placement.ini
        else
            echo "N" >> placement.ini
        fi

    ${DCM_DIR}/bin/final_placement < placement.ini
    
    if [ ${bTrim} -eq 1 ]; then
    	# trim pileup and indels file for Dave-specific reference file
    	${DCM_DIR}/bin/trim_repeats.pl ${L} > ${L}_after_trim.summary.txt
    
		# transform pileup into format required for SeqAnt
		${DCM_DIR}/bin/combine_pileup.pl trim.pileup.txt ${L}_combined_pileup.txt
	
		# basecaller_from_pileup *is* DC's snp detector...
	
		echo "D" > basecaller.ini
		echo "${L}_basecaller.txt" >> basecaller.ini
		echo "${L}_combined_pileup.txt" >> basecaller.ini
		echo "${POSTERIOR_PROB}" >> basecaller.ini
		echo "${THETA}" >> basecaller.ini
		if [ ${bHaploid} -eq 1 ]; then
			echo "Y" >> basecaller.ini
		else
			echo "N" >> basecaller.ini
		fi
    else
		# transform pileup into format required for SeqAnt
		${DCM_DIR}/bin/combine_pileup.pl pileup.txt ${L}_combined_pileup.txt
	
		# basecaller_from_pileup *is* DC's snp detector...
	
		echo "D" > basecaller.ini
		echo "${L}_basecaller.txt" >> basecaller.ini
		echo "${L}_combined_pileup.txt" >> basecaller.ini
		echo "${POSTERIOR_PROB}" >> basecaller.ini
		echo "${THETA}" >> basecaller.ini
		if [ ${bHaploid} -eq 1 ]; then
			echo "Y" >> basecaller.ini
		else
			echo "N" >> basecaller.ini
		fi
	fi

    ${DCM_DIR}/bin/basecaller_from_pileup < basecaller.ini
    
#     echo "Parsing SNP - Indels ..."
#     if [ ${bHaploid} -eq 1 ]; then
#         ${DCM_DIR}/bin/parse_snps_indels.pl ${L}_combined_pileup.txt.snp ${L}_parsed_snps.txt haploid
#     else
#         ${DCM_DIR}/bin/parse_snps_indels.pl ${L}_combined_pileup.txt.snp ${L}_parsed_snps.txt diploid
#     fi

    # run Velvet for large indels.... TBD
    
    echo "Comparing consensus ..."
    if [ ${bTrim} -eq 1 ]; then
    	$PPLN_DIR/compare_cns.pl --r $ORef --c ${L}_trim.fasta --o ${L}_cns.stats
    else
    	$PPLN_DIR/compare_cns.pl --r $RFA --c ${L}.fasta --o ${L}_cns.stats
    fi
    
    echo "Processing coverage statistics ..."
	if [ ${bTrim} -eq 1 ]; then
		$PPLN_DIR/cvgstats.pl --i `pwd` --o `pwd` --b '0,50,100,150,200,250,300,350,400,450,500' --em --trim --v
	else
		$PPLN_DIR/cvgstats.pl --i `pwd` --o `pwd` --b '0,50,100,150,200,250,300,350,400,450,500' --em --v
	fi
    
    echo "Processing mapping stats ..."
    if [ $PE -eq 1 ]; then
    	if [ "${sOutDir}" != "0" ]; then
    		$PPLN_DIR/runstats.sh --l $D/$L --m $M --p
    	else
    		$PPLN_DIR/runstats.sh --l $D/$L --m $D/$L/$M --p
    	fi
    else
    	if [ "${sOutDir}" != "0" ]; then
    		$PPLN_DIR/runstats.sh --l $D/$L --m $M
    	else
    		$PPLN_DIR/runstats.sh --l $D/$L --m $D/$L/$M
    	fi
    fi

else
    echo "Processing multiplexed..."
    if [ $PE -eq 1 ]; then
        echo "paired-end..."
    else
        echo "single-end..."
    fi

    nLane=$(echo ${L} | sed -e 's/s_//')
    for Y in `${CMD_CAT} ${sSampleSheet} | ${CMD_CUT} -d, -f2,5 | ${CMD_GREP} "${nLane}," | ${CMD_CUT} -d, -f 2`
    do
        ${CMD_MKDIR} ${Y}
        pushd $Y >> /dev/null
        pwd
        
        SID=`${CMD_CAT} ${sSampleSheet} | ${CMD_CUT} -d, -f2,3,5 | ${CMD_GREP} "^${nLane}," | ${CMD_GREP} "${Y}" | ${CMD_CUT} -d, -f 2`

        if [ $PE -eq 1 ]; then
            for ((P=1;P<=2;P++))
            do
                echo "D" > ${P}.ini
                echo "${L}_${P}_${Y}.map" >> ${P}.ini
                echo "${DCM_DIR}/indexes/${R}.sdx" >> ${P}.ini
                echo "${D}/${L}/Indexed/${L}_${P}_${Y}_sequence.txt" >> ${P}.ini
                if [ ${bBisulfite} -eq 1 ]; then
					echo "Y" >> ${P}.ini
				else
					echo "N" >> ${P}.ini
				fi
				
                ${DCM_DIR}/bin/map_reads < ${P}.ini
            done
        else
            for ((P=1;P<=1;P++))
            do
                echo "D" > ${P}.ini
                echo "${L}_${Y}.map" >> ${P}.ini
                echo "${DCM_DIR}/indexes/${R}.sdx" >> ${P}.ini
                echo "${D}/${L}/Indexed/${L}_${Y}_sequence.txt" >> ${P}.ini
                if [ ${bBisulfite} -eq 1 ]; then
					echo "Y" >> ${P}.ini
				else
					echo "N" >> ${P}.ini
				fi
				
                ${DCM_DIR}/bin/map_reads < ${P}.ini
            done
        fi

        # final_placement replaces Velvet->MUMmer->Clustal... almost

        echo "${L}_${Y}" >> placement.ini
        echo "${DCM_DIR}/indexes/${R}.sdx" >> placement.ini
        if [ $PE -eq 1 ]; then
            echo "P" >> placement.ini
        else
            echo "S" >> placement.ini
        fi
        if [ $PE -eq 1 ]; then
            echo "${L}_1_${Y}.map" >> placement.ini
            echo "${L}_2_${Y}.map" >> placement.ini
            echo "${nMaxPairDistance}" >> placement.ini
            echo "${nMinPairDistance}" >> placement.ini
        else
            echo "${L}_${Y}.map" >> placement.ini
        fi
        if [ ${bBisulfite} -eq 1 ]; then
            echo "Y" >> placement.ini
        else
            echo "N" >> placement.ini
        fi
        echo "${nMinAlignPercent}" >> placement.ini
        if [ ${bRmDups} -eq 1 ]; then
            echo "Y" >> placement.ini
        else
            echo "N" >> placement.ini
        fi

        ${DCM_DIR}/bin/final_placement < placement.ini
        
        if [ ${bTrim} -eq 1 ]; then
        	# trim pileup and indels file for Dave-specific reference file
        	${DCM_DIR}/bin/trim_repeats.pl ${L}_${Y} > ${L}_${Y}_after_trim.summary.txt
        	
        	# transform pileup into format required for SeqAnt
			${DCM_DIR}/bin/combine_pileup.pl trim.pileup.txt ${L}_${Y}_combined_pileup.txt
	
			# basecaller_from_pileup *is* DC's snp detector...
	
			echo "D" > basecaller.ini
			echo "${L}_${Y}_basecaller.txt" >> basecaller.ini
			echo "${L}_${Y}_combined_pileup.txt" >> basecaller.ini
			echo "${POSTERIOR_PROB}" >> basecaller.ini
			echo "${THETA}" >> basecaller.ini
			if [ ${bHaploid} -eq 1 ]; then
				echo "Y" >> basecaller.ini
			else
				echo "N" >> basecaller.ini
			fi
        else
			# transform pileup into format required for SeqAnt
			${DCM_DIR}/bin/combine_pileup.pl pileup.txt ${L}_${Y}_combined_pileup.txt
	
			# basecaller_from_pileup *is* DC's snp detector...
	
			echo "D" > basecaller.ini
			echo "${L}_${Y}_basecaller.txt" >> basecaller.ini
			echo "${L}_${Y}_combined_pileup.txt" >> basecaller.ini
			echo "${POSTERIOR_PROB}" >> basecaller.ini
			echo "${THETA}" >> basecaller.ini
			if [ ${bHaploid} -eq 1 ]; then
				echo "Y" >> basecaller.ini
			else
				echo "N" >> basecaller.ini
			fi
		fi

        ${DCM_DIR}/bin/basecaller_from_pileup < basecaller.ini

#         echo "Parsing SNP - Indels ..."
#         if [ ${bHaploid} -eq 1 ]; then
#             ${DCM_DIR}/bin/parse_snps_indels.pl ${L}_${Y}_combined_pileup.txt.snp ${L}_${Y}_parsed_snps.txt haploid
#         else
#             ${DCM_DIR}/bin/parse_snps_indels.pl ${L}_${Y}_combined_pileup.txt.snp ${L}_${Y}_parsed_snps.txt diploid
#         fi
		
		echo "Comparing consensus ..."
		if [ ${bTrim} -eq 1 ]; then
			$PPLN_DIR/compare_cns.pl --r $ORef --c ${L}_${Y}_trim.fasta --o ${L}_${Y}_cns.stats
		else
			$PPLN_DIR/compare_cns.pl --r ../$RFA --c ${L}_${Y}.fasta --o ${L}_${Y}_cns.stats
		fi
		
		echo "Processing coverage statistics ..."
		if [ ${bTrim} -eq 1 ]; then
    		$PPLN_DIR/cvgstats.pl --i `pwd` --o `pwd` --b '0,50,100,150,200,250,300,350,400,450,500' --em --trim --v
    	else
    		$PPLN_DIR/cvgstats.pl --i `pwd` --o `pwd` --b '0,50,100,150,200,250,300,350,400,450,500' --em --v
    	fi
        
        popd >> /dev/null
        
        echo ""        
    done
    
	echo "Processing mapping stats ..."
	if [ $PE -eq 1 ]; then
		if [ "${sOutDir}" != "0" ]; then
			$PPLN_DIR/runstats.sh --l $D/$L --m $M --s ${sSampleSheet} --p
		else
			$PPLN_DIR/runstats.sh --l $D/$L --m $D/$L/$M --s ${sSampleSheet} --p
		fi
	else
		if [ "${sOutDir}" != "0" ]; then
			$PPLN_DIR/runstats.sh --l $D/$L --m $M --s ${sSampleSheet}
		else
			$PPLN_DIR/runstats.sh --l $D/$L --m $D/$L/$M --s ${sSampleSheet}
		fi
	fi
fi

echo "${LOG}" >> rundcm.log

popd >> /dev/null

echo "DONE! Stop looking at screenlog!"
