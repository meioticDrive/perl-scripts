#!/usr/bin/perl
# Run all chips
use strict 'vars';
use vars qw(%hFasta $sHeader $pad $half_pad $len);
use List::Util qw[min max];

if(@ARGV != 3)
{
        print "\n Usage: ${0} ref_fasta_file regions_file.bed pad \n";
        exit(1);
}


$pad = int ($ARGV[2]);
$half_pad = int ($pad / 2);
if($pad < 0 || $pad > 1000)
{
	die "\n Given Pad is $pad which is crazy \n";
}

open(FILE,"$ARGV[0]") || die "\n Can't open $ARGV[0] which should be reference file \n";

while (<FILE>) {
    $_ =~ s/\s+$//;
    if (/^>(chr\w+)/) {
        $sHeader = $1;
        $hFasta{$sHeader}[0] = 0;
        $hFasta{$sHeader}[1] = '';
        next;
    }
    $hFasta{$sHeader}[1] .= $_;
}

close(FILE);

foreach (keys %hFasta) {
    $hFasta{$_}[0] = length($hFasta{$_}[1]);
    print STDERR "$_\t$hFasta{$_}[0]\n";
}

# print "\n the chromosome has length $len \n";
open(FILE,"$ARGV[1]") || die "\n Can't open $ARGV[1] which should contain regions to extract in bed format\n";
while(<FILE>)
{
	chomp;
	my @fields = split('\t');
    my $sChr = $fields[0];
	my $start = $fields[1]-1;
	my $stop = $fields[2]-1;
	if($start < 0 || $stop > $hFasta{$sChr}[0])
	{
		die "\nOn line $_\n We found start= $start and stop = $stop and our total length is $hFasta{$sChr}[0] \n"; 
	} 

	my $p_start = max(0,$start-$pad);
	my $dist = max($start - $p_start,1);
	my $pad_region = substr($hFasta{$sChr}[1],$p_start,$dist);
	my $c_lower = $pad_region =~ tr/a-z//;
	if($c_lower / $dist > 0.5)
	{
		$p_start = max(0,$start-$half_pad);
	}

	my $p_end = min($hFasta{$sChr}[0],$stop+$pad);
	my $dist = max($p_end- $stop,1);
	my $pad_region = substr($hFasta{$sChr}[1],$stop+1,$dist);
	my $c_lower = $pad_region =~ tr/a-z//;
	if($c_lower / $dist > 0.5)
	{
		$p_end = min($hFasta{$sChr}[0],$stop+$half_pad);
	}
	my $j1 = $start-$p_start;
	my $j2 = $p_end - $stop;
	print ">$fields[0]:$p_start-$p_end\_$j1\_$j2\n";
	for(my $i = $p_start-1; $i < $p_end;$i += 50)
	{
		my $j = min(50,$p_end - $i);
		print substr($hFasta{$sChr}[1],$i,$j);
		print "\n";
	}

}

