#!/opt64/local/bin/perl
# Run all chips
use strict 'vars';
use vars qw($dirname %user $max %ins_allele $max_count @handles %ref %all_stuff $is_hap @fields @fields2 %ins @names $no_samples $i $j %snps %dels %indel_type %indel_geno);

$dirname = ".";

if(@ARGV != 3)
{
	print "\n Usage: ${0} snpfile outfile haploid/diploid \n";
	exit(1);
}

$_ = lc($ARGV[2]);
$is_hap = 0;
if(/hap/)
{
	$is_hap = 1;
}

open(FILE,"$ARGV[0]") || die "\n Can't open $ARGV[0] which should contain snp summary data \n";
$_ = <FILE>;
chomp;
@fields = split('\t');
for($i=3;$i < @fields; $i+=2)
{
	$names[$i] = $fields[$i];
	$no_samples = $i;
	open(SFILE,"$names[$i].small_indel.txt") || die "\n Can't open $names[$i].small_indel.txt which should contain indels \n";
	open($handles[$i],">$names[$i].snp") || die "\n Can't open $names[$i].snp for writing";
	<SFILE>;
	while(<SFILE>)
	{
		chomp;
		@fields2 = split('\t');
		if($fields2[3] > 1)
		{
			if(! $is_hap || ($fields2[8] > 0.5) )
			{
				$_ = $fields2[4];
				$ref{$fields2[0]}{$fields2[1]} = $fields2[2];
				$user{$fields2[0]}{$fields2[1]} = "-";
				if(/Deletion/)
				{
					$indel_type{$fields2[0]}{$fields2[1]}{$names[$i]} = "Deletion";
				}
				else
				{
					for($j=9;$j<@fields2;$j++)
					{
						$ins{$fields2[$j]}++;
					}
					my @sorted = sort { $ins{$b} <=> $ins{$a} } keys %ins;
					$indel_type{$fields2[0]}{$fields2[1]}{$names[$i]} = "Insertion $sorted[0]";
					$ins_allele{$fields2[0]}{$fields2[1]}{$sorted[0]}++;
					foreach $j (keys %ins)
					{
						delete $ins{$j};
					}
				}
				if($fields2[8] > $fields2[7])
				{
					$indel_geno{$fields2[0]}{$fields2[1]}{$names[$i]} = "Hom";
				}
				else
				{
					$indel_geno{$fields2[0]}{$fields2[1]}{$names[$i]} = "Het";
				}
				$all_stuff{$fields2[0]}{$fields2[1]} = "Indel";
				$snps{$fields2[0]}{$fields2[1]}{$names[$i]} = "$indel_geno{$fields2[0]}{$fields2[1]}{$names[$i]} $indel_type{$fields2[0]}{$fields2[1]}{$names[$i]}";
			}
		} 
	}
	close(SFILE);
}


while(<FILE>)
{
	chomp;
	@fields = split('\t');
	$all_stuff{$fields[0]}{$fields[1]}="SNP";
	$ref{$fields[0]}{$fields[1]}=$fields[2];
	my %allele;
	for($i=3;$i<@fields;$i+=2)
	{
		$_ = $fields[$i];
		if(/[RYWSKM]/)
		{
			if(/R/)
			{
				$allele{"A"}++;
				$allele{"G"}++;
			}
			elsif(/M/)
			{
				$allele{"A"}++;
				$allele{"C"}++;
			}
			elsif(/W/)
			{
				$allele{"A"}++;
				$allele{"T"}++;
			}
			elsif(/S/)
			{
				$allele{"C"}++;
				$allele{"G"}++;
			}
			elsif(/Y/)
			{
				$allele{"C"}++;
				$allele{"T"}++;
			}
			elsif(/K/)
			{
				$allele{"G"}++;
				$allele{"T"}++;
			}
		}
		else
		{
			if(!/N/)
			{
				$allele{$_} += 2;
			}
		}
		$snps{$fields[0]}{$fields[1]}{$names[$i]} = $fields[$i];
		if($indel_type{$fields[0]}{$fields[1]}{$names[$i]})
		{
			$snps{$fields[0]}{$fields[1]}{$names[$i]} = "$indel_geno{$fields[0]}{$fields[1]}{$names[$i]} $indel_type{$fields[0]}{$fields[1]}{$names[$i]}";
			$all_stuff{$fields[0]}{$fields[1]}="Indel";
		}
		else
		{
			my $j1 = $fields[1] - 1;
			if($indel_type{$fields[0]}{$j1}{$names[$i]})
			{
				$snps{$fields[0]}{$j1}{$names[$i]} = "$indel_geno{$fields[0]}{$j1}{$names[$i]} $indel_type{$fields[0]}{$j1}{$names[$i]}";
				$all_stuff{$fields[0]}{$fields[1]}="Indel";
			}
			else
			{
				$j1 = $fields[1] + 1;
				if($indel_type{$fields[0]}{$j1}{$names[$i]})
				{
					$snps{$fields[0]}{$j1}{$names[$i]} = "$indel_geno{$fields[0]}{$j1}{$names[$i]} $indel_type{$fields[0]}{$j1}{$names[$i]}";
					$all_stuff{$fields[0]}{$fields[1]}="Indel";
				}
			}
		}
	}
	if(!$user{$fields[0]}{$fields[1]})
	{
		$max = "-";
		$max_count = 0;
		foreach my $f (keys %allele)
		{
			if( ($allele{$f} > $max_count) && ($f ne $ref{$fields[0]}{$fields[1]}) ) 
			{
				$max_count = $allele{$f};
				$max = $f;
			}
			delete($allele{$f});
		}
		$user{$fields[0]}{$fields[1]} = $max;
	}
}
close(FILE);

open(FILE,">$ARGV[1]") || die "\n Can't open $ARGV[1] for writing \n";
print FILE "Fragment\tPosition\tReference\tMinor_allele\tType";
for($i=3;$i<=$no_samples;$i+=2)
{
	print FILE "\t$names[$i]";
}
for($i=3;$i<=$no_samples;$i+=2)
{
	print {$handles[$i]} "Fragment\tPosition\tReference\tType\tCall";
}

foreach $i ( sort {$a cmp $b} (keys %all_stuff))
{
	foreach my $j ( sort {$a <=> $b} (keys %{$all_stuff{$i}}))
	{
		if($user{$i}{$j} eq "-")
		{
			my $max = 0;
			foreach my $m (keys %{$ins_allele{$i}{$j}})
			{
				if($ins_allele{$i}{$j}{$m} > $max)
				{
					$max = $ins_allele{$i}{$j}{$m};
					$user{$i}{$j} = $m;
				}
			}
		}
		print FILE "\n$i\t$j\t$ref{$i}{$j}\t$user{$i}{$j}\t$all_stuff{$i}{$j}";
		for(my $k = 3; $k <= $no_samples ; $k+=2)
		{
			if($snps{$i}{$j}{$names[$k]} ne $ref{$i}{$j} && $snps{$i}{$j}{$names[$k]})
			{
				print {$handles[$k]} "\n$i\t$j\t$ref{$i}{$j}\t$all_stuff{$i}{$j}\t$snps{$i}{$j}{$names[$k]}";
			}
			if($snps{$i}{$j}{$names[$k]})
			{
				print FILE "\t$snps{$i}{$j}{$names[$k]}";
			}
			else
			{
				print FILE "\t$ref{$i}{$j}";
			}
		}
	}
}
