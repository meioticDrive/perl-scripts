#!/usr/bin/env perl
##############################################################################
### This program generates statistics from a MAQ pileup file
##############################################################################

use lib "$ENV{HOME}/lib/perl5";
use lib "/opt/perl5/lib";

use strict;
use warnings;

use Carp;
use Getopt::Long;
use Pod::Usage;
use File::Spec;
use File::Temp qw/ tempfile /;

use POSIX qw(ceil);
use Switch;
use Tie::IxHash;
use CutlerLab::Tm;

##############################################################################
### Constants
##############################################################################

use constant FALSE => 0;
use constant TRUE  => 1;

use constant VERSION => '1.9.0';
use constant PROGRAM => eval { ($0 =~ m/(\w+\.pl)$/) ? $1 : $0 };

use constant NDF_FIELDS    => 17;
use constant CONTAINERCOL  => 1;
use constant DESIGNNOTECOL => 2;
use constant SEQIDCOL      => 4; 
use constant PROBESEQCOL   => 5;
use constant POSITIONCOL   => 13;

##############################################################################
### Globals
##############################################################################

my %hCmdLineOption;
my $sHelpHeader = "\nThis is ".PROGRAM." version ".VERSION."\n";

my %hCmd = ( 'rm'       => '/bin/rm',
             'ln'       => '/bin/ln',
             'cp'       => '/bin/cp',
             'ls'       => '/bin/ls',
             'cat'      => '/bin/cat',
             'date'     => '/bin/date',
             'mkdir'    => '/bin/mkdir',
             'cd'       => '/usr/bin/cd',
             'awk'      => '/usr/bin/awk',
             'cut'      => '/usr/bin/cut',
             'sed'      => '/usr/bin/sed',
             'find'     => '/usr/bin/find',
             'grep'     => '/usr/bin/grep',
           );

my (@aInputFiles);
my ($sOutDir, $sFile);
my %hNdf = ();

##############################################################################
### Main
##############################################################################

GetOptions( \%hCmdLineOption,
            'input|i=s', 'kmer|k=i', 'skip|s=i',
            'pad|p:i', 'prepad:i', 'postpad:i',
            'ndf|n:s','cid|d:s','output|o:s',
            'csv|c',
            'verbose|v',
            'debug',
            'help',
            'man') or pod2usage(2);

pod2usage( -exitval => 0, -verbose => 2) if $hCmdLineOption{'man'};

if ( $hCmdLineOption{'help'} ||
 
     (! ((defined $hCmdLineOption{'input'}) &&
         (defined $hCmdLineOption{'kmer'})  &&
         (defined $hCmdLineOption{'skip'})  &&
         ((defined $hCmdLineOption{'pad'}) || 
          (defined $hCmdLineOption{'prepad'})))) ||
     
     ((defined $hCmdLineOption{'pad'}) && 
      ((defined $hCmdLineOption{'prepad'}) || 
       (defined $hCmdLineOption{'postpad'}))) ||
     
     (((defined $hCmdLineOption{'prepad'}) && 
       (! defined $hCmdLineOption{'postpad'})) || 
      ((! defined $hCmdLineOption{'prepad'}) && 
       (defined $hCmdLineOption{'postpad'}))) ||
     
     ((defined $hCmdLineOption{'ndf'}) &&
      (! defined $hCmdLineOption{'cid'})) ||
      
     ((! defined $hCmdLineOption{'ndf'}) &&
      (defined $hCmdLineOption{'cid'}))) {
    pod2usage( -msg => $sHelpHeader, -exitval => 1);
}


@aInputFiles = undef;
if (-d $hCmdLineOption{'input'}) {
    @aInputFiles = glob($hCmdLineOption{'input'}."/*.pileup");
}
else {
    @aInputFiles = glob($hCmdLineOption{'input'});
}

if ($#aInputFiles < 0) {
    die "No pileup file(s) found in $hCmdLineOption{'input'}\n";
}


$sOutDir = File::Spec->curdir();
if (defined $hCmdLineOption{'output'}) {
    $sOutDir = $hCmdLineOption{'output'};

    if (! -e $sOutDir) {
        mkdir($hCmdLineOption{'output'}) ||
            croak "ERROR! Cannot create output directory\n";
    }
    elsif (! -d $hCmdLineOption{'output'}) {
            croak "ERROR! $hCmdLineOption{'o'} is not a directory\n";
    }
}
$sOutDir = File::Spec->canonpath($sOutDir);

if (defined $hCmdLineOption{'ndf'}) {
	Read_Ndf( \%hCmdLineOption, \%hNdf );
}

# process the input files
foreach $sFile (@aInputFiles) {

 	Process_Pileup( \%hCmdLineOption, \%hNdf, $sOutDir, $sFile);
}

exit;

##############################################################################
### Subroutines
##############################################################################

# Read_Ndf()
#
# Purpose
#   Read NDF file and create a hash with SEQIDCOL as keys and PROBESEQCOL as
#   values
#
# Required Parameters
#   phCmdLineOption = pointer to hash containing command line options
#   phNdf           = pointer to hash for storing NDF data
#
# Optional Parameters
#
# Returns
#   nothing
#
# Side Effects
#   modifies external hash
#   
# Assumptions
#
# Notes
#
sub Read_Ndf {
	my $phCmdLineOption = shift;
	my $phNdf           = shift;
	
	my $sSubName = (caller(0))[3];
	if (! ((defined $phCmdLineOption) &&
	       (defined $phNdf))) {
	   croak "$sSubName - required parameters missing\n";
	}
	
    # Local variables
    my $bDebug = (defined $phCmdLineOption->{'debug'}) ? TRUE : FALSE;
    my $bVerbose = (defined $phCmdLineOption->{'verbose'}) ? TRUE : FALSE;

    my $sContainerID = $phCmdLineOption->{'cid'};	
	
	my @aFields = ();
	my $nI = 0;
	my $fpNDF;

    Indent('+');	
    
    ($bDebug) ? print STDERR Indent("In $sSubName\n") : ();

    ($bDebug || $bVerbose) ?
        print STDERR Indent("Reading NDF...\n") : ();
            	
	open($fpNDF, '<', $phCmdLineOption->{'ndf'}) ||
	   croak "$sSubName - cannot open NDF file for reading\n";
	   
    while (<$fpNDF>) {

        chomp;

        next if (! /$sContainerID/);

        @aFields = split(/\t/, $_, NDF_FIELDS);

        if ($aFields[SEQIDCOL] !~ /(chr.*)[_\W](\d+)-(\d+)/) {
            croak "$sSubName - invalid SEQID detected\n";
        }

        $phNdf->{"$1:$2-$3\_$nI"} = $aFields[PROBESEQCOL];
 
        $nI++;
        ($bDebug || $bVerbose) ?
            print STDERR "\r".Indent("Probe... $nI") : ();
	}
	
    close($fpNDF);

    ($bDebug || $bVerbose) ? print STDERR "\n" : ();

    ($bDebug) ? print STDERR Indent("Leaving $sSubName\n") : ();
    
    Indent('-');
    	
	return;
}


# Process_Pileup()
#
# Purpose
#
#    Compute stats for pileup file
#
# Required Parameters
#   hCmdLineOption = pointer to hash containing command line options
#   sOutDir        = output directory
#   sInFile        = input pileup file
#
# Optional Parameters
#
# Returns
#   nothing
#
# Side Effects
#   creates external disk file
#   
# Assumptions
#
# Notes
#
sub Process_Pileup {
    my $phCmdLineOption = shift;
    my $phNdf           = shift;
    my $sOutDir         = shift;
    my $sPileupFile     = shift;

    my $sSubName = (caller(0))[3];
    if (! ((defined $phCmdLineOption) &&
           (defined $sOutDir) &&
           (defined $sPileupFile))) {
        (! defined $phCmdLineOption) ? print STDERR "phCmdLineOption\n" : ();
        (! defined $sOutDir) ? print STDERR "sOutDir\n" : ();
        (! defined $sPileupFile) ? print STDERR "sPileupFile\n" : ();
        croak "$sSubName - required parameters missing\n";
    }

    # Local variables
    my $bDebug   = (defined $phCmdLineOption->{'debug'}) ? TRUE : FALSE;
    my $bVerbose = (defined $phCmdLineOption->{'verbose'}) ? TRUE : FALSE;
    my $bCSV     = (defined $phCmdLineOption->{'csv'}) ? TRUE : FALSE;
    
    my $nKmer    = $phCmdLineOption->{'kmer'};
    my $nSkip    = $phCmdLineOption->{'skip'};
    
    my %hSegment = ();
    my %hReadDistribution = ();
	my @aSkippedProbes = ();
	my @aSegDepths = ();
    my @aSegMedians = ();
	my @aThreads = ();
    my $nTotalNonPadBases = 0;
	my ($sID, $sPrevID);
    my ($nBaseNum, $cBase, $nBaseDepth, $nLineNum, $nSegNum);
    my ($nPrePadSize, $nPostPadSize);
	my ($nAvgSegDepth, $nMedianSegDepth, $nSegVar, $nSegSD);
    my ($sOutFileSpec, $sOutFile, $sDir, $sFile, $sTmp);
    my ($fpPILEUP, $fpOUT, $fpCSV, $fpCSV_NOPAD, $fpTM, $fpCVG, $nFP);

    Indent('+');
    
    ($bDebug) ? print STDERR Indent("In $sSubName\n") : ();

    ($bDebug || $bVerbose) ?
        print STDERR Indent("Computing stats for $sPileupFile...\n") : ();

    tie %hSegment, "Tie::IxHash";   # return keys in the order they were
                                    # added.

    if (defined $phCmdLineOption->{'pad'}) {
    	$nPrePadSize = $nPostPadSize = $phCmdLineOption->{'pad'};
    }
    else {
    	$nPrePadSize = $phCmdLineOption->{'prepad'};
    	$nPostPadSize = $phCmdLineOption->{'postpad'};
    }

    $sOutFileSpec = Init_OutFileName( \%$phCmdLineOption,
                                      $sOutDir,
                                      $sPileupFile,
                                      'pileup');

  	$sOutFile = File::Spec->canonpath( $sOutFileSpec.
	    	                                   '_base_depths.txt');
   	open($fpOUT, '>', $sOutFile) ||
    	   croak "$sSubName - Cannot open $sOutFile for writing\n";

	open($fpPILEUP, '<', $sPileupFile) ||
        croak "$sSubName - Cannot open $sPileupFile for reading\n";

    $nSegNum = $nLineNum = $nFP = 0;

    $sPrevID = ();

    while (<$fpPILEUP>) {

        chomp;

       ($sID, $nBaseNum, $cBase, $sTmp) = split(/\t/,$_, 4);

       $nBaseDepth = 0;
       foreach (split(/\t/,$sTmp)) {
           $nBaseDepth += $_;
       }

        if ($sID !~ /(chr.*)[_\W](\d+)[-_](\d+)$/) {
        	croak "$sSubName - Cannot parse segment ID - $sID\n";
        }
        $sID = $1.':'.eval($2 + $nPrePadSize).'-'.eval($3 - $nPostPadSize);
 
        $nLineNum++;

		if (((defined $sPrevID) && ($sID ne $sPrevID)) || 
		    (! defined $sPrevID)) {
			$nSegNum++;
            ($bVerbose) ? print STDERR "\r".Indent("Segment: $nSegNum") : ();
		}
		$sPrevID = $sID;

        if (! defined $hSegment{$sID}) {

            $sID =~ /chr(.*)[_\W](\d+)-(\d+)$/;

            my $rStats = {
                PRE_PAD_DEPTH       => 0.0,
                PRE_PAD_SEQ         => "",
                POST_PAD_DEPTH      => 0.0,
                POST_PAD_SEQ        => "",
                CHR                 => $1,
                START               => $2,
                STOP                => $3,
                SEGMENT_SIZE        => $3 - $2 + 1,
                SEGMENT_SEQ         => "",
                SEGMENT_DEPTH       => "",
                SEGMENT_MEDIAN      => 0.0,
                SEGMENT_VAR         => 0.0,
                SEGMENT_SD          => 0.0,
                SEGMENT_GC          => 0.0,
                SEGMENT_TM_NDF      => 'NA',
                SEGMENT_TM_NDF_VAR  => 'NA',
                SEGMENT_TM_NDF_SD   => 'NA',
                SEGMENT_TM_KMER     => 0.0,
                SEGMENT_TM_KMER_VAR => 0.0,
                SEGMENT_TM_KMER_SD  => 0.0,
                KMER_TMS            => "$sID",
                KMER_DEPTHS         => "$sID",
                DEPTHS              => "$sID",
            };

            $hSegment{$sID} = $rStats;
        }

        if ($nBaseNum <= ($nPrePadSize)) {                
            $hSegment{$sID}->{PRE_PAD_DEPTH} += $nBaseDepth;
            $hSegment{$sID}->{PRE_PAD_SEQ} .= $cBase;
        }
        elsif ($nBaseNum <= ($nPrePadSize + $hSegment{$sID}->{SEGMENT_SIZE})) {
        	$hSegment{$sID}->{SEGMENT_DEPTH} .= "$nBaseDepth,";
            $hSegment{$sID}->{SEGMENT_SEQ} .= $cBase;

            if (defined $hReadDistribution{$nBaseDepth}) {
                $hReadDistribution{$nBaseDepth}++;
            }
            else {
                $hReadDistribution{$nBaseDepth} = 1;
            }

            print $fpOUT "$nBaseDepth\n";
        }
        else {
            $hSegment{$sID}->{POST_PAD_DEPTH} += $nBaseDepth;
            $hSegment{$sID}->{POST_PAD_SEQ} .= $cBase;
        }
        
       	$hSegment{$sID}->{DEPTHS} .= ",$nBaseDepth";
        
        ($bDebug) ? (print STDERR "\r\tfpPILEUP: $nFP") && $nFP++ : ();
        
    }

    close($fpPILEUP);

    close($fpOUT);

    if ($nSegNum == 0) {
        croak "$sSubName - Number of segments is $nSegNum (??)\n";
    }
    

	foreach $sID (keys %hSegment) {
	
        if ($nPrePadSize > 0) {
		    $hSegment{$sID}->{PRE_PAD_DEPTH} /= $nPrePadSize;
        }
        if ($nPostPadSize > 0) {
            $hSegment{$sID}->{POST_PAD_DEPTH} /= $nPostPadSize;
        }

        {
        	my @aTmp = sort { $a <=> $b } 
                            split(/,/, $hSegment{$sID}->{SEGMENT_DEPTH});

        	$hSegment{$sID}->{SEGMENT_DEPTH} = Calc_Mean(@aTmp);
            $hSegment{$sID}->{SEGMENT_MEDIAN} = Calc_Median(@aTmp);
        	$hSegment{$sID}->{SEGMENT_VAR} = 
                Calc_Variance($hSegment{$sID}->{SEGMENT_DEPTH}, @aTmp);
        	$hSegment{$sID}->{SEGMENT_SD} = 
                $hSegment{$sID}->{SEGMENT_VAR} ** 0.5;

        	my @aDepths = split(/,/, $hSegment{$sID}->{DEPTHS});


        	my $nStart = $nPrePadSize - ceil($nKmer / 2) + 1;

            if ($nStart < 0) {
                $nStart = 1;
            }

        	my $nStop =  $#aDepths -
                         $nPostPadSize + 
                         ceil($nKmer / 2) -
                         $nKmer + 1;

            if ($nStart == 1) {
                $nStop = $#aDepths - $nKmer + 1;
            }

#            $sID =~ /(\d+)-(\d+)$/;

#            ($bDebug) ? print STDERR "\n".
#                                     "nKmer: $nKmer\n".
#                                     "sID: $sID\n".
#                                     "size: ".eval($2-$1+1)."\n".
#                                     "Num. depths: ".@aDepths."\n".
#                                     "nStart: $nStart\n".
#                                     "nStop: $nStop\n" : ();
#            exit;

            my $nI = 0;
                    	
        	for (my $nX = $nStart; $nX <= $nStop; $nX += $nSkip) {
        		my $nDepth = 0;
        		for (my $nY = $nX; $nY < ($nX + $nKmer); $nY++) {
        			$nDepth += $aDepths[$nY];
        		}
        		$nDepth /= $nKmer;
        		$hSegment{$sID}->{KMER_DEPTHS} .= sprintf(",%.4f", $nDepth);
        		$nI++;
        	}
        	if ($bDebug) {
        		$hSegment{$sID}->{KMER_DEPTHS} .= ",($nI)";
        	}
        }
        
        $hSegment{$sID}->{SEGMENT_GC} = Calc_GC($hSegment{$sID}->{SEGMENT_SEQ});
        
        push @aSegDepths, $hSegment{$sID}->{SEGMENT_DEPTH};
        push @aSegMedians, $hSegment{$sID}->{SEGMENT_MEDIAN};        
    }

    $nAvgSegDepth = Calc_Mean(@aSegDepths);
    $nMedianSegDepth = Calc_Median(@aSegMedians);
    $nSegVar = Calc_Variance($nAvgSegDepth, @aSegDepths);
    $nSegSD = $nSegVar**0.5;
    
    if (defined $phCmdLineOption->{'ndf'}) {
        Compute_Tm_From_NDF( \%$phCmdLineOption,
                             \%$phNdf,
                             \%hSegment,
                             \@aSkippedProbes);
    }
    
  	Compute_Tm_From_Kmer(\%$phCmdLineOption, \%hSegment);
    
    $sOutFileSpec = Init_OutFileName( \%$phCmdLineOption,
                                      $sOutDir,
                                      $sPileupFile,
                                      'pileup');

    if (defined $phCmdLineOption->{'ndf'}) {
	    if ($#aSkippedProbes >= 0) {
	    	$sOutFile = File::Spec->canonpath( $sOutFileSpec.
	    	                                   '_skipped_probes.txt');
	    	open($fpOUT, '>', $sOutFile) ||
	    	   croak "$sSubName - Cannot open $sOutFile for writing\n";
	    	   
	    	foreach (@aSkippedProbes) {
	    		print $fpOUT "$_\n";
	    	}
	    	
	    	close($fpOUT);
	    }
    }

    $sOutFile = File::Spec->canonpath($sOutFileSpec.'_read_distribution.txt');
    open($fpOUT, '>', $sOutFile) ||
        croak "$sSubName - Cannot open $sOutFile for writing\n";
    
    print $fpOUT "\nRead distribution:\nNo. Reads\tNo. Bases\n";
    foreach $sID (sort { $a <=> $b } keys %hReadDistribution) {
        printf $fpOUT "%5d\t\t%7d\n",$sID,$hReadDistribution{$sID};
    }

    close($fpOUT);

    $sOutFile = File::Spec->canonpath($sOutFileSpec.
                                      '_tm_window.csv');
    open($fpTM, '>', $sOutFile) ||
        croak "$sSubName - Cannot open $sOutFile for writing\n";

    $sOutFile = File::Spec->canonpath($sOutFileSpec.   
                                      '_coverage_window.csv');
    open($fpCVG, '>', $sOutFile) ||
        croak "$sSubName - Cannot open $sOutFile for writing\n";    
        
    if ($bCSV) {
        $sOutFile = File::Spec->canonpath( $sOutFileSpec.
                                           '_pileup.csv');    	
    	open($fpCSV, '>', $sOutFile) ||
    		croak "$sSubName - Cannot open $sOutFile for writing\n";
    		
        $sOutFile = File::Spec->canonpath( $sOutFileSpec.
                                           '_pileup_nopad.csv');
        open($fpCSV_NOPAD, '>', $sOutFile) ||
            croak "$sSubName - Cannot open $sOutFile for writing\n";
    }
    
    $sOutFile = File::Spec->canonpath($sOutFileSpec.
                                      '_pileup.stats');
    open($fpOUT, '>', $sOutFile) ||
        croak "$sSubName - Cannot open $sOutFile for writing\n";
   
    print $fpOUT "Number of segments: $nSegNum\n";
    printf $fpOUT "Avg. depth across segments (non-padded): %5.2f\n",
                  $nAvgSegDepth;
    printf $fpOUT "Median depth across segments (non-padded): %5.2f\n",
                  $nMedianSegDepth;
    printf $fpOUT "Variance across segments: %5.2f\n",$nSegVar;
    printf $fpOUT "Standard deviation across segments: %5.2f\n\n",$nSegSD;

	print $fpOUT "SegmentID\tSize\t".
                 "Avg_Coverage\tMedian_Coverage\tVariance\t".
                 "StdDev\tGC\tTm(k-mer)\tTm_Variance\tTm_StdDev";
    
    if (defined $phCmdLineOption->{'ndf'}) {
    	print $fpOUT "\tTm(NDF)\tTm_Variance\tTm_StdDev";
    }
    
    print $fpOUT "\tPrePad_Coverage\tPostPad_Coverage\n";
				 
    foreach $sID (keys %hSegment) {

        $sID =~ /(chr.*)[_\W](\d+)-(\d+)/;
        my $sPadID = $1.":".
                     eval($2 - $nPrePadSize).
                     "-".
                     eval($3 + $nPostPadSize);
        
        printf $fpOUT "%s\t%d\t".
                      "%9.2f\t%9.2f\t%9.2f\t".
                      "%9.2f\t%9.2f\t%9.2f\t%9.2f\t%9.2f\t",
                      $sPadID,
                      $hSegment{$sID}->{SEGMENT_SIZE},
                      $hSegment{$sID}->{SEGMENT_DEPTH},
                      $hSegment{$sID}->{SEGMENT_MEDIAN},
                      $hSegment{$sID}->{SEGMENT_VAR},
                      $hSegment{$sID}->{SEGMENT_SD},
                      $hSegment{$sID}->{SEGMENT_GC},
                      $hSegment{$sID}->{SEGMENT_TM_KMER},
                      $hSegment{$sID}->{SEGMENT_TM_KMER_VAR},
                      $hSegment{$sID}->{SEGMENT_TM_KMER_SD};
                      
        if (defined $phCmdLineOption->{'ndf'}) {
       	    printf $fpOUT "\t%9.2f\t%9.2f\t%9.2f",
       	                  $hSegment{$sID}->{SEGMENT_TM_NDF},
       	                  $hSegment{$sID}->{SEGMENT_TM_NDF_VAR},
       	                  $hSegment{$sID}->{SEGMENT_TM_NDF_SD};
        }
        
        printf $fpOUT "\t%9.2f\t%9.2f\n",
                      $hSegment{$sID}->{PRE_PAD_DEPTH},
                      $hSegment{$sID}->{POST_PAD_DEPTH};

        if ($bCSV) {
        	print $fpCSV "$hSegment{$sID}->{DEPTHS}\n";
            my @aTmp1 = split(/,/, $hSegment{$sID}->{DEPTHS});
            my $nStart = 1 + $nPrePadSize;
            my $nStop = $#aTmp1 - $nPostPadSize;
            my @aTmp2 = @aTmp1[$nStart .. $nStop];
            my $sTmp = join(',',@aTmp2);

            print $fpCSV_NOPAD "chr".
                               "$hSegment{$sID}->{CHR}".
                               ":".
                               "$hSegment{$sID}->{START}".
                               "-".
                               "$hSegment{$sID}->{STOP}".
                               ",".
                               "$sTmp\n";
        }
        
        print $fpTM "$hSegment{$sID}->{KMER_TMS}\n";
        print $fpCVG "$hSegment{$sID}->{KMER_DEPTHS}\n";
        
    }

    close($fpOUT);
    
	if ($bCSV) {
		close($fpCSV);
	}
	
    close($fpCVG);
    close($fpTM);

    ($bDebug || $bVerbose) ? print STDERR "\n" : ();

    ($bDebug) ? print STDERR Indent("Leaving $sSubName\n") : ();

    Indent('-');
    
    return;
}


# Compute_Tm_From_NDF()
#
# Purpose
#
#    Compute Tm for each segment in a pileup file using probes from NDF file
#
# Required Parameters
#   phCmdLineOption = pointer to hash containing command line options
#   phSegment       = pointer to hash containing segment data
#   paSkippedProbes = pointer to array to store probes that are not used in
#                     computing Tm
#
# Optional Parameters
#
# Returns
#   nothing
#
# Side Effects
#   modifies external variables
#   
# Assumptions
#   an NDF file is specified on program invokation
#
# Notes
#
sub Compute_Tm_From_NDF {
    my $phCmdLineOption = shift;
    my $phNdf           = shift;
    my $phSegment       = shift;
    my $paSkippedProbes = shift;
    
    my $sSubName = (caller(0))[3];
    if (! ((defined $phCmdLineOption) &&
           (defined $phNdf)           &&
           (defined $phSegment)       &&
           (defined $paSkippedProbes))) {
        croak "$sSubName - required parameters missing\n";
    }

    # Local variables
    my $bDebug = (defined $phCmdLineOption->{'debug'}) ? TRUE : FALSE;
    my $bVerbose = (defined $phCmdLineOption->{'verbose'}) ? TRUE : FALSE;

    my $sContainerID = $phCmdLineOption->{'cid'};

    my (%hSegIndex, %hTm);
    my (@aSegID, @aFields);
    my ($sNdfKey, $sKey);
    my ($nSegStart, $nSegStop, $nProbeStart, $nProbeStop, $nTm, $nI, $nX);
    my $fpNDF;

    %hSegIndex = ();
    %hTm = ();
    @aSegID = ();

    Indent('+');
    
    ($bDebug) ? print STDERR Indent("In $sSubName\n") : ();

    ($bDebug || $bVerbose) ?
        print STDERR Indent("Computing Tm from NDF...\n") : ();

    $nI = 0;
    foreach $sKey (keys %$phSegment) {
        if ($sKey !~ /chr.*[_\W](\d+)-(\d+)/) {
        	croak "$sSubName - invalid segment id detected. nI = $nI\n";
        }
        else {
        	$nSegStart = $1;
        	$nSegStop = $2;
        }
        
		@hSegIndex{$nSegStart .. $nSegStop} = 
		    values %{{map {$_ => $nI}($nSegStart .. $nSegStop)}};
        $aSegID[$nI] = $sKey;
        $nI++;
    }

    $nI = 0;
    
    foreach $sNdfKey (keys %$phNdf) {
 
        if ($sNdfKey !~ /chr.*[_\W](\d+)-(\d+)/) {
            croak "$sSubName - invalid SEQID detected: $sNdfKey\n";
        }

        $nProbeStart = $1;
        $nProbeStop = $2;
        
        if (defined $hSegIndex{$nProbeStart}) {
        	$sKey = $aSegID[$hSegIndex{$nProbeStart}];
        }
        elsif (defined $hSegIndex{$nProbeStop}) {
            $sKey = $aSegID[$hSegIndex{$nProbeStop}];
        }
        else {
        	$sKey = ();
        	for ($nX = $nProbeStart; $nX <= $nProbeStop; $nX++) {
        		if (defined $hSegIndex{$nX}) {
        			$sKey = $aSegID[$hSegIndex{$nX}];
        			last;
        		}
        	}
        	if (! defined $sKey) {
        	   push @$paSkippedProbes, $sNdfKey;
        	   next;
        	}
        }
        
        $nTm = Calc_Tm($phNdf->{$sNdfKey});
        
        if (! defined $hTm{$sKey}) {
        	$hTm{$sKey} = [ $nTm ];
        }
        else {
        	push @{ $hTm{$sKey} }, $nTm;
        }
        
        $nI++;
        ($bDebug || $bVerbose) ?
            print STDERR "\r".Indent("Probe: $nI") : ();

    }
    
    ($bDebug || $bVerbose) ? print STDERR "\n" : ();
    
    $nI = 0;
    foreach (keys %hTm) {
    	$phSegment->{$_}->{SEGMENT_TM_NDF} = Calc_Mean(@{ $hTm{$_} });
    	$phSegment->{$_}->{SEGMENT_TM_NDF_VAR} =
            Calc_Variance($phSegment->{$_}->{SEGMENT_TM_NDF}, @{ $hTm{$_} });
    	$phSegment->{$_}->{SEGMENT_TM_NDF_SD} =
            $phSegment->{$_}->{SEGMENT_TM_NDF_VAR} ** 0.5;
    	$nI++;
        ($bDebug || $bVerbose) ?
            print STDERR "\r".Indent("Segment: $nI") : ();
    }

    ($bDebug || $bVerbose) ? print STDERR "\n" : ();

    ($bDebug) ? print STDERR Indent("Leaving $sSubName\n") : ();

    Indent('-');
    
    return;
}


# Compute_Tm_From_Kmer()
#
# Purpose
#
#    Compute Tm for each segment in a pileup file using Kmer
#
# Required Parameters
#   phCmdLineOption = pointer to hash containing command line options
#   phSegment       = pointer to hash containing segment data
#
# Optional Parameters
#
# Returns
#   nothing
#
# Side Effects
#   modifies external variables
#   
# Assumptions
#   kmer size is specified in command line options
#
# Notes
#
sub Compute_Tm_From_Kmer {
	my $phCmdLineOption = shift;
	my $phSegment       = shift;
    
    my $sSubName = (caller(0))[3];
    if (! ((defined $phCmdLineOption) &&
           (defined $phSegment      ))) {
        croak "$sSubName - required parameters missing\n";
    }

    # Local variables
    my $bDebug   = (defined $phCmdLineOption->{'debug'})   ? TRUE : FALSE;
    my $bVerbose = (defined $phCmdLineOption->{'verbose'}) ? TRUE : FALSE;	

    my $nKmer = $phCmdLineOption->{'kmer'};
    my $nSkip = $phCmdLineOption->{'skip'};
    
    my ($sSequence, $sSubSeq, $sID);
    my ($nStart, $nStop, $nShift, $nI);
    my @aTm = ();
    
    Indent('+');
    
    ($bDebug) ? print STDERR Indent("In $sSubName\n") : ();
    
    ($bDebug || $bVerbose) ?
        print STDERR Indent("Computing Tm From Kmers...\n") : ();
        
    $nI = 0;
    $nShift = $nKmer - $nSkip;
    
    foreach $sID (keys %$phSegment) {
        
        $nStop = ceil($nKmer / 2);
        $nStart = -$nStop;
        $sSequence =
            uc( substr($phSegment->{$sID}->{PRE_PAD_SEQ},$nStart,$nStop).
                $phSegment->{$sID}->{SEGMENT_SEQ}.
                substr($phSegment->{$sID}->{POST_PAD_SEQ},0,$nStop) );

        @aTm = ();
        
        while ($sSequence =~ /([ACGTN]{$nKmer})/g) {
        	$sSubSeq = $1;
        	pos($sSequence) -= $nShift;
        	if ($sSubSeq !~ /N/) {
        	   push @aTm, Calc_Tm($sSubSeq);
        	}
        	else {
        	   push @aTm, -1;
        	}
        }

        foreach (@aTm) {
        	$phSegment->{$sID}->{KMER_TMS} .= sprintf(",%.4f",$_);
        }
        if ($bDebug) {
        	$phSegment->{$sID}->{KMER_TMS} .= sprintf(",(%d)",eval(@aTm));
        }
        
        
        $phSegment->{$sID}->{SEGMENT_TM_KMER} = Calc_Mean(@aTm);
        $phSegment->{$sID}->{SEGMENT_TM_KMER_VAR} =
            Calc_Variance($phSegment->{$sID}->{SEGMENT_TM_KMER}, @aTm);
        $phSegment->{$sID}->{SEGMENT_TM_KMER_SD} =
            $phSegment->{$sID}->{SEGMENT_TM_KMER_VAR} ** 0.5;
              
        $nI++;
        ($bDebug || $bVerbose) ?
            print STDERR "\r".Indent("Segment: $nI") : ();
    }
    
    ($bDebug || $bVerbose) ? print STDERR "\n" : ();
    
    ($bDebug) ? print STDERR Indent("Leaving $sSubName\n") : ();
    
    Indent('-');
    
    return;
}



sub Calc_GC {
    my $sSequence = uc(shift);

    my ($nCalledBases, $nGC);
    my ($nA, $nC, $nG, $nN, $nT);

    $nA = $sSequence =~ tr/A//;
    $nC = $sSequence =~ tr/C//;
    $nG = $sSequence =~ tr/G//;
    $nN = $sSequence =~ tr/N//;
    $nT = $sSequence =~ tr/T//;

    $nCalledBases = $nA + $nC + $nG + $nT;

    if ($nCalledBases > 0) {
        $nGC = (($nC + $nG) / $nCalledBases) * 100.0;
    }
    else {
        $nGC = 'NaN';
    }

    return $nGC;
}


sub Calc_Variance {
	my $nMean = shift;
	my @aData = @_;
	
	my $nSum = 0;
	my $nVariance;
	
	return 'NaN' if ($nMean eq 'NaN');
	return 'NaN' if (@aData == 0);
	
	foreach (@aData) {
		$nSum += (($_ - $nMean) ** 2);
	}

    if (@aData > 1) {	
	    $nVariance = $nSum / (@aData - 1);
    } 
    else {
        $nVariance = $nSum / @aData;
    }
    
	return $nVariance;
}


sub Calc_Mean {
	my @aData = @_;
	
	my $nSum = 0;
	my $nMean = 'NaN';
	
	if (@aData > 0) {
	   foreach (@aData) {
		  $nSum += $_;
	   }
	
	   $nMean = $nSum / @aData;
	}
	
	return $nMean;
}


sub Calc_Median {
    my @aData = @_;

    my @aTmp = ();
    my $nMedian = 'NaN';

    if (@aData > 0) {
        @aTmp = sort { $a <=> $b } @aData;
        if (@aData % 2 == 0) {
            $nMedian = ($aTmp[int(@aData/2)] + $aTmp[int(@aData/2)+1]) / 2;
        }
        else {
            $nMedian = ($aTmp[int(@aData/2)]);
        }
    
    }

    return $nMedian;
}


# Init_OutFileName()
#
# Purpose
#   generates a new filename based on existing filename by removing the
#   extension, and prepending an output directory
#
# Required Parameters
#   phCmdLineOption = pointer to hash containing command line options
#   sOutDir         = output directory
#   sFileName       = existing filename
#   sExtension      = filename extension
#
# Optional Parameters
#   none
#
# Returns
#   sOutFile        = new filename
#
# Side Effects
#   none
#
# Assumptions
#
# Notes
#
sub Init_OutFileName {
    my $phCmdLineOption = shift;
    my $sOutDir         = shift;
    my $sFileName       = shift;
    my $sExtension      = shift;

    my $sSubName = (caller(0))[3];

    if (! ((defined $phCmdLineOption) &&
           (defined $sOutDir)         &&
           (defined $sFileName)       &&
           (defined $sExtension))) {
        croak "$sSubName - required parameters missing\n";
    }

    # Local variables
    my $bDebug   = (defined $phCmdLineOption->{'debug'}) ? TRUE : FALSE;
    my $bVerbose = (defined $phCmdLineOption->{'verbose'}) ? TRUE : FALSE;

    my ($sFile, $sDir);
    my $sOutFile;


#    ($bDebug) ? print STDERR "In $sSubName\n" : ();

#    ($bDebug || $bVerbose) ? print STDERR "\n\tInitializing filename...\n" : ();

    ($_, $sDir, $sFile) = File::Spec->splitpath($sFileName);
    if ($sOutDir ne File::Spec->curdir()) {
        $sDir = '';
    }
        $sFile =~ m/^(\S+)\.$sExtension$/;
        if (defined $1) {
            $sOutFile = $sOutDir.'/'.$sDir.'/'.$1;
        }
        else {
            $sOutFile = $sOutDir.'/'.$sDir.'/'.$sFile;
        }
    $sOutFile = File::Spec->canonpath($sOutFile);

#    ($bDebug || $bVerbose) ? print STDERR "\n" : ();

#    ($bDebug) ? print STDERR "Leaving $sSubName\n" : ();
    
    return $sOutFile
}


INIT {
	
	use Switch;
	
	my $nIndentLevel = -1;
    my $bNL = FALSE;
    
    sub Indent {
	   my $sMode = shift;
		   
	   my $sTmp = ();
	   
	   switch ($sMode) {
	       case '+' { $nIndentLevel++; $bNL = TRUE }
	       case '-' { 
	           if ($nIndentLevel >= 0) {
	               $nIndentLevel--;
	           }
	           $bNL = TRUE
	       }
	       else     {
	       	   if ($bNL) {
	       	       $sTmp = "\n";
	       	       $bNL = FALSE;
	       	   }
	           foreach (0 .. $nIndentLevel) {
	               $sTmp .= "\t";
	           }
	           $sTmp .= $sMode;
	       }
	   }
	   
	   return $sTmp;
    }
    
} #INIT


##############################################################################
### POD Documentation
##############################################################################

__END__

=head1 NAME

pustats.pl - program to compute segment stats from a pileup file

=head1 SYNOPSIS

 pustats.pl --i pileup_filespec --k kmer_size --s skip_size
 --p pad_size | --prepad pre_pad_size --postpad post_pad_size
 [--n ndf_file --d container_id] [--c]  [--o output_directory] [--v]

 Command line parameters in square brackets are optional.

 pustats.pl --help also displays usage information.
 pustats.pl --man  generates the full manual page for the program

=head1 OPTIONS

 --i pileup_filespec

 Text file(s) containing pileup data generated by MAQ. If a directory, it will
 be searched for files with a .pileup extension. Otherwise the current directory
 will be searched. Wildcards may also be used but <filespec> should be enclosed
 in quotes, e.g. "NLGN*.pileup"

 --k kmer_size

 The size of window to use in computing segment Tm. The skip size for computing
 segment Tm is always 1.

 --s skip_size
 
 The value by which to slide the window in computing window Tms and coverages.
 
 --p pad_size

 The number of bases on either side of the reference sequence.

 --prepad pre_pad_size

 The number of bases before the reference sequence
 
 --postpad post_pad_size
 
 The number of bases after the reference sequence
 
 *** NOTE: Either --p or --prepad/--postpad must be specified. However they are
 mutually exclusive. Use one or the other, never both.
 
 --n ndf_file

 NDF file containining probes for each segment in the pileup file. The NDF file
 must contain the probe coordinates in USCS format in the SEQ_ID column. If this
 option is specified,the next option must also be specified.

 --d container_id

 A single-quoted string containing id's that identify an actual probe line in
 the NDF (as opposed to control lines). The string may contain multiple id's if
 they are separated by a vertical bar, e.g. --d 'FORWARD|REVERSE'.

 --c

 Generate a CSV file with the depths of each segment in rows. Facilitates
 importing into a spreadsheet or plotting program. Creates CSV with padded and
 unpadded depths.

 --o <output_directory>

 Output files will be placed in this directory. Default is current directory.
 Output file names will be denoted by _pileup.stats.

 --v

 Flag to enable generation of runtime messages

=head1 DESCRIPTION

=head1 DIAGNOSTICS

=head1 CONFIGURATION AND ENVIRONMENT

 set PERL5LIB enviroment variable to include paths for required modules below
 
=head1 DEPENDENCIES

 POSIX
 Getopt::Long
 Pod::Usage
 Tie::IxHash
 CutlerLab::Tm

=head1 INCOMPATIBILITIES

=head1 BUGS AND LIMITATIONS

There are no known bugs in this module. Please report problems to Viren Patel
(vcpatel@genetics.emory.edu). Patches are welcome.

=head1 AUTHOR

 Viren Patel
 Zwick Lab (http://www.genetics.emory.edu/labs/zwick/zwick_lab_index.php)
 Department of Human Genetics
 Emory University School of Medicine
 Whitehead Biomedical Research Building
 615 Michael Street, Suite 301
 Atlanta, GA 30322

=head1 LICENSE AND COPYRIGHT

Copyright (c) 2028 Michael E Zwick (<mzwick@genetics.emory.edu>). All rights
reserved.

This program is free software; you can distribute it and/or modify it under the
same terms as Perl itself. See L<perlartistic>.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTIBILITY or FITNESS
FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

=cut

##############################################################################
### Internal Documentation
##############################################################################

# Revision Notes

# 20090209 - Version 1.9.0
#   - Added output of number of segments
#
# 20090113 - Version 1.8.1
#   - Removed functionality to output base counts
#
# 20090110 - Version 1.8.0
#   - Added functionality to output counts of non-pad bases
#   - Changed read distribution output to new file
#
# 20090108 - Version 1.7.0
#   - Added functionality to output non-padded base coverage to a separate
#     file
#   - Changed read distribution output to show distribution for all depths,
#     not grouped
#
# 20090106 - Version 1.6.0
#   - Added functionality to compute median coverage of each segment and
#     across segments
#   - Added functionality to compute percent read distribution for 0 to 10
#     reads, and more than 10 reads
#
# 20081217 - Version 1.5.1
#   - Fixed extra tab in header line in stats file
#
# 20081024 - Version 1.5.0
#   - Added code to compute variance and std. dev. of segment Tms (for both
#     k-mer and ndf methods);
#   - Modified stats output file to print NDF tm, var. and std. dev.
#     values only if --ndf command-line option is used
#   - Modified stats output file column order
#
# 20081014 - Version 1.4.2
#   - Fixed code to remove count from tm_window.csv and coverage_window.csv
#     files.
#
# 20081013 - Version 1.4.1
#   - Fixed code to disregard N calls
#
# 20081010 - Version 1.4.0
#   - Added functionality to compute Tm and Depth for size kmer windows for
#     each segment.
#
# 20081009 - Version 1.3.0
#   - Added functionality to compute segment Tm using sub sequences of a
#     specified size.
#
# 20081008 - Version 1.2.0
#   - Added functionality to compute segment Tm using corresponding probes
#     from NDF file
#   - Added functionality to compute segment GC content
#
# 20080603 - Version 1.1.0
#   - Added functionality to generate CSV without padded regions
#   - Fixed bug that used entire segment size to compute avg. depth of
#   unpadded region
#
# 20080418 - Version 1.0.0
#   - initial release
#

# Variable/Subroutine Name Conventions

# Type Prefixes

#    b = boolean
#    c = character
#    n = number
#    p = pointer aka reference
#    s = string
#    a = array
#    h = hash
#    r = rec (aka hash)
#    o = object (e.g. for vars created/initialized via module->new() methods)
#    g = global

#    Type prefixes can be combined where appropriate, e.g. as = array of
#    strings or ph = pointer to a hash, but not cn (character of numbers???)

# Variable Names

#    Variable names start with a type prefix followed by capitalized words
#    descriptive of the purpose of the variable. Variable names do not have
#    underscores. E.g. sThisIsAString

# Subroutine Names

#    Subroutine names do not have a type prefix, have capitalized words
#    descriptive of the purpose of the subroutine, and the words are
#    separated by an underscore. E.g. This_Is_A_Subroutine

#    Internal utility subroutines begin with an underscrore and follow the
#    naming conventions of subroutines.
