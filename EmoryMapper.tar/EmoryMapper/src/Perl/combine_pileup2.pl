#!/usr/bin/perl
# Run all chips
use strict 'vars';
use vars qw($dirname $i $j @filehandles @files @filess @fields $name $frag $pos);

$dirname = ".";

if(@ARGV != 2)
{
	print "\n Usage: ${0} file_extension outfile \n";
	exit(1);
}

opendir(DIR,$dirname) || die "Cannot open $dirname";
@files =  grep{/$ARGV[0]$/} readdir(DIR);
@filess = sort @files;
close(DIR);
open(FILE,">$ARGV[1]") || die "\n Can't open file $ARGV[1] for writing \n";
print FILE "Fragment\tPosition\tReference";
for($i=0;$i<@filess;$i++)
{
	open($filehandles[$i],"<$filess[$i]") || die "\n Can't open file $filess[$i] \n";
	$_ = readline($filehandles[$i]);
	chomp;
	@fields = split("\t");
	my $avg = $fields[9];
	#print;
	@fields = split('\.',$filess[$i]);
	$name = $fields[0];
	print "\t\t File $filess[$i] using name .$name.\n";
	print FILE "\t$name";
	print FILE "\t$avg\t\t\t\t";
}

while(!eof($filehandles[0]))
{
	for($i=0;$i<@filess;$i++)
	{
		$_ = readline($filehandles[$i]);
		chomp;
		@fields = split('\t');
		if($i==0)
		{
			$frag = $fields[0];
			$pos = $fields[1]+0;
			print FILE "\n$fields[0]\t$fields[1]\t$fields[2]\t$fields[3]\t$fields[4]\t$fields[5]\t$fields[6]\t$fields[7]\t$fields[8]";
		}
		else
		{
			if($fields[0] ne $frag || $fields[1] != $pos)
			{
				print "\n The first file had fragment=$frag and pos=$pos, whereas $filess[$i] has fragment=$fields[0] and pos=$fields[1]\n";
				exit(1);
			}
			print FILE "\t$fields[3]\t$fields[4]\t$fields[5]\t$fields[6]\t$fields[7]\t$fields[8]";
		}
	}
}
