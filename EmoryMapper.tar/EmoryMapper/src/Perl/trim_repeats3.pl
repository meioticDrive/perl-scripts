#!/opt/local/bin/perl

use strict 'vars';

use vars qw($dirname @save_line $b1 $last @fields $start $stop $exons @histo $this_exon_hit $exon_hits  @subfields $tot $good $avg);



if(@ARGV != 1)

{

	die "\n Usage: ${0} filename \n";

}



open(FILE,"$ARGV[0].pileup.txt") || die "\n Can't open file $ARGV[0].pileup.txt \n";

open(oFILE,">$ARGV[0]_temp.txt") || die "\n Can't open file $ARGV[0]_temp.txt for writing\n";

$_ = <FILE>;

@save_line = split("\t");

#print oFILE;

$last = "!!!!!!";

while(<FILE>)

{

	chomp;

	@fields = split('\t');

	if($fields[0] ne $last)

	{

		@subfields = split('[-_\:]',$fields[0]); 

		$_ = $subfields[0];

		if(/^[Cc][Hh][Rr]/)

		{

			my $j = $subfields[1];

			my $k = $subfields[2];

			if($subfields[3] > 0 || $subfields[4] > 0)

			{

				$start = $subfields[3]+2;

				$stop = ($subfields[2]-$subfields[1])-$subfields[4]+2;

				#print "\n$subfields[0] $subfields[1] $subfields[2]  start=.$start. stop = .$stop.";

				$j = 1+$subfields[1] + $subfields[3];

				$k = 1+$subfields[2] - $subfields[4];

			}

			else

			{

				$start = 1;

				$stop = 1 + $k - $subfields[1]; 

			}

			$b1 = "$subfields[0]:$j-$k";

			$exons++;

			if($this_exon_hit > 0)

			{

				$exon_hits++;

			}

			$this_exon_hit = 0;

		}

		else

		{

			$start = 1;

			$stop = -1;

		}

		$last = $fields[0];

	}

	if($fields[1] >= $start && $fields[1] <= $stop)

	{

		my $j = int(1 + $fields[1] - $start);

		print oFILE  "$b1\t$j";

		for(my $i=2; $i < @fields;$i++)

		{

			print oFILE "\t$fields[$i]";

		}

		$tot++;

		my $this_cov = $fields[3] + $fields[4] + $fields[5] + $fields[6];

		if($this_cov >= 1)

		{

			$this_exon_hit++;

			$good++;

			$avg += $this_cov;

		}

		print oFILE "\n";

	}

}

close(FILE);

close(oFILE);

if($this_exon_hit > 0)

{

	$exon_hits++;

}



print "\nTotal Number of Bases in Target Region\t$tot";

my $j = $good;

if($tot > 0)

{

	$j /= $tot;

	$avg /= $tot;

}

print "\nTotal Number of Bases with at least one read\t$good\t$j";

print "\nAverage Depth of Coverage\t$avg";

if($exons > 0)

{

	$j = $exon_hits / $exons;

}

print "\nTotal Number of Exons in Region\t$exons";

print "\nTotal Number of Exons with at least one read\t$exon_hits\t$j\n";

open(oFILE,">$ARGV[0]_header") || die "\n Can't open file $ARGV[0]_header for writing\n";

for(my $i=0;$i<@save_line-1;$i++)

{

	print oFILE "$save_line[$i]\t";

}

print oFILE "$avg\n";

close(oFILE);

system("sync");

system("cat $ARGV[0]_header $ARGV[0]_temp.txt > $ARGV[0]_trim.pileup.txt");

system("rm $ARGV[0]_header $ARGV[0]_temp.txt");



